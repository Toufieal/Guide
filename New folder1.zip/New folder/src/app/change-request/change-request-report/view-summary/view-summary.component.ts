import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component, ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PasscrdataService } from '../../passcrdata.service';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment'
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

interface DropdownItem {
  item_id: number;
  item_text: string;
}

@Component({
  selector: 'app-view-summary',
  templateUrl: './view-summary.component.html',
  styleUrl: './view-summary.component.css'
})
export class ViewSummaryComponent {
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  supportid: any;
  supportname: any;
  today: any;
  crid: any = '';
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: ActivatedRoute, private router: Router) {
    this.getChangeRequests();
  }
  private apiurl = environment.apiurls;

  ngOnInit(): void {
    /*  this.getsummaryreport();*/
    this.filterdonutbyplant();
    this.getChangeRequests();
    this.fetchDropdownData();

  }
 
  dropdownList: DropdownItem[] = [];
  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  selectedlocationNames: any='';
  impactedLocation: any = '';
  selectedlocation: any = '';
  selectedPlantIds: any[] = [];
  filterdata: any[] = [];
  
  exportToPDF() {
    const doc = new jsPDF.default();
    (doc as any).autoTable({ html: '#excel-table' });
    doc.save('SummaryReport.pdf');
  }

  fileName = 'SummaryReport.xlsx';
  exportexcel(): void {
    let element = document.getElementById('excel-table');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    XLSX.writeFile(wb, this.fileName);

  }


  code: any[] = [];
  changerequest: any[] = [];
  statusList: string[] = ['Open', 'Completed', 'Draft', 'Pending', 'Approved', 'Implemented', 'Released', 'Closure', 'Rejected'];
  getChangeRequests(): void {
    const apiUrl = this.apiurl + '/ViewChangeRequest/ViewChangerequest';
    this.http.get(apiUrl).subscribe(
      (response: any) => {
        this.changerequest = response;
        this.code = [...new Set(response.map((item: any) => item.plantId))];
        console.log("Plant", this.code)
      },
      
      (error) => {
        console.error("Request failed", error);
      }
    );
  }
  mapedplantdatas() {
    this.impactedLocation = this.selectedPlantIds.map((item: any) => item.item_id);
    console.log(this.impactedLocation);
    this.selectedlocationNames = Array.from(new Set(this.impactedLocation));
  }
  filterdonutbyplant() {
    if (this.selectedPlantIds.length > 0) {
      // Extracting item_ids from selectedPlantIds array
      const selectedIds = this.selectedPlantIds.map(item => item.item_id);
      // Filtering this.code based on selectedIds
      this.code = this.changerequest.filter(item => selectedIds.includes(item.plantId));
    } else {
      // If no items are selected, show all items
      this.code = this.changerequest;
    }
    console.log("here is multi donut selected plantid", this.code);
  }
  getStatusCount(status: string, plantId: string): number {
    return this.changerequest.filter(item => item.status.trim() === status && item.plantId === plantId).length;
  }

  getTotalCount(status: string): number {
    return this.changerequest.filter(item => item.status.trim() === status).length;
  }

  getopenCount(_status: string, plantId: string): number {
    return this.changerequest.filter(item => item.status.trim() !== 'Completed' && item.plantId === plantId).length;
  }

  getTotalopen(_status: string): number {
    return this.changerequest.filter(item => item.status.trim() !== 'Completed').length;
  }

  navigateToOtherComponent(plantId: string) {

    this.router.navigate(['/filterdashboard'], { queryParams: { plantId: plantId } });
  }
  navigatecompleted(plantId: string) {
    this.router.navigate(['/filtercompleted'], { queryParams: { plantId: plantId } });
  }
  navigatedraft(plantId: string) {
    this.router.navigate(['/filterdraft'], { queryParams: { plantId: plantId } });
  }
  navigatePending(plantId: string) {
    this.router.navigate(['/filterpending'], { queryParams: { plantId: plantId } });
  }
  navigateApproval(plantId: string) {
    this.router.navigate(['/filterapproval'], { queryParams: { plantId: plantId } });
  }
  navigateImplemented(plantId: string) {
    this.router.navigate(['/filterimplemented'], { queryParams: { plantId: plantId } });
  }
  navigateClosure(plantId: string) {
    this.router.navigate(['/filterclosure'], { queryParams: { plantId: plantId } });
  }
  navigateReleased(plantId: string) {
    this.router.navigate(['/filterrelease'], { queryParams: { plantId: plantId } });
  }
  navigateRejected(plantId: string) {
    this.router.navigate(['/filterrejected'], { queryParams: { plantId: plantId } });
  }







}
