import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import * as XLSX from 'xlsx';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { DatePipe } from '@angular/common';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { debug } from 'console';


interface DropdownItem {
  item_id: number;
  item_text: string;
}
@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrl: './view-task.component.css'
})
export class ViewTaskComponent {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  isVisible = true;
  fileName = 'ExcelSheet.xlsx';

  constructor(private http: HttpClient) {
    this.getviewcrdata()
  }
  private apiurl = environment.apiurls

  ngOnInit(): void {
    this.getplant();

    this.getcategory();
    this.getclassification();
    this.getpriority();
    this.getviewcrdata();
    this.fetchDropdownData();
    this.fetchCategoryData();
  }

  parseAndSortResponse(response: any): any[] {
    let parsedResponse = response.map((item: any) => {
      return item;
    });
    parsedResponse.sort((a: any, b: any) => {
      if (a.itcrid < b.itcrid) {
        return 1;
      }
      if (a.itcrid > b.itcrid) {
        return -1;
      }
      return 0;
    });

    return parsedResponse;
  }

  dropdownList: DropdownItem[] = [];
  dropdowncategroy: DropdownItem[] = [];
  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  fetchCategoryData(): void {
    const apiUrl = this.apiurl + '/Category' // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdowncategroy = data.map(item => ({
          item_id: item.itcategoryId,
          item_text: item.categoryName // Assuming your API response has 'id' and 'name' fields
        }));
        console.log(this.dropdowncategroy);
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }
  selectedlocationNames: any = '';
  selectedcategroy: any = '';
  impactedLocation: any = '';
  selectedlocation: any = '';
  selectedPlantIds: any[] = [];
  selectedCategoryId: any[] = [];
 
  mapedplantdatas() {
    
    this.impactedLocation = this.selectedPlantIds.map((item: any) => item.item_id);
    console.log('Plant',this.impactedLocation)
    this.selectedlocationNames = Array.from(new Set(this.impactedLocation));
  }
  mapedcategoryatas() {

    this.impactedLocation = this.selectedCategoryId.map((item: any) => item.item_id);
    console.log(this.impactedLocation)
    this.selectedcategroy = Array.from(new Set(this.impactedLocation));
  }
  
  rptfilter: any[] = [];

  filtersdata: any[] = [];
  paginatedTableData: any[] = [];
  pageIndex = 0;
  pageSize = 10;
  totalItems = 0;
  onPageChange(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    console.log("Page", this.pageSize)
  }
  getviewcrdata() {
    
    const apiUrls = this.apiurl + '/ViewExecuteReport/GetAllcrexecute';
    const requestBody = {}; // You can include request body if needed
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };

    this.http.get(apiUrls).subscribe(
      (response: any) => {
        // Parse and sort the response before assigning it to viewchangerequest
        /**/
        this.rptfilter = response;

        this.viewchangerequest = this.parseAndSortResponse(this.rptfilter);


        this.totalItems = this.viewchangerequest.length;
        const startIndex = this.pageIndex * this.pageSize;
        const endIndex = startIndex + this.pageSize;
        this.viewchangerequest = this.viewchangerequest.slice(startIndex, endIndex);
        console.log("check support", this.rptfilter);
        /*this.tablevalueshow = false;
        this.function();*/
        return this.viewchangerequest
      },
      (error) => {
        console.error("Get failed", error);
      }
    );
  }

  statusfilter: any;
  plantscode: any = '';
  categoryids: any = '';
  classificationid: any = '';
  prioritytypeid: any = '';
  fromDt: any = '';
  endDt: any = '';
  filterflag: boolean = false;
  today: any;
  searchrfcnumber: any = '';
  viewchangerequest: any[] = [];
 
  filterdropdown() {

    if (this.selectedlocationNames != '') {
      debugger
      
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }
      this.filtersdata = this.rptfilter.filter((item: any) => item.plantId === parseInt(this.selectedlocationNames))

   
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
      console.log("filter in cahage", this.plantscode, this.viewchangerequest)
      
      //return this.viewchangerequest
    }

    if (this.selectedcategroy != '') {
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.itcategoryId === parseInt(this.selectedcategroy))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);


      //return this.viewchangerequest
    }

    if (this.classificationid != '') {
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.itclassificationId === parseInt(this.classificationid))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
     
      //return this.viewchangerequest
    }
    else {
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
  

    }

    if (this.prioritytypeid != '') {

      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.priorityType === parseInt(this.prioritytypeid))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
  

    }

    if (this.searchrfcnumber != '') {

      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crcode === this.searchrfcnumber)
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);


    }

    /* this.filtersdata = this.filtersdata.filter((item: any) => item.crdate > this.fromDt && item.crdate < this.endDt)
     this.filtersdata = this.parseAndSortResponse(this.filtersdata);*/
    if (this.fromDt != '') {
      if (this.endDt == '') this.endDt = this.today;
      //alert('in date cond'+this.filtersdata.length);
      //this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crdate > this.fromDt && item.crdate <= this.endDt)
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);

      //alert('in post cond' + this.fromDt + 'enddt' + this.endDt +'len'+this.filtersdata.length);
    }
    // alert('post prioritytypeid' + this.filtersdata.length)
    if (this.statusfilter != '' && this.statusfilter!=undefined) {
      //this.filterflag = true;
      //alert('v' + this.filtersdata.length + 'value status filter' + this.statusfilter)
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }
      else if (this.statusfilter == 'All') {
        this.filtersdata = this.rptfilter
        this.filtersdata = this.parseAndSortResponse(this.filtersdata);
      

      }
      else {
        this.filtersdata = this.filtersdata.filter((item: any) => item.status === this.statusfilter)
        this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
  

        //alert('v later' + this.filtersdata.length)
      }

    }
    this.totalItems = this.viewchangerequest.length;
    this.viewchangerequest = this.viewchangerequest.slice(this.pageIndex * this.pageSize, (this.pageIndex + 1) * this.pageSize);

    //this.filtersdata = this.rptfilter.filter((item: any) => item.plantcode === parseInt(this.plantscode) || item.itcategoryId === this.categoryids || item.itclassificationId === this.classificationid || item.priorityType === this.prioritytypeid)
    console.log("(filtereddata", this.viewchangerequest)
  }

  // Filter
 
  /**/

  plantcode: any[] = [];

  getplant() {

    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.plantcode = response;
        console.log(this.plantcode)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }


  categorydata: any[] = [];

  getcategory() {

    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response.filter((item: any) => item.supportId === 1);
        console.log("category data test", this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  classificationdata: any[] = [];
  getclassification() {

    const apiUrls = this.apiurl + '/Classification'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.classificationdata = response;
        console.log("classification data test", this.classificationdata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  prioritydata: any[] = [];
  getpriority() {

    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.prioritydata = response;
        console.log("Priority data test", this.prioritydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  exportexcel(): void {
    let element = document.getElementById('excel-table');
    const ws: XLSX.WorkSheet = XLSX.utils.table_to_sheet(element);

    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    XLSX.writeFile(wb, this.fileName);

  }
  toggleVisibility() {
    this.isVisible = !this.isVisible;
}

  exportToPDF() {
    const doc = new jsPDF.default();
    (doc as any).autoTable({ html: '#excel-table' });
    doc.save('table.pdf');
  }
}
