import { Component, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { PasscrdataService } from './passcrdata.service';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
interface DropdownItem {
  item_id: number;
  item_text: string;
}
@Component({
  selector: 'app-change-request',
  templateUrl: './change-request.component.html',
  styleUrl: './change-request.component.css',

})

export class ChangeRequestComponent {
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  selecttable: any;
  supportid: any;
  supportname: any;
  today: any;
  getstatus: any = '';
  crid: any = '';
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private router: Router, private route: ActivatedRoute) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;

    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);
    this.getviewcrdata();
    this.changeapprovers();
    this.getsupportemgineers();

    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value
      this.getstatus = this.crid.status.trim();
    })
  }
  ngOnInit(): void {
    this.loadData();
   
    setTimeout(() => {
      this.getsupportteamassign();
    }, 500);
  }

  loadData() {
    this.getplant();
    this.getclassification();
    this.getcategory();
    this.getviewcrdata();
    //this.filterdropdown();
    //this.useraccess();
    //this.function();
    this.getsupportteams();
    this.getsupportemgineers();
    this.changeapprovers();
    this.getpriority();
    this.fetchDropdownData();
    this.fetchCategoryData();
  }

  private apiurl = environment.apiurls

  /*toggleVisibility() {
    this.isVisible = !this.isVisible;
  }
*/
  parseAndSortResponse(response: any): any[] {
    let parsedResponse = response.map((item: any) => {
      return item;
    });
    parsedResponse.sort((a: any, b: any) => {
      if (a.itcrid < b.itcrid) {
        return 1;
      }
      if (a.itcrid > b.itcrid) {
        return -1;
      }
      return 0;
    });
    return parsedResponse;
  }
  supportteam: any[] = [];
  crfilter: any[] = [];

  paginatedTableData: any[] = [];
  pageIndex = 0;
  pageSize = 10;
  totalItems = 0;
  rptfilter: any = '';
  getviewcrdata() {
    //
    const apiUrls = this.apiurl + '/ViewChangeRequest/ViewChangerequest';
    const requestBody = {}; // You can include request body if needed
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };

    this.http.get(apiUrls).subscribe(
      (response: any) => {
        console.log('New:', this.supportid, response);
        //this.crfilter = response.filter((item: any) => item.changeRequestor === parseInt(this.supportid));
        this.rptfilter = response.filter((item: any) => item.changeRequestor === parseInt(this.supportid));
        //this.viewchangerequest = response.filter((item: any) => item.changeRequestor === parseInt(this.supportid));
        this.filtersdata = this.parseAndSortResponse(this.rptfilter);
        this.totalItems = this.rptfilter.length;
        const startIndex = this.pageIndex * this.pageSize;
        const endIndex = startIndex + this.pageSize;
        this.viewchangerequest = this.filtersdata.slice(startIndex, endIndex);
        console.log("check support", this.rptfilter);
        /*this.tablevalueshow = false;
        this.function();*/
        return this.rptfilter
      },
      (error) => {
        console.error("Get failed", error);
      }
    );
  }

  onPageChange(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    console.log("Page", this.pageSize)
    this.getviewcrdata();
  }

  statusfilter: any;
  
  plantscode: any = '';
  categoryids: any = '';
  classificationid: any = '';
  prioritytypeid: any = '';
  fromDt: any = '';
  endDt: any = '';
  filterflag: boolean = false;
  searchrfcnumber: any = '';
  viewchangerequest: any[] = [];

  filtersdata: any[] = [];

  dropdownList: DropdownItem[] = [];
  dropdowncategroy: DropdownItem[] = [];
  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  fetchCategoryData(): void {
    const apiUrl = this.apiurl + '/Category' // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdowncategroy = data.map(item => ({
          item_id: item.itcategoryId,
          item_text: item.categoryName // Assuming your API response has 'id' and 'name' fields
        }));
        console.log(this.dropdowncategroy);
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }
  selectedlocationNames: any = '';
  selectedcategroy: any = '';
  impactedLocation: any = '';
  selectedlocation: any = '';
  selectedPlantIds: any[] = [];
  selectedCategoryId: any[] = [];
  mapedplantdatas() {

    this.impactedLocation = this.selectedPlantIds.map((item: any) => item.item_id);
    console.log('Plant:', this.impactedLocation)
    this.selectedlocationNames = Array.from(new Set(this.impactedLocation));
  }
  filterdonutbyplant() {
    if (this.selectedlocationNames != '') {
      this.viewchangerequest = this.viewchangerequest.filter((item: any) => this.selectedlocationNames.includes(item.plantcode));
    }
    console.log("here is multi donut selected plantid", this.viewchangerequest)
  }
  mapedcategoryatas() {

    this.impactedLocation = this.selectedCategoryId.map((item: any) => item.item_id);
    console.log(this.impactedLocation)
    this.selectedcategroy = Array.from(new Set(this.impactedLocation));
  }
  filterdropdown() {
   // this.viewchangerequest = [];
    this.filtersdata = [];
    
    if (this.selectedlocationNames != '') {
      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter;
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.plantcode === parseInt(this.selectedlocationNames))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);

      console.log("filter in chage", this.selectedlocationNames, this.viewchangerequest)
      
    }
    
    
    if (this.selectedcategroy != '') {
      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.parseAndSortResponse(this.rptfilter)
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.itcategoryId === parseInt(this.selectedcategroy))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
     }
    
    if (this.classificationid != '') {
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.itclassificationId === parseInt(this.classificationid))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);

      //return this.viewchangerequest
    }
    else {
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);


    }

    if (this.prioritytypeid != '') {

      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.priorityType === parseInt(this.prioritytypeid))
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);


    }

    if (this.searchrfcnumber != '') {

      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crcode === this.searchrfcnumber)
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);


    }


    if (this.fromDt != '') {
      if (this.endDt == '') this.endDt = this.today;

      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crdate > this.fromDt.trim() && item.crdate <= this.endDt.trim())
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);

    }

    if (this.endDt != '' && this.fromDt == '') {
      if (this.fromDt == '') this.fromDt = this.endDt;

      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter

      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crdate > this.fromDt && item.crdate <= this.endDt)
      this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);

    }

    if (this.statusfilter != '' && this.statusfilter != undefined) {
      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.rptfilter
      }

      if (this.statusfilter == 'All') {
        this.filtersdata = this.rptfilter
        this.filtersdata = this.parseAndSortResponse(this.filtersdata);
      }
      else { 
        this.filtersdata = this.filtersdata.filter((item: any) => item.status === this.statusfilter)
        this.viewchangerequest = this.parseAndSortResponse(this.filtersdata);
      }

    }
        
    this.totalItems = this.viewchangerequest.length;
    this.viewchangerequest = this.viewchangerequest.slice(this.pageIndex * this.pageSize, (this.pageIndex + 1) * this.pageSize);

    console.log("(filtereddata", this.viewchangerequest)
  }

  updatecr(itcrid: number): void {
    this.router.navigate(['/updatecr', itcrid]);
  }

  plantcode: any[] = [];

  getplant() {

    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.plantcode = response;
        console.log(this.plantcode)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  classifications: any[] = [];

  getclassification() {

    const apiUrls = this.apiurl + '/Classification'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.classifications = response;
        console.log(this.classifications)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorydata: any[] = [];

  getcategory() {
    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response;
        console.log(this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  prioritydata: any[] = [];
  getpriority() {

    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.prioritydata = response;
        console.log("Priority data test", this.prioritydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  selectradio: any = '';
  
 
  gotoapprove(tabId: string) {
    // alert('selected radio' + this.selectradio + 'itcrid ' + this.selectradio.itcrid )
    if (this.selectradio!='') {
      const itcrid = this.selectradio.itcrid;
      this.router.navigate([`/executive/${itcrid}/edit`], { fragment: tabId });
      setTimeout(() => {
        const tabButton = document.getElementById(tabId + '-tab');
        if (tabButton) {
          tabButton.click();
        }
      });
      this.approvepage();
    } else {

      alert('Select the RFC');
      console.error("No itcrid found in selectradio.");
    }
  }

  approvepage() {
    const report = {
      value: this.selectradio
    }
    this.routeservice.changerequestdata({ report })
  }

  updatepage() {
    const report = {
      value: this.selectradio
    }
    this.routeservice.changerequestdata({ report })
  }

  goToTab(tabId: string) {
    //alert('this.selectradio' + this.selectradio)
    if (this.selectradio=='') {
        alert("Select the RFC")
      }
    else {
      //alert('itcrid' + this.selectradio.itcrid + 'tab id' + tabId);
        const itcrid = this.selectradio.itcrid;
        this.router.navigate([`/executive/${itcrid}/edit`], { fragment: tabId });
        setTimeout(() => {
          
          this.excutepage();
        },1000);
        
      }

  }

  

  excutepage() {
    const report = {
      value: this.selectradio
    }
   // alert('excutepage' + this.selectradio)
    this.routeservice.changerequestdata({ report })
  }
    
  onRadioSelect(row: any): void {
    this.selectradio = row;
    this.routeservice.setSelectedRadio(JSON.stringify(row));
    console.log("value from radio button", this.selectradio)
    
  }

  onRadio(row: any): void {
    //alert('row' + row)
    this.selectradio = row;
    this.routeservice.setSelectedRadio(JSON.stringify(row));
    console.log("value from radio button", this.selectradio)
    this.updatepage();
    //Made Changes
    if (this.getstatus == 'Rejected') {
      alert('Change Request was rejected. Please check History for details');
      const actvFlg = { activeFlg: 'false' }
      this.routeservice.getCRRejectData({ actvFlg })
      this.router.navigate(['/executive/' + this.crid.itcrid + '/edit']);
    }
    else if (this.getstatus !== 'Rejected') {
      const actvFlg = { activeFlg: 'true' }
      this.routeservice.getCRRejectData({ actvFlg })
    }
  }

  supportengineers: any[] = [];
  filterexecutdata: any[] = [];
  supportteamcode: any = '';

  paginatedTableDataforsupport: any[] = [];
  pageIndexforsupport = 0;
  pageSizeforsupport = 10;
  totalItemsforsupport = 0;

  onPageChangeforsupport(event: PageEvent) {
    this.pageIndexforsupport = event.pageIndex;
    this.pageSizeforsupport = event.pageSize;
    this.getsupportemgineers();
  }

  getsupportemgineers() {
    const apiUrls = this.apiurl + '/VwSupportEngineer'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportengineers = response;
        this.supportengineers = response.filter((item: any) => item.assgigntome === parseInt(this.supportid));
        
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers);
        this.filterexecutdata = this.filterexecutdata.filter((value: any, index: any, self: any) => self.indexOf(value) === index)
        console.log("getting supportteam id", this.supportid)

        this.totalItemsforsupport = this.filterexecutdata.length;
        this.filterexecutdata = this.filterexecutdata.slice(this.pageIndexforsupport * this.pageSizeforsupport, (this.pageIndexforsupport + 1) * this.pageSizeforsupport);

      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  filtersupportengineer() {
    if (this.selectedlocationNames != '') {
      this.filterflag = true;

      if (this.filterexecutdata.length == 0) {
       this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)
      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.plantcode === parseInt(this.selectedlocationNames))
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
      console.log("filter in cahage", this.plantscode, this.filterexecutdata)
    
    }

    if (this.selectedcategroy != '') {
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)
      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.itcategoryId === parseInt(this.selectedcategroy))
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
    }

    if (this.classificationid != '') {
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)
      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.itclassificationId === parseInt(this.classificationid))
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
      //alert('categoryids : ' + this.categoryids + 'lrn bf' + this.filtersdata.length)
    }



    if (this.prioritytypeid != '') {
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)

      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.priorityType === parseInt(this.prioritytypeid))
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);

    }
   
    if (this.searchrfcnumber != '') {
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)

      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.crcode === this.searchrfcnumber.trim())
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
     
    }

    if (this.fromDt != '') {
      if (this.endDt == '') this.endDt = this.today;
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)

      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.crdate > this.fromDt && item.crdate <= this.endDt)
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
    }

    if (this.endDt != '' && this.fromDt == '') {
      this.fromDt = this.endDt;
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)

      }
      this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.crdate > this.fromDt && item.crdate <= this.endDt)
      this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
      
    }
    if (this.statusfilter != '' && this.statusfilter != undefined) {
      this.filterflag = true;
      if (this.filterexecutdata.length == 0) {
        this.filterexecutdata = this.parseAndSortResponse(this.supportengineers)
      }

      if (this.statusfilter == 'All') {
        this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
      }
      else {
        this.filterexecutdata = this.filterexecutdata.filter((item: any) => item.status === this.statusfilter)
        this.filterexecutdata = this.parseAndSortResponse(this.filterexecutdata);
   
      }
      
    }
    this.totalItems = this.filterexecutdata.length;
    this.filterexecutdata = this.filterexecutdata.slice(this.pageIndex * this.pageSize, (this.pageIndex + 1) * this.pageSize);

    console.log("(filterexecutdata", this.filterexecutdata)
  }

  supporassignto: any;
  supportenginer() {
    this.supporassignto = this.supportengineers.filter((item: any) => item.assgigntome === parseInt(this.supportid) && item.status !== 'Completed');
  }

  isengineerasign: boolean = false;
  allengineer: boolean = true;
  assigenttobutton() {
    this.isengineerasign = true
    this.allengineer = false
    this.supportenginer()
  }

  //Login User
  supportteams: any[] = [];
  getsupportid: any;

  getsupportteams() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log('checkResponse:', response);
        for (var i of response) {
          if (i.empId == parseInt(this.supportid)) {
            this.getsupportid = i.supportTeamId;
            console.log(this.getsupportid);
          }
        }
        /*this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid));
        
        console.log("getting supportteam id", this.supportteams)
        this.getsupportid = this.supportteams[0].designation*/
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  supportteamassign: any[] = [];
  isapprover: any;
  isassignappbutton: any;
  ischangeanalyst: any;
  issupportegineer: any;
  issupegineerasignbtn: any;
  supportcatid: any;
  supportcalid: any;
  supportplantid: any;

  getsupportteamassign() {
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("supportteamassigned",response);
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === parseInt(this.getsupportid));
        this.isapprover = this.supportteamassign[0].isApprover
        this.isassignappbutton = this.supportteamassign[0].isApprover
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.issupegineerasignbtn = this.supportteamassign[0].isSupportEngineer
        this.supportcatid = this.supportteamassign[0].categoryId
        this.supportcalid = this.supportteamassign[0].classificationId
        this.supportplantid = this.supportteamassign[0].plantId
        console.log("geting support asigned id", this.issupportegineer)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.supportadmin();
    }, 1000);
  }

  


  navigateinprogress() {
    this.deleteinprogress = false;
  }

  issuperadmin: boolean = false;
  supportadmin() {
    if (this.isapprover == true && this.ischangeanalyst == true && this.issupportegineer == true) {
      this.issuperadmin = true;
      this.issupegineerasignbtn = false;
      this.isassignappbutton = false;
    }
  }

  supportbtnadmin() {
    this.filterdropdown();
    this.filtersupportengineer();
    this.isassignbutton();
    this.assigenttobutton();
  }

  changeapprover: any[] = [];
  filtersapprvdata: any[] = [];

  paginatedTableDataforapprover: any[] = [];
  pageIndexforapprover = 0;
  pageSizeforapprover = 10;
  totalItemsforapprover = 0;


  onPageChangeforapprover(event: PageEvent) {
    this.pageIndexforapprover = event.pageIndex;
    this.pageSizeforapprover = event.pageSize;
    this.changeapprovers();
  }
  changeapprovers() {
    const apiUrls = this.apiurl + '/VwApproverCR'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.changeapprover = response;
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover);

        this.totalItemsforapprover = this.changeapprover.length;
        this.filtersapprvdata = this.filtersapprvdata.slice(this.pageIndexforapprover * this.pageSizeforapprover, (this.pageIndexforapprover + 1) * this.pageSizeforapprover);

      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  onclickfilter() {
    //this.resetfn();
    if (this.ischangeanalyst && this.isapprover && this.issupportegineer) {
      this.filterdropdown();
      setTimeout(() => {
        this.filtersupportengineer();
      }, 500);
      setTimeout(() => {
        this.filterapprover();
      }, 500);
      
    }
    else if (this.isapprover) {
      //this.filtersapprvdata = [];
      this.filterapprover();
    }
    else if (this.issupportegineer) {
      this.filtersupportengineer();
    }
    else { this.filterdropdown(); }
    
  }
  
  filterapprover() {

    if (this.selectedlocationNames != '') {
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)
      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.plantcode === parseInt(this.selectedlocationNames))
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
      console.log("filter in cahage", this.plantscode, this.filtersapprvdata)

    }


    if (this.selectedcategroy != '') {
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)
      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.itcategoryId === parseInt(this.selectedcategroy))
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
    }

    if (this.classificationid != '') {
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)
      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.itclassificationId === parseInt(this.classificationid))
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
      //alert('categoryids : ' + this.categoryids + 'lrn bf' + this.filtersdata.length)
    }

    if (this.prioritytypeid != '') {
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)

      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.priorityType === parseInt(this.prioritytypeid))
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);

    }

    if (this.searchrfcnumber != '') {
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)

      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.crcode === this.searchrfcnumber.trim())
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);

    }

    if (this.fromDt != '') {
      if (this.endDt == '') this.endDt = this.today;
      //alert('in date cond'+this.filtersdata.length);
      this.filterflag = true;
      if (this.filtersapprvdata.length == 0) {
        this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)

      }
      this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.crdate > this.fromDt && item.crdate <= this.endDt)
      this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
      //alert('in post cond' + this.fromDt + 'enddt' + this.endDt +'len'+this.filtersdata.length);
    }
     if (this.statusfilter != '' && this.statusfilter !=undefined) {
      this.filterflag = true;
       if (this.filtersapprvdata.length == 0) {
         this.filtersapprvdata = this.parseAndSortResponse(this.changeapprover)
      }

       if (this.statusfilter == 'All') {
         this.filtersapprvdata = this.crfilter
         this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
      }
      else {
         this.filtersapprvdata = this.filtersapprvdata.filter((item: any) => item.status == this.statusfilter)
         this.filtersapprvdata = this.parseAndSortResponse(this.filtersapprvdata);
        //alert('v later' + this.filtersdata.length)
      }
    }
    
    this.totalItemsforapprover = this.filtersapprvdata.length;
    this.filtersapprvdata = this.filtersapprvdata.slice(this.pageIndexforapprover * this.pageSizeforapprover, (this.pageIndexforapprover + 1) * this.pageSizeforapprover);

   console.log("(filtereddata", this.changeapprover)
  }
  
  isassigntome: any[] = [];
  
  gettingassigntome() {
    debugger;
    this.isassigntome = this.changeapprover.filter((item: any) => item.approver1 === parseInt(this.getsupportid) || item.approver2 === parseInt(this.getsupportid) || item.approver3 === parseInt(this.getsupportid));
    this.isassigntome = this.isassigntome.filter((item: any) => (item.status.trim() !== "Approved") && (item.status.trim() !== "Completed"));
    this.isassigntome = this.parseAndSortResponse(this.isassigntome);


    
   }

  allcrdata: boolean = true;
  assignedtodata: boolean = false;
  isassignbutton() {
   
    this.gettingassigntome();
    this.allcrdata = false;
    this.assignedtodata = true;
  }


  resetfn() {
    this.statusfilter='';
    this.plantscode='';
    this.categoryids='';
    this.classificationid= '';
    this.prioritytypeid  = '';
    this.fromDt = '';
    this.endDt = '';
    this.searchrfcnumber = '';
    this.filterflag= false;
    if (this.isapprover) {
      this.changeapprovers();
      this.allcrdata = true;
      this.assignedtodata = false;
    }
    else if (this.issupportegineer) {
      this.getsupportemgineers();
      this.isengineerasign = false;
      this.allengineer = true;
    }
    else {
      this.getviewcrdata();
    }
  }

  checkAccess() {
    if (this.isapprover || this.issupportegineer) {
      window.alert("You don't have access to new requests.");
    }
  }
  deleteconfirmation: boolean = false;
  deletesupportid: any;
  deletesupportassignid: any;
  deleteempid: any;
  deletespassign: any;
  deleteplantid: any;
  deletecategoryid: any;
  deleteclassificationid: any;
 
  deleteinprogress: Boolean = false;
  deleteinmessage: any = '';
  deletecrid: any = '';
  
  deleteRow(crid:any) {
    this.deletecrid = crid

/*    this.deleteempid = employeeid

    this.deleteplantid = plantid
    this.deletecategoryid = categoryid
    this.deleteclassificationid = classificationid
    this.deletesupportassignid = supporteamassignid

    this.isapprover = isapprover*/

    this.deleteconfirmation = true
    /*setTimeout(() => {
      this.deleteSupportTeam()
    }, 500);*/

  }

  deleteyes() {
    this.deleteconfirmation = false
    this.deleteSupportTeam()
  }

  deleteno() {
    this.deleteconfirmation = false
  }

  
  deletesuccess: boolean = false;
  deletemessage: any = '';
   messageerror: boolean = false;
  errormessage: any;
  errorresponse: any;
  deleteSupportTeam() {
    
    const apiUrl = this.apiurl + "/ChangeRequest/InsertChangeRequest";
    const requestBody = {
      "type": "D",
      "itcrid": this.deletecrid,
      "supportId": 0,
      "classifcationId": 0,
      "categoryId": 0,
      "categoryTypeId": 0,
      "crowner": 0,
      "crdate": "2024-05-22T17:43:44.652Z",
      "crrequestedBy": 0,
      "crrequestedDt": "2024-05-22T17:43:44.652Z",
      "crinitiatedFor": 0,
      "status": "Cancelled",
      "referenceId": 0,
      "referenceTyp": 0,
      "natureOfChange": 0,
      "priorityType": 0,
      "plantId": 0,
      "gxpclassification": true,
      "gxpplantId": 0,
      "changeControlNo": "string",
      "changeControlDt": "2024-05-22",
      "changeControlAttach": true,
      "changeDesc": "string",
      "reasonForChange": "string",
      "alternateConsidetation": "string",
      "impactNotDoing": "string",
      "businessImpact": "string",
      "triggeredBy": "string",
      "benefits": "string",
      "estimatedCost": 0,
      "estimatedCostCurr": "string",
      "estimatedEffort": 0,
      "estimatedEffortUnit": "string",
      "estimatedDateCompletion": "2024-05-22",
      "rollbackPlan": "string",
      "backoutPlan": "string",
      "downTimeRequired": true,
      "downTimeFromDate": "2024-05-22T17:43:44.653Z",
      "downTimeToDate": "2024-05-22T17:43:44.653Z",
      "impactedLocation": "string",
      "impactedDept": "string",
      "imactedFunc": "string",
      "isSubmitted": true,
      "isApproved": true,
      "isImplemented": true,
      "isReleased": true,
      "createdBy": this.supportid
    };
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    setTimeout(() => {
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log("this is error response", response);
          this.errorresponse = response.type
          if (this.errorresponse == "E") {
            this.deleteinprogress = true;
            this.deleteinmessage = "There are open items it Can't be deleted"
          } else if (this.errorresponse == "S") {
            this.deletesuccess = true;
            this.deletemessage = "Change Request ID: "+this.deletecrid+" Deleted Successfully"
          } 
        },
        (error: any) => {
          console.log('Post request failed', error);
          this.messageerror = true;
          this.errormessage = error;
        }
      );
    }, 500);
  }

  navigatesuccess() {
    this.deletesuccess = false;
    window.location.reload();
  }  
  

}

function round(): number {
    throw new Error('Function not implemented.');
}
