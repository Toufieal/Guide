import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { PasscrdataService } from '../../passcrdata.service';
import { ActivatedRoute,Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-releaser',
  templateUrl: './releaser.component.html',
  styleUrl: './releaser.component.css'
})
export class ReleaserComponent {

 showInitiator: boolean = false;
  showRiskQ: boolean = false;
  tabs: any[] = [];
  numberOfTabs: number = 1;
  plantData: any[] = [];
  status: any = '';
  approver: any = '';
  appdate: any = '';
  attach: any = '';
  remark: any = '';
  comment: any = '';
  crid: any = '';
  today: any;
  currentdate: any;
  itcrid: any;
  appstatus: any;
  supportid: any;
  stage: any;
  isRelease: any = '';
  appflag:boolean =false;
  APILevel: Number = 1;
  isReadOnly: boolean = false;
  isReadOnly2: boolean = false;
  isReadOnly3: boolean = false;
  rfcapproverlevel: string = '';
  isApproved: any;
  isReleased: any;
  categoryId: any = '';
  selectedOption: string = '';
  classificationId: any = '';
  approveflag: boolean = true;
  isSupport: boolean = true;
  supportname: any;
  crownername: any;
  getcrid: any[] = [];
  getcrcode: string = '';
  plantidforapp: any = ' ';
  date: any = ' ';
  currentday: any = ' ';
  constructor(private http: HttpClient,private router:Router, private routeservice: PasscrdataService, private route: ActivatedRoute) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value;
      this.itcrid = parseInt(this.crid.itcrid);
      this.appstatus = this.crid.status.trim();
      this.status = this.crid.status.trim();
      this.stage = this.crid.stage.trim();
      this.crownername = this.crid.crowner;
      this.isApproved = this.crid.isApproved;
      this.isReleased = this.crid.isReleased;
      this.categoryId = this.crid.itcategoryId;
      this.classificationId = this.crid.itclassificationId;
      this.plantidforapp = this.crid.plantcode;
      
    })
    
    this.Approver(1);
    this.Approver1();
    this.getsupportteams();
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    console.log('release supportid', this.supportid);
    this.supportname = this.routeservice.supporterName;
    const currentDate = new Date()
    const datePart = currentDate.toISOString().slice(0, 10);
    const timePart = currentDate.getHours().toString().padStart(2, '0') + ':' +
      currentDate.getMinutes().toString().padStart(2, '0') + ':' +
      currentDate.getSeconds().toString().padStart(2, '0');
    this.date = `${datePart} ${timePart}`;
    this.currentday = `${datePart} ${timePart}`;
    this.today = currentDate.toISOString().slice(0, 10);
    this.currentdate = currentDate.toISOString().slice(0, 10);
    this.routeservice.crdata.subscribe(data => {
      this.getcrid = [data.report];
    })
    this.getcrcode = this.getcrid[0].value.crcode;
    this.getData();
  }
  tab1: boolean = true;

  showfunction() {
    this.supportid == 2;
    if (this.supportid == 2) {
      this.tab1 = true;
    }
  }

  ImplementedStatus() {
    //this.getdata('Implemented');
    //alert('count' + this.approverCount)
    if (this.stage == "Implementation") {
      if (this.appstatus == "Implemented") {
        this.Approver1();
        

        if (this.approverCount == 2) {
          this.Approver2();
        }

        if (this.approverCount == 3) {
          this.Approver2();
          this.Approver3();
         }
        //alert('Apli approver2tab' + this.approver2tab + 'this.status' + this.status + 'aapv count +'+this.approverCount)
      }
    }
  }
  
  StageStatus() {
    if (this.isReleased) {
      this.Approver1();
 
      if (this.approverCount == 2) {
        this.Approver2();
      }

      if (this.approverCount == 3) {
        this.Approver2();
        this.Approver3();
       }
    }
    if (this.appstatus == "Implemented") {
       
      this.Approver1();
      
      if (this.approverCount == 2) {
        this.Approver2();
       }

      if (this.approverCount == 3) {
        this.Approver2();
        this.Approver3();
        }
      }

    if (this.stage == "Release") {
      if (this.appstatus == "Approved") {
        this.Approver1();
          
        if (this.approverCount == 2) {
          this.Approver2();
         }

        if (this.approverCount == 3) {
          this.Approver2();
          this.Approver3();
        }
      }
      if (this.appstatus == "Approved level1") {
          this.Approver1();
          this.Approver2();
       
        if (this.approverCount == 3) {
          this.Approver3();
        }
      }

      if (this.appstatus == "Approved level2") {
         this.Approver1();
        this.Approver2();
        this.Approver3();
        }
      }
    }
  

  selectedTab: number = 0;
  count: any;
  // Method to show the selected tab
  showTab(index: number) {
    this.selectedTab = index;
  }

  approver1Name: String = '';
  approver2Name: String = '';
  approver3Name: String = '';

  ngOnInit(): void {
    this.getidupdate();
    this.getapprovestatus();
    this.getsupportteams();
    this.getupdatyevalue();
    this.getapprdtls(1);
    this.getrequetervalue(this.crid.itcrid);
    this.getapproverslevel();
    this.usersupportteams();
    this.getcrdata();
    this.getreleasedata();
    setTimeout(() => {
      this.getsupportteamassign();
      this.GetApprover(1);
      this.crrequestors();
      //this.ImplementedStatus();
      //this.StageStatus();
    }, 1000);
   
        
  }
  private apiurl = environment.apiurls;

  handleFileInput(event: any, index: number) {
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }
  activetab(tabval: any) {
    if (tabval == 'R' && this.isApproved) {
      alert("Please complete approval to release.");
      //this.release1tab.active=false;
    }
  }
  getidupdate() {

    this.itcrid = this.route.snapshot.paramMap.get('id');
  }//ff


  approverdata: any[] = [];
  data = 2; // Or any value you want
  approvers: any[] = [];


  initializeApprovers() {

  }

  counter(i: number) {
    return new Array(i);
  }
 
  
  activeTab: number = 1; // Default to the first tab being active

  supportpersonname: any = ''
  firstname: any = ''
  middlename: any = ''
  lastname: any = ''
  employeeid: any = ''

  supportteams: any[] = []
  usersupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("SupportId:", this.supportid)
        this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
        this.employeeid = this.supportteams[0].empId;
        this.firstname = this.supportteams[0].firstName;
        this.middlename = this.supportteams[0].middleName;
        this.lastname = this.supportteams[0].lastName;
        /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;

        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }


      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  crval: any[] = [];
  crrname: any = '';
  croname: any = '';
  crrempid: any = '';
  croempid: any = '';
  crempid: any = '';
  cremail: any = '';
  ischangeowner: boolean = false
  getcrinfo(empid: Number, person: string) {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        this.crval = response.filter(item => item.empId === empid)

        if (person == 'cro') {
          this.croname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.croemail = this.crval[0].email
         
          if (empid==parseInt(this.supportid)) {
            this.ischangeowner = true;
            
          }
        }
        else {
          this.crrname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.crremail = this.crval[0].email
        }
        // alert('crr email' + this.crremail + 'emp id' + this.crrempid)
        // alert('cro email' + this.croemail + 'emp id' + this.crrempid)
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }
  releaseval: any[] = [];
  releasecmts: any = '';
  releasedt: any = '';
  attachmentfile: any = '';
  getreleasedata() {
    const apiUrls = this.apiurl + '/CRrelease/GetRelease'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.releaseval = response.filter((item: any) => item.itcrid === Number(this.crid.itcrid))
        console.log('cr release info', this.releaseval)
        this.releasecmts = this.releaseval[0].releaseComments
        this.releasedt = this.releaseval[0].releasedt
        this.attachmentfile = this.releaseval[0].attachments
        //alert('this.attach' + this.attachmentfile);
        this.releaseComments = this.releaseval[0].releaseComments

        setTimeout(() => {
          this.getcrinfo(this.crrempid, 'cro');

          //CR Owner name ad email
          this.getcrinfo(this.croempid, 'crr');

        }, 1000);
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  croemailid: any = ''
  crdate: any = ''
  crrdate: any = ''
  crdesc: any = ''
  emailCR: any[] = []

  getcrdata() {
    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.emailCR = response.filter((item: any) => item.itcrid === Number(this.crid.itcrid))
        console.log('cr info', this.emailCR)
        this.crrempid = this.emailCR[0].crrequestedBy
        this.croempid = this.emailCR[0].crowner
        this.crdate = this.emailCR[0].crdate
        this.crrdate = this.emailCR[0].crrequestedDt
        this.crdesc = this.emailCR[0].changeDesc
        this.plantid = this.emailCR[0].plantId

        setTimeout(() => {
          this.getcrinfo(this.crrempid, 'crr');

          //CR Owner name ad email
          this.getcrinfo(this.croempid, 'cro');

        }, 1000);
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  crremail: any = '';
  croemail: any = '';
  crrequestedBy: any = '';

  approver1N: any = ''
  approver2N: any = ''
  approver3N: any = ''
  approver1: any = ''
  approver2: any = ''
  approver3: any = ''
  plantid: any = ''
  appv: any[] = []
  apprv1email: any = ''
  apprv2email: any = ''
  apprv3email: any = ''

  emailapproversinfo(status: string) {
    const apiUrl = this.apiurl + '/GetApproverforEmail/GetApproverEmail';
    const requestBody = {
      "stage": "R",
      "plantid": Number(this.plantidforapp),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('email conut', response)
        //  alert('respn' + response.length)
        this.appv = response
      });
    setTimeout(() => {
      this.sendemailfrom(status, this.appv);
    }, 1000);

    if (status == 'Released') {
      setTimeout(() => {
        this.closureemailapproversinfo();
      }, 1000)
    }
  }

  closureappv: any[] = [];

  closureemailapproversinfo() {
    const apiUrl = this.apiurl + '/GetApproverforEmail/GetApproverEmail';
    const requestBody = {
      "stage": "C",
      "plantid": Number(this.plantidforapp),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('email conut', response)
        //  alert('respn' + response.length)
        this.closureappv = response
      });
    setTimeout(() => {
      this.sendemailfrom('Closure', this.closureappv);

    }, 1000);
  }
  appr: any[] = []
  appemail: any = ''

  approver11: any = ''
  approver21: any = ''
  approver31: any = ''
  approver12: any = ''
  approver22: any = ''
  approver32: any = ''
  approver13: any = ''
  approver23: any = ''
  approver33: any = ''

  approver11Name: any = ''
  approver21Name: any = ''
  approver31Name: any = ''
  approver12Name: any = ''
  approver22Name: any = ''
  approver32Name: any = ''
  approver13Name: any = ''
  approver23Name: any = ''
  approver33Name: any = ''
  approver1Names: any = ''
  approver2Names: any = ''
  approver3Names: any = ''
  apprv11email: any = ''
  apprv21email: any = ''
  apprv31email: any = ''
  apprv12email: any = ''
  apprv22email: any = ''
  apprv32email: any = ''
  apprv13email: any = ''
  apprv23email: any = ''
  apprv33email: any = ''
  approver1Emails: any = ''
  approver2Emails: any = ''
  approver3Emails: any = ''
  to: any = '';
  to1: any = '';
  to2: any = '';
  to3: any = '';
  cc1: any = '';
  cc2: any = '';
  cc3: any = '';
  cc4: any = '';
  cc5: any = '';
  approverlevelstatus1: any = ''
  approverlevelstatus2: any = ''
  approverlevelstatus3: any = ''
  subjecttxt: any = '';
  populatedOutput: any = '';
  crowner: any = '';
  submitby: any = '';
  crrequestedby: any[] = [];
  setcreniatorname: any;
  approver1NamesR: any = '';
  approver2NamesR: any = '';
  approver3NamesR: any = '';
  appname: any = '';
  crrequestors() {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }

    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.crrequestedby = response.filter((item: any) => item.empId === this.updatevalue[0].crrequestedBy);
        this.setcreniatorname = this.crrequestedby[0].empId + "-" + this.crrequestedby[0].firstName + " " + this.crrequestedby[0].lastName
        this.crremail = this.crrequestedby[0].email;
        this.crrequestedBy = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
        this.crowner = response.filter((item: any) => item.empId === this.updatevalue[0].crowner);
        this.submitby = this.crowner[0].firstName + " " + this.crowner[0].middleName + " " + this.crowner[0].lastName

      },

      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  sendemailfrom(emailreq: string, appv: any[]) {
    const apiUrl = this.apiurl + '/Email'
    this.approver11 = appv[0].approver1;
    this.approver11Name = appv[0].approver1Name;
    this.apprv11email = appv[0].approver1Email;
    if (appv[0].empid1 != '' && appv[0].empid1 != undefined) {
      this.approver1Names = this.approver11Name + '(' + appv[0].empid1 + ')'
      this.approver1Emails = ', ' + this.apprv11email
    }
    else { this.approver11Name = '' }

    this.approver21 = appv[0].approver2
    this.approver21Name = appv[0].approver2Name;
    this.apprv21email = appv[0].approver2Email;
    console.log('appv[0]', this.appv);
    if (appv[0].empid2 != '' && appv[0].empid2 != undefined) {
      this.approver1Names += ", <br> "
      this.approver1Names += this.approver21Name + '(' + appv[0].empid2 + ')'
      this.approver1Emails += ", " + this.apprv21email
    }
    else { this.approver21Name = '' }

    this.approver31 = appv[0].approver3;
    this.approver31Name = appv[0].approver3Name;
    this.apprv31email = appv[0].approver3Email;
    if (appv[0].empid3 != '' && appv[0].empid3 != undefined) {
      this.approver1Names += ', <br>' + this.approver31Name + '(' + appv[0].empid3 + ')'
      this.approver1Emails += ', ' + this.apprv31email
    }
    else { this.approver31Name = '' }
    //second Level
    this.approver12 = appv[1].approver1;
    this.approver12Name = appv[1].approver1Name;
    this.apprv12email = appv[1].approver1Email;
    if (appv[1].empid1 != '' && appv[1].empid1 != undefined) {
      this.approver2Names = this.approver12Name + '(' + appv[1].empid1 + ')'
      this.approver2Emails += ', ' + this.apprv12email
    }
    this.approver22 = appv[1].approver2;
    this.approver22Name = appv[1].approver2Name;
    this.apprv22email = appv[1].approver2Email;
    if (appv[1].empid2 != '' && appv[1].empid2 != undefined) {
      this.approver2Names += ', <br>' + this.approver22Name + '(' + appv[1].empid2 + ')'
      this.approver2Emails += ', ' + this.apprv22email
    }
    this.approver32 = appv[1].approver3;
    this.approver32Name = appv[1].approver3Name;
    this.apprv32email = appv[1].approver3Email;
    if (appv[1].empid3 != '' && appv[1].empid3 != undefined) {
      this.approver2Names += ', <br>' + this.approver32Name + '(' + appv[1].empid3 + ')'
      this.approver2Emails += ', ' + this.apprv32email
    }
    else { this.approver32Name = '' }

    //Thrid Level
    this.approver13 = appv[2].approver1;
    this.approver13Name = appv[2].approver1Name;
    this.apprv13email = appv[2].approver1Email;
    if (appv[2].empid1 != '' && appv[2].empid1 != undefined) {
      this.approver3Names = this.approver13Name + '(' + appv[2].empid1 + ')'
      this.approver3Emails += ', ' + this.apprv13email
    } else { this.approver13Name = '' }

    this.approver23 = appv[2].approver2;
    this.approver23Name = appv[2].approver2Name;
    this.apprv23email = appv[2].approver2Email;
    if (appv[2].empid2 != '' && appv[2].empid2 != undefined) {
      this.approver3Names += ', <br>' + this.approver23Name + '(' + appv[2].empid2 + ')'
      this.approver3Emails += ', ' + this.apprv23email
    } else { this.approver23Name = '' }
    this.approver33 = appv[2].approver3;
    this.approver33Name = appv[2].approver3Name;
    this.apprv33email = appv[2].approver3Email;
    if (appv[2].empid3 != '' && appv[2].empid3 != undefined) {
      this.approver3Names += ', <br>' + this.approver33Name + '(' + appv[2].empid3 + ')'
      this.approver3Emails += ', ' + this.apprv33email
    } else { this.approver33Name = '' }
    setTimeout(() => {
      this.approver1N = appv[0].approver1Name;
      this.approver2N = appv[0].approver2Name;
      this.approver3N = appv[0].approver3Name;

      //alert('crremail' + this.crremail + 'cro email' + this.croemail)
      debugger
      if (emailreq == "Approved Level1") {
        this.to1 = this.approver1Emails
        //this.to2 = this.apprv21email
        //this.to3 = this.apprv31email
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        this.cc3 = this.approver2Emails
        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus2 = 'Pending'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus3 = 'Queued'
        }
        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Release Approved Level 1`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);

        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver1Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Release Submitted for Approval Level 1')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Release Approval')
          .replace('{{status}}', 'Release Approval Level1')
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);
      }
      else if (emailreq == "Approved Level2") {
        this.to1 = this.approver2Emails
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        this.cc3 = this.approver3Emails
        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus2 = 'Approved'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus3 = 'Pending'
        }
        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Release Approved Level 2`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver2Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Release Submitted for Approval Level 2')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Release Approval')
          .replace('{{status}}', 'Release Approval Level2')
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);

      }
      else if ((emailreq == "Approved")) {

        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approver1NamesR = this.approver1Names
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approver2NamesR = this.approver2Names
          this.approverlevelstatus2 = 'Approved'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approver3NamesR = this.approver3Names
          this.approverlevelstatus3 = 'Approved'
        }

        this.to1 = this.approver3Emails
        //this.to2 = this.apprv23email
        //this.to3 = this.apprv33email
        this.cc1 = this.croemail
        this.cc2 = this.crremail
       // this.cc3 = this.approver1Emails

        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Release Approved`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver3Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Release Approved')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Release Approval')
          .replace('{{status}}', 'Release Approved')
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);
      }
      else if ((emailreq == "Released")) {

        this.crdesc += "<br><br><b> Release Remarks : </b>" + this.releaseComments

        this.to1 = this.crremail
        this.to2 = this.croemail
        this.cc1 = this.croemail

        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Released`
        const output = this.readHtmlFile('assets/email.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crownername)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Release Approved')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1NamesR)
          .replace('{{crapprover2}}', this.approver2NamesR)
          .replace('{{crapprover3}}', this.approver3NamesR)
          .replace('{{phase}}', 'Release ')
          .replace('{{status}}', 'Released')
          .replace('@Approval1Status', 'Approved')
          .replace('@Approval2Status', 'Approved')
          .replace('@Approval3Status', 'Approved')
          .replace('{{BodyContent}}', 'Please find the details of the Change Request Submitted by ' + this.supportpersonname + ' and waiting for your Approval.')
          .replace('{{approvedby}}', this.supportpersonname);
      }
      else if (emailreq == "Reject") {
        this.cc1 = this.croemail
        this.cc2 = this.crremail
        if (this.status == 'Approved') {
          this.appname = this.approver3Names
          this.to1 = this.approver3Emails
          this.approverlevelstatus1 = 'Approved'
          this.approverlevelstatus2 = 'Approved'
          this.approverlevelstatus3 = 'Rejected'

        } else if (this.status == 'Approved Level2') {
          this.appname = this.approver2Names
          this.to1 = this.approver2Emails
          this.cc3 = this.approver3Emails
          this.approverlevelstatus1 = 'Approved'
          this.approverlevelstatus2 = 'Rejected'
          this.approverlevelstatus3 = 'Not Required'
        } else if (this.status == 'Approved Level1') {
          this.appname = this.approver1Names
          this.to1 = this.approver1Emails
          this.cc3 = this.approver2Emails

          this.approverlevelstatus1 = 'Rejected'
          this.approverlevelstatus2 = 'Not Required'
          this.approverlevelstatus3 = 'Not Required'

        } else {
          this.appname = this.approver1Names
          this.to1 = this.approver1Emails
          this.cc3 = this.approver2Emails

          this.approverlevelstatus1 = 'Rejected'
          this.approverlevelstatus2 = 'Not Required'
          this.approverlevelstatus3 = 'Not Required'
        }

        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }

        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }


        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Release Approve Rejected`
        const output = this.readHtmlFile('assets/rejection.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.appname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Release Approve Rejected')
          .replace('{{phase}}', 'Release Approve Approval')
          .replace('{{status}}', 'Release Approve Rejected')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{setstatus}}', 'Rejected')
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);

      }
      else if ((emailreq == "Closure")) {
        // alert('closure email' + this.approver1Emails)
       
        this.to1 = this.approver1Emails
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        

        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Pending Closure Approval`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crownername)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Pending Closure Approval')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Release ')
          .replace('{{status}}', 'Pending Closure Approval')
          .replace('@Approval1Status', 'Pending')
          .replace('@Approval2Status', 'Queued')
          .replace('@Approval3Status', 'Queued')
          .replace('{{BodyContent}}', 'Please find the details of the Change Request Submitted by ' + this.supportpersonname + ' and waiting for your Approval.')
          .replace('{{approvedby}}', this.supportpersonname);
      }
      if (this.to2 != '' && this.to3 != '') {
        var To = ',' + this.to2 + ',' + this.to3;
      } else if (this.to2 != '' && this.to3 == '') {
        var To = ',' + this.to2;
      }
      else {
        var To = '';
      }
      //cc
      if (this.cc2 != '' && this.cc3 != '') {
        var cc = ',' + this.cc2 + ',' + this.cc3;
      } else if (this.cc2 != '' && this.cc3 == '') {
        var cc = ',' + this.cc2;
      }
      else {
        var cc = '';
      }
      var cc1pluscc = this.cc1 + cc;

      var cc1pluscc1 = cc1pluscc.replace(',,', ',');
      const requestBody = {
        "to": this.to1 + To,
        "cc": cc1pluscc1,
        "subject": this.subjecttxt,
        "body": this.populatedOutput

      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
        },
        (error: any) => {
          console.log('Post request failed', error);
        });
    }, 500)

  }

  readHtmlFile(file: string): string {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', file, false);
    xhr.send();
    if (xhr.status === 200) {
      return xhr.responseText;
    } else {
      console.error('Failed to read HTML file:', file);
      return ''; // or handle error accordingly
    }
  }

// Function to activate a tab
  activateTab(tabNumber: number) {
   
    this.activeTab = tabNumber;
  }
  approverValues: string[] = [];
  remarkValues: string[] = [];
  value: any;
  attachfile: any;

  getdata(statu: any) {
    this.attachfile = this.selectedFile.name;
    if (this.attachfile == undefined) {
      this.attachfile = '';
    }
    console.log('Approver', this.supportid)
   
    if (Number(this.APILevel) == 1) {
      if (Number(this.approverCount) <= 1) {
        this.status = "Approved"
      }
      else {
        this.status = "Approved Level1"
      }
    }
    else if (Number(this.APILevel) == 2) {
      if (Number(this.approverCount) <= 2) {
        this.status = "Approved"
      }
      else {
        this.status = "Approved Level2"
      }
    }
    else {
      this.status = "Approved"
    }

    const apiUrl = this.apiurl + '/CRapprove/Approve';
    const requestBody = {

      "Flag": "I",
      "CRApproverID": 1,
      "PlantID": this.crid.plantcode,
      "SupportID": 1,
      "CRID": this.crid.itcrid,
      "ApproverLevel":this.APILevel,
      "Stage": "R",
      "ApproverID": this.supportid,
      "ApprovedDt": this.today,
      "Remarks": this.remark,
      "Comments":this.comment,
      "Status": this.status,
      "Attachment": this.attachfile,
      "CreatedBy": this.supportid,
      "CreatedDt": this.currentdate,
      "ModifiedBy": this.supportid,
      "ModifiedDt": this.currentdate,
      "sendemailfrom": this.sendemailfrom
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
        alert("Change Id:" + this.crid.itcrid + " " + "" + " " + "Released " + " " + this.status);
        //this.viewemail(this.status);
        this.addFile();
        this.emailapproversinfo(this.status);
        this.router.navigate(['/change-request']);

      });
    }
  selectedFile: any = '';
  getattach(event: any): void {
    this.selectedFile = event.target.files[0];
  }


  addFile(): void {
    if (!this.selectedFile) {
      console.error('No file selected.');
      return;
    }

    if (!this.crid.itcrid) {
      console.error('ITCRID is required.');
      return;
    }

    const itcrid = this.crid.itcrid.toString();
    const formData = new FormData();
    formData.append('itcrid', itcrid);
    formData.append('file', this.selectedFile, this.selectedFile.name);
    const apiUrl = this.apiurl + '/CRlession'; // Adjust the API endpoint as per your route

    this.http.post(apiUrl, formData).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.error('POST request failed', error);
      }
    );
  }
  viewFile(itcrid: string, fileName: string): void {
    const apiUrl = `${this.apiurl}/CRlession/GetFile?itcrid=${itcrid}&fileName=${fileName}`;

    this.http.get(apiUrl, { responseType: 'blob' }).subscribe(
      (response: Blob) => {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }
 
  rejectbutton(status: any) {
    this.attachfile = this.selectedFile.name;
    //alert('remarks -'+this.remark);
    if (this.attachfile == undefined) {
      this.attachfile = '';
    }
    if (this.remark=='') {
      alert('Enter release remarks')
    }
    else {
      const apiUrl = this.apiurl + '/CRapprove/Approve';
      const requestBody = {
        "Flag": "I",
        "CRApproverID": 1,
        "PlantID": this.crid.plantcode,
        "approverLevel": this.APILevel,
        "SupportID": 1,
        "CRID": this.crid.itcrid,
        "Stage": "R",
        "ApproverID": Number(this.supportid),
        "ApprovedDt": this.today,
        "Remarks": this.remark,
        "Comments": this.comment,
        "Status": status,
        "Attachment": this.attachfile,
        "CreatedBy": Number(this.supportid),
        "CreatedDt": this.currentdate,
        "ModifiedBy": Number(this.supportid),
        "ModifiedDt": this.currentdate,
        "sendemailfrom": this.sendemailfrom
      }
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };

      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);

          alert("Change ID" + " " + this.crid.itcrid + " " + ": RFC Is Rejected at" + " " + this.status);

          setTimeout(() => {
            this.emailapproversinfo(status);
          }, 1000)
          this.addFile();
          this.router.navigate(['/change-request']);
        },
        (error: any) => {
          alert("POST request failed");
          console.error('POST request failed', error);
        });

    }
  }
      


  isapprover: any[] = [];
  getapprovestatus() {

    const apiUrl = this.apiurl + '/SupportteamAssigned';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("approver id taken", response);
        this.isapprover = response.filter((item: any) => item.itcrid === this.crid.value.itcrid);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  supportteam: any[] = [];
  getsupportid: any;

  getsupportteams() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("Supportid", response);

        this.supportteam = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteam[0].supportTeamId
        console.log("getting supportteam id", this.getsupportid)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    this.getsupportteamassign()
  }

  supportteamassign: any[] = [];
  isapprovers: any = 0;
  issupportegineer: any = 0;
  ischangeanalyst: any = 0;

  getsupportteamassign() {

    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.isapprovers = this.supportteamassign[0].isApprover
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        console.log("support engin", this.issupportegineer)
        
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  updatevalue: any;
  valuereq: any = '';
  isapproved: any;
  changerequest: any = '';
  getrequetervalue(itcrid: any) {
    debugger
    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.valuereq = response
        this.updatevalue = this.valuereq.filter((item: any) => item.itcrid === itcrid);
        this.isapproved = this.updatevalue[0].isApproved
        this.crdesc = this.updatevalue[0].changeDesc;
        //this.crdateval = this.updatevalue[0].crdate;
        const changerequstorname = this.updatevalue[0].crrequestedBy

        /*if (this.itcrtd = this.updatevalue)*/

      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }
  getupdatyevalue() {

    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.changerequest = response.filter((item: any) => item.itcrid.toString() === this.crid.itcrid);
        this.updatevalue = response.filter((item: any) => item.itcrid.toString() === this.crid.itcrid);
        this.isapproved = this.updatevalue[0].isApproved
        /*if (this.itcrtd = this.updatevalue)*/
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  
  approvervalue: any = '';
  approverCount: any = '';
  supportapp1: any; supportapp2: any; supportapp3: any; supportapp: any;
  supportapp1ID: any; supportapp2ID: any; supportapp3ID: any;
  appvflg: boolean = false;

  GetApprover(index: Number) {
    const apiUrl = this.apiurl + '/GetApproval/GetApprover';
    const requestBody = {
      "level": Number(index),
      "stage": "R",
      "plantid": Number(this.plantidforapp),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('apvconut', response)
        this.appvflg = false;
        //alert('this.approverCount '+this.approverCount )
        this.approverCount = (response[0].approverCount);
        //this.approverCount = this.approverCount - 1;s
        console.log("Approver count", this.approverCount)
        this.approvervalue = response;
        this.supportapp = "Select Approver"
        if (this.approvervalue[0].approver1 != '') {

          this.supportapp1ID = this.approvervalue[0].approver1;
          this.supportapp1 = this.approvervalue[0].approver1Name;
          if (Number(this.getsupportid) === Number(this.supportapp1ID)) {
                this.appvflg = true;
          }

        }
        if (this.approvervalue[0].approver2 != '') {
          this.supportapp2ID = this.approvervalue[0].approver2;
          this.supportapp2 = this.approvervalue[0].approver2Name;
          if (Number(this.supportapp2ID) == Number(this.getsupportid))
            this.appvflg = true;
        }
        if (this.approvervalue[0].approver3 != '') {
          this.supportapp3ID = this.approvervalue[0].approver3;
          this.supportapp3 = this.approvervalue[0].approver3Name;
          if (Number(this.supportapp3ID) == Number(this.getsupportid))
            this.appvflg = true;
        }
        console.log("Approver data", this.supportapp, this.approverCount)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  Approver(applevel: Number) {
    if (Number(applevel) == 3) { this.Approver3(); }
    else if (Number(applevel) == 2) { this.Approver2(); }
    else { this.Approver1(); }
  }

  
 //get approved details for all levels
  getapprvdtls: any[] = [];
  approvedDt: any = '';
  comments: any = '';
  getlevel: any;
  emailofreciver: any;

  getapprdtls(level: Number) {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrApproverHistory?id=' + this.itcrid
    
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        
        this.getapprvdtls = response.filter((item: any) => item.stage.trim() === "R" );
        this.getlevel = Number(level) - 1
        this.approvedDt = this.getapprvdtls[this.getlevel].approvedDt;
        this.remark = this.getapprvdtls[this.getlevel].remarks
        this.date = this.getapprvdtls[this.getlevel].approvedDt
        this.comment = this.getapprvdtls[this.getlevel].comments
        this.attach = this.getapprvdtls[this.getlevel].attachment
        console.log('get apprv dtls', response)
       
      },
      (error) => {
        console.error("Data fetching error", error)
      })
  }

  Approver1() {
    this.APILevel = 1;
    this.GetApprover(1);
    this.getapproverslevel();
    this.getapprdtls(1);
    
    if (this.appstatus == "Implemented") {
      if (this.appvflg) this.appflag = true;
      this.remark = '';
      this.attach = '';
      this.date = this.currentday;
    } else {
      this.appflag = false;
      this.appvflg = false;
    }
     //alert('this.appflag APPROVER 1'+this.isReleased+'--' + this.appvflg + '--' + this.appflag + '--' + this.supportapp1ID + '--' + this.supportapp2ID + '--' + this.supportapp3ID + '--' + this.getsupportid)
  }

  Approver2() {
    this.APILevel = 2;
    this.GetApprover(2);
    this.getapproverslevel();
    this.getapprdtls(2);
    

    if (this.appstatus == "Approved level1") {
      if (this.appvflg) this.appflag = true;
      this.remark = '';
      this.attach = '';
      this.date = this.currentday;
    } else {
      this.appflag = false;
      this.appvflg = false;
    }
   //alert('this.appflag APPROVER 2' + this.appvflg + '--' + this.appflag + '--' + this.supportapp1ID + '--' + this.supportapp2ID + '--' + this.supportapp3ID + '--' + this.getsupportid)
  }

  Approver3() {
    this.APILevel = 3;
    this.GetApprover(3);
    this.getapproverslevel();
    this.getapprdtls(3);
    if (this.appstatus == "Approved level2")
  {
      if (this.appvflg) this.appflag = true;
      this.remark = '';
      this.attach = '';
      this.date = this.currentday;
   }
      else
    {
      this.appflag = false;
      this.appvflg = false;
    }
  }
    approverget: any;
    approverlevels: any = '';
    responseData: any[] = [];
    apvnames: any[] = [];

  ApproverNames(): { id: string, name: string }[] {
    
    const approverNames: { id: string, name: string }[] = [];
    for (const key in this.responseData[0]) {
      if (key.endsWith('Name')) {
        const idKey = key.replace('Name', '');
        const id = this.responseData[0][idKey];
        const name = this.responseData[0][key];
        if (id && name && name.trim() !== '') {
          approverNames.push({ id, name });
        }
        
      }
    }
   
    return approverNames;
      }

  getapproverslevel() {
    
    const apiUrls: any = this.apiurl + '/GetApproval/GetApprover';
    const requestBody = {
      "level": Number(this.APILevel),
      "stage": "R",
      "plantid": Number(this.plantidforapp),
      "categoryId": this.categoryId,
      "classificationId": this.classificationId
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.post(apiUrls, requestBody, httpOptions).subscribe(
      (response: any) => {
        //console.log('apilevels', response)
        //console.log('responseData', this.apvnames)
        
        if (this.APILevel == 1) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 1";
          this.ApproverNames();
          console.log("1"+this.rfcapproverlevel)
        }
        if (this.APILevel == 2) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 2";
          this.ApproverNames();
          console.log("2" +this.rfcapproverlevel)
        }
        if (this.APILevel == 3) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 3";
          this.ApproverNames();
          console.log("3" +this.rfcapproverlevel)
        }
        this.approverget = response.filter((item: any) => item.approverstage.trim() === "R");
        this.approverlevels = this.updatevalue[0].isApproved
        console.log("geting approversstaesinpage", response)
        /*if (this.itcrtd = this.updatevalue)*/
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
   // this.sendemailfrom()
  }
  releaseComments: any = '';
  attachments: any = '';
  submitRelease() {
    this.attachfile = this.selectedFile.name;
    if (this.attachfile == undefined) {
      this.attachfile = '';
    }

    if (this.releaseComments.trim() == '') {
      alert(' Enter Release Comments')

    } else {
      const apiUrl = this.apiurl + "/CRrelease/Releaser";
      const requestBody = {
        "flag": "I",
        "itcrid": this.crid.itcrid,
        "crReleaseID": 0,
        "sysLandscape": 1,
        "releaseComments": this.releaseComments,
        "assignedTo": this.supportid,
        "releaseDt": this.today,
        "attachments": this.attachfile,
        "status": "Released",
        "approvedBy": this.supportid,
        "approvedDt": this.today,
        "createdBy": this.supportid,
        "sendemailfrom": this.sendemailfrom,
      }
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
          alert("Change Id:" + this.crid.itcrid + " " + "Released for Approval");
          //this.viewemail('Released'); 
          this.emailapproversinfo('Released');
          this.router.navigate(['/change-request']);
        },
        (error: any) => {
          console.log('Post request failed', error);
        }
      );
    }
  }

  tableData: any[] = [];
  getData() {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrApproverHistory?id=' + this.crid.itcrid
    /*const requestBody = {

    }*/
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.tableData = response;
        console.log('responsetable', response)
      },
      (error) => {
        console.error("Data fetching error", error)
      }
    )
  }
}
    

