import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { PasscrdataService } from '../../passcrdata.service';

interface DropdownItem {
  item_id: number;
  item_text: string;
}

@Component({
  selector: 'app-updatechangerequest',
  templateUrl: './updatechangerequest.component.html',
  styleUrl: './updatechangerequest.component.css'
})
export class UpdatechangerequestComponent {
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  supportid: any;
  supportname: any;
  today: any;
  crid: any = '';
  isApproved: any = '';
  isImplemented: any = '';
  isReleased: any = '';
  isSubmitted: any = '';
  getstatus: any = '';
  CheckDowntimeReq: boolean = false;
  dropdownList: DropdownItem[] = [];
  radioconfirmation: boolean = false;
  gxpradioconfirmation: boolean = false;
  errorMessage: any = '';
  successMessage: any = '';

  clearErrorMessage() {
    this.errorMessage = '';
  }
  clearSuccessMessage() {
    this.successMessage = '';
  }

  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: ActivatedRoute, private router: Router) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;

    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);

    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value;
      this.getstatus = this.crid.status.trim();
      this.isApproved = this.crid.isApproved;
      this.isImplemented = this.crid.isImplemented;
      this.isReleased = this.crid.isReleased;
      this.isSubmitted = this.crid.isSubmitted;
    })
  }
  private apiurl = environment.apiurls;

  ngOnInit(): void {
    this.load();
    /*setTimeout(() => {
      
    }, 1000);*/
    setTimeout(() => {
      this.iniatorid();
      this.crrequestors();
      this.getsupportteamassign();
      this.getsupportteams();
      this.fetchAllItems();
      this.getCheckList();
    }, 500);

  }

  load() {
    this.fetchDropdownData()
    this.getclassification();
    this.getcategory();
    this.getnature();
    this.getcrdata();
    this.getcategorytype();
    this.getreference();
    this.getidupdate();
    this.getreferencetype();
    this.getupdatyevalue(this.itcrid);
    this.getpriority();

    this.fetchAllItems();
    this.getsupportteams();
    this.hidebutton();
  }

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid';
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  selectedlocationNames: DropdownItem[] = [];
  impactedLocation: string = '';

  onSelectedItemsChange(): void {
    this.impactedLocation = this.selectedlocationNames.map((item: DropdownItem) => item.item_text).join(',');
  }

  buttonfunction: boolean = false;

  hidebutton() {
    if (this.getstatus == 'Draft' || this.getstatus == 'Seek Clarification' && this.ischangeanalyst == true) {
      this.buttonfunction = true
    }
    else {
      this.buttonfunction = false
    }
    console.log("status in updatepage", this.getstatus)
  }

  toggleInitiatorFields() {
    this.showInitiator = !this.showInitiator;
  }

  toggleField() {
    /*if (this.updatevalue[0].downTimeRequired==true) {
      this.CheckDowntimeReq = true;
      this.showRiskQ = true;
    }*/
    this.showRiskQ = !this.showRiskQ;
    if (!this.showRiskQ) {
      if (this.updatevalue[0].downTimeFromDate != '' || this.updatevalue[0].downTimeToDate != '' || this.updatevalue[0].impactedLocation != 0 || this.updatevalue[0].impactedDept != 0 || this.updatevalue[0].imactedFunc != '') {
        this.radioconfirmation = true;
      }
      else {
        this.radioconfirmation = false;
      }
    }
  }

  Yes() {
    this.updatevalue[0].downTimeFromDate = '';
    this.updatevalue[0].downTimeToDate = '';
    this.updatevalue[0].impactedLocation = '';
    this.updatevalue[0].impactedDept = '';
    this.updatevalue[0].imactedFunc = '';
    this.radioconfirmation = false;
  }

  No() {
    this.radioconfirmation = false;
  }

  isPopupVisible = false;

  togglePopup() {
    this.isPopupVisible = !this.isPopupVisible;
  }

  // g*p classification
  plantData: any[] = []; // Assuming you want to store multiple plant data entries

  addMore() {
    this.plantData.push({
      selectPlant: '',
      controlNumber: '',
      controlDate: '',
      attachment: null
    });
  }

  update(index: number) {
    // Implement the update logic here
  }

  delete(index: number) {
    this.plantData.splice(index, 1);
  }

  datetimefunction() {

    this.showRiskQ = true;
    this.updateEndDateMin();
  }
  updateEndDateMin() {
    const fromDate = new Date(this.downTimeFromDate);
    fromDate.setDate(fromDate.getDate() + 1);
    this.minEndDate = fromDate.toISOString().slice(0, 16); // Adjust as per your date format
  }



  handleFileInput(event: any, index: number) {
    // Assuming you want to handle file input for a specific row
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }


  getidupdate() {
    this.itcrid = this.route.snapshot.paramMap.get('id');
  }

  itcrid: any = '';
  supportId: any = '';
  classificationId: any = '';
  categoryId: any = '';
  categorytypeid: any = '';
  crowner: any = '';
  crdate: any = '';
  changerequestedby: any = '';
  crrequestedDt: any = '';
  referenceid: any = '';
  referencetype: any = '';
  crinitiatedFor: any = '';
  changeType: any = '';
  natureOfChange: any = '';
  priorityType: any[] = [];
  plantId: any = '';
  gxpclassification: any = '';
  gxpplantId: any = '';
  changeControlNo: any = '';
  changeControlDt: any = '';
  changeControlAttach: any = '';
  changeDesc: any = '';
  reasonForChange: any = '';
  alternateConsidetation: any = '';
  impactNotDoing: any = '';
  triggeredBy: any = '';
  benefits: any = '';
  estimatedCost: any = '';
  estimatedCostCurr: any = '';
  estimatedEffort: any = '';
  estimatedEffortUnit: any = '';
  estimatedDateCompletion: any = '';
  rollbackPlan: any = '';
  backoutPlan: any = '';
  downTimeRequired: any = '';
  downTimeFromDate: string = '';
  downTimeToDate: string = '';
  approvedBy: any = '';
  approvedDt: any = '';
  createdBy: any = '';
  createdDt: any = '';
  modifiedBy: any = '';
  modifiedDt: any = '';
  businessImpact: any;
  impactedDept: any;
  imactedFunc: any;
  selectedCategory: any = '';
  changecntroldt: any = '';
  minEndDate: string = '';
  categorydata: any[] = [];

  getpriority() {
    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.priorityType = response;
        //alert(this.updatevalue[0].priorityType)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  showRiskQ1: any;
  toggleField2() {
    this.showRiskQ1 = !this.showRiskQ1;
    if (!this.showRiskQ1) {
      if (this.updatevalue[0].gxpplantId != 0 || this.updatevalue[0].changeControlNo != '' || this.updatevalue[0].changeControlDt != 0) {
        this.gxpradioconfirmation = true;
      }
      else {
        this.gxpradioconfirmation = false;
      }
    }
  }

  gxpYes() {
    this.updatevalue[0].gxpplantId = '';
    this.updatevalue[0].changeControlNo = '';
    this.updatevalue[0].changeControlDt = '';
    this.gxpradioconfirmation = false;
  }

  gxpNo() {
    this.gxpradioconfirmation = false;
  }

  getcategory() {
    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.categorydata = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  Natureofchange: any[] = [];
  parseToInt(value: string): number {
    return parseInt(value, 10); // Parse string to integer with base 10
  }
  getnature() {

    const apiUrls = this.apiurl + '/NatureofChange'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.Natureofchange = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  classifications: any[] = [];

  getclassification() {

    const apiUrls = this.apiurl + '/Classification';
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.classifications = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  plantcode: any[] = [];
  plant: any;
  getplant() {

    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.plantcode = response.filter((item: any) => this.assignedplant.includes(item.id));
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  changerequest: any[] = [];

  getcrdata() {

    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.changerequest = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorytype: any[] = [];

  getcategorytype() {

    const apiUrls = this.apiurl + '/CategoryTyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.categorytype = response;

      },
      (error) => {
        console.error("Post failed", error)
      })
  }

  referenceapi: any[] = [];

  getreference() {

    const apiUrls = this.apiurl + '/Reference'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.referenceapi = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  refer: any;
  getreferencetype() {

    const apiUrls = this.apiurl + '/ReferenceType'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.refer = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  isapproved: any;
  updatevalue: any = '';
  crdesc: any = '';
  crdateval: any = '';
  CheckGxPClassification: boolean = false;

  plantvalue: number = this.updatevalue.plantId;

  getupdatyevalue(itcrid: any) {
    
    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.updatevalue = response.filter((item: any) => item.itcrid.toString() === itcrid.toString());
        this.isapproved = this.updatevalue[0].isApproved
        this.crdesc = this.updatevalue[0].changeDesc;
        this.crdateval = this.updatevalue[0].crdate;
        const changerequstorname = this.updatevalue[0].crrequestedBy
        this.plantData.push(this.updatevalue);

        if (this.updatevalue[0].downTimeRequired == true) {
          this.CheckDowntimeReq = true;
          this.showRiskQ = true;
        }

        if (this.updatevalue[0].gxpclassification == true) {
          this.CheckGxPClassification = true;
          this.showRiskQ1 = true;
        }


        /*if (this.itcrtd = this.updatevalue)*/
        this.getsystemlandscape();
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }
  getsystemlandscape() {
    const apiUrl = this.apiurl + '/SystemLandscape/Getsystems';
    const requestBody = {
      "categroyId": this.updatevalue[0].categoryId,
      "supportId": this.updatevalue[0].supportId,
      "classificationId": this.updatevalue[0].classifcationId
    };
    this.http.post(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.systemlandscape = response;
        let checkedVlues = this.updatevalue[0]['sysLandscapeId'].split(',')
        this.systemlandscape.forEach(m=>m['isChcked']=(checkedVlues.indexOf(m.sysLandscapeId.toString())!=-1)?true:false)
        this.selectCheckboxes();
      },
      (error: any) => {
        console.error('POST request failed', error);
      }
    );
  }

  selectCheckboxes() {
    for (const item of this.systemlandscape) {
      if (this.checkboxValues.includes(item.sysLandscape1)) {
        item.selected = true;
      }
    }
  }
  updatedvalue = [
    { crdate: new Date() },
    // Add more fields as needed
  ];

  formatDate(date: Date): string {
    return date.toISOString().slice(0, 10);
  }
  splitvalue: any = '';

  Updatecr(status: any) {
    if (this.updatevalue[0].changeDesc == "" || null) {
      alert('Enter Change Description');
    }
    else if (this.updatevalue[0].reasonForChange == "" || null) {
      alert('Enter Reason for Change');
    }
    else if (this.updatevalue[0].alternateConsidetation == "" || null) {
      alert('Enter Alternate Consideration');
    }
    else if (this.updatevalue[0].impactNotDoing == "" || null) {
      alert('Enter impact of not doing change');
    }
    else if (this.updatevalue[0].benefits == "" || null) {
      alert('Enter benefits of doing change');
    }
    else if (this.updatevalue[0].businessImpact == "" || null) {
      alert('Enter business impact if change is implemented');
    }
    else if (this.updatevalue[0].rollbackPlan == "" || null) {
      alert('Enter Roll Back Plan');
    }
    else if (this.updatevalue[0].backoutPlan == "" || null) {
      alert('Enter Back Out Plan');
    }
    else if (this.updatevalue[0].estimatedEffort.length == 0 || this.updatevalue[0].estimatedEffort == '') {
      alert('Please Enter Estimated Effort');
    }
    else if (this.updatevalue[0].estimatedEffortUnit == "") {
      alert('Select Effort Day(s)/Hour(s)');
    }
    else if (!this.updatevalue[0].estimatedDateCompletion || this.updatevalue[0].estimatedDateCompletion == '') {
      alert('Select Expected Date of Completion');
    }
    else if (this.showRiskQ) {
      if (!this.updatevalue[0].downTimeFromDate || this.updatevalue[0].downTimeFromDate == '') {
        alert('Select From Date');
      }
      else if (!this.updatevalue[0].downTimeToDate || this.updatevalue[0].downTimeToDate == '') {
        alert('Select End Date');
      }
      else if (this.updatevalue[0].impactedLocation.length == 0) {
        alert('Select Impacted Location');
      }
      else if (this.updatevalue[0].impactedDept.length == 0) {
        alert('Select Impacted Department');
      }
      else if (this.updatevalue[0].imactedFunc == "") {
        alert('Enter Impacted Function');
      }
      else if (this.showRiskQ1) {
        if (!this.updatevalue[0].gxpplantId) {
          alert('Select GXP Plant');
        }
        else if (!this.updatevalue[0].changeControlNo) {
          alert('Enter Change Control');
        }
        else if (!this.updatevalue[0].changeControlDt || this.updatevalue[0].changeControlDt == '') {
          alert('Select Change Control Date');
        }
        else {
          this.ExecuteFunc(status);
        }
      }
      else {
        this.ExecuteFunc(status);
      }
    }
    else if (this.showRiskQ1) {
      if (!this.updatevalue[0].gxpplantId) {
        alert('Select GXP Plant');
      }
      else if (!this.updatevalue[0].changeControlNo) {
        alert('Enter Change Control');
      }
      else if (!this.updatevalue[0].changeControlDt || this.updatevalue[0].changeControlDt == '') {
        alert('Select Change Control Date');
      }
      else if (this.showRiskQ) {
        if (!this.updatevalue[0].downTimeFromDate || this.updatevalue[0].downTimeFromDate == '') {
          alert('Select From Date');
        }
        else if (!this.updatevalue[0].downTimeToDate || this.updatevalue[0].downTimeToDate == '') {
          alert('Select End Date');
        }
        else if (this.updatevalue[0].impactedLocation.length == 0) {
          alert('Select Impacted Location');
        }
        else if (this.updatevalue[0].impactedDept.length == 0) {
          alert('Select Impacted Department');
        }
        else if (this.updatevalue[0].imactedFunc == "") {
          alert('Enter Impacted Function');
        }
        else {
          this.ExecuteFunc(status);
        }
      }
      else {
        this.ExecuteFunc(status);
      }
    }
    else {
      this.ExecuteFunc(status);
    }
  }

  ExecuteFunc(status: any) {
    const apiUrl = this.apiurl + "/ChangeRequest/InsertChangeRequest";
    const crinitiate = this.setiniatorname.split("-")[0];
    const changerequested = this.setcreniatorname.split("-")[0];
    let checkedLansScapes = this.systemlandscape.filter(m=>m.isChcked==true).map(m=>m.sysLandscapeId)
    .join(',')
    const requestBody = {
      "type": "U",
      "itcrid": this.itcrid,
      "supportId": 1,
      "classifcationId": this.updatevalue[0].classifcationId,
      "categoryId": this.updatevalue[0].categoryId,
      "crowner": this.updatevalue[0].crowner,
      "referenceId": this.updatevalue[0].referenceId,
      "referenceTyp": this.updatevalue[0].referenceTyp,
      "crdate": this.updatevalue[0].crdate,
      "crinitiatedFor": crinitiate,
      "status": status,
      "categoryTypeId": this.updatevalue[0].categoryTypeId,
      "crrequestedBy": changerequested,
      "crrequestedDt": this.updatevalue[0].crrequestedDt,
      "natureOfChange": this.updatevalue[0].natureOfChange,
      "priorityType": this.updatevalue[0].priorityType,
      "plantId": this.updatevalue[0].plantId,
      "gxpclassification": this.CheckGxPClassification,
      "gxpplantId": this.updatevalue[0].gxpplantId,
      "changeControlNo": this.updatevalue[0].changeControlNo,
      "changeControlDt": this.updatevalue[0].changeControlDt,
      "changeControlAttach": true,
      "changeDesc": this.updatevalue[0].changeDesc,
      "reasonForChange": this.updatevalue[0].reasonForChange,
      "alternateConsidetation": this.updatevalue[0].alternateConsidetation,
      "impactNotDoing": this.updatevalue[0].impactNotDoing,
      "triggeredBy": this.updatevalue[0].triggeredBy,
      "benefits": this.updatevalue[0].benefits,
      "estimatedCost": this.updatevalue[0].estimatedCost,
      "estimatedCostCurr": this.updatevalue[0].estimatedCostCurr,
      "estimatedEffort": this.updatevalue[0].estimatedEffort,
      "estimatedEffortUnit": this.updatevalue[0].estimatedEffortUnit,
      "estimatedDateCompletion": this.updatevalue[0].estimatedDateCompletion,
      "rollbackPlan": this.updatevalue[0].rollbackPlan,
      "backoutPlan": this.updatevalue[0].backoutPlan,
      "businessImpact": this.updatevalue[0].businessImpact,
      "downTimeRequired": this.CheckDowntimeReq,
      "downTimeFromDate": this.updatevalue[0].downTimeFromDate,
      "downTimeToDate": this.updatevalue[0].downTimeToDate,
      "impactedLocation": this.updatevalue[0].impactedLocation,
      "impactedDept": this.updatevalue[0].impactedDept,
      "imactedFunc": this.updatevalue[0].imactedFunc,
      "isSubmitted": true,
      "isApproved": false,
      "isImplemented": false,
      "isReleased": false,
      "createdBy": this.supportid,
      "SysLandscapeID" : checkedLansScapes
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        if (status == "Submitted") {
          alert("Change ID" + " " + this.itcrid + " " + ":RFC is Successfully Submitted for approval",);
          //this.viewemail(status);
          this.emailapproversinfo();
          //this.sendemailfrom('Requestor');
          // this.sendemailfrom('Approver');
        }

        this.router.navigate(['/change-request']);
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  approver11: any = ''
  approver21: any = ''
  approver31: any = ''
  approver12: any = ''
  approver22: any = ''
  approver32: any = ''
  approver13: any = ''
  approver23: any = ''
  approver33: any = ''

  approver11Name: any = ''
  approver21Name: any = ''
  approver31Name: any = ''
  approver12Name: any = ''
  approver22Name: any = ''
  approver32Name: any = ''
  approver13Name: any = ''
  approver23Name: any = ''
  approver33Name: any = ''
  approver1: any = ''
  approver2: any = ''
  approver3: any = ''
  approver1Names: any = ''
  approver2Names: any = ''
  approver3Names: any = ''
  plantid: any = ''
  appv: any[] = []
  apprv11email: any = ''
  apprv21email: any = ''
  apprv31email: any = ''
  apprv12email: any = ''
  apprv22email: any = ''
  apprv32email: any = ''
  apprv13email: any = ''
  apprv23email: any = ''
  apprv33email: any = ''
  approver1Emails: any = ''
  approver2Emails: any = ''
  approver3Emails: any = ''
  
  emailapproversinfo() {
    const apiUrl = this.apiurl + '/GetApproverforEmail/GetApproverEmail';
    this.categoryId = this.updatevalue[0].categoryId
    this.plantid = this.updatevalue[0].plantId
    this.classificationId = this.updatevalue[0].classifcationId
    const requestBody = {
      "stage": "N",
      "plantid": Number(this.plantid),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('email conut', response)
      //  alert('respn' + response.length)
        this.appv = response
      });
    setTimeout(() => {
      this.sendemailfrom('Requestor', this.appv);
      this.sendemailfrom('Approver', this.appv);
      
    }, 1000);
  }
   
  appr: any[] = []
  appemail: any = ''

  

  to1: any = '';
  to2: any = '';
  to3: any = '';
  cc1: any = '';
  cc2: any = '';
  cc3: any = '';
  subjecttxt: any = '';
  populatedOutput: any = '';

  sendemailfrom(emailreq: string, appv : any[]) {
    
    const apiUrl = this.apiurl + '/Email'

    this.approver11 = appv[0].approver1;
    this.approver11Name = appv[0].approver1Name;
    this.apprv11email = appv[0].approver1Email;
    if (appv[0].empid1 != '' && appv[0].empid1!=undefined) {
      this.approver1Names = this.approver11Name + '(' + appv[0].empid1 + ')'
      this.approver1Emails = ', ' +this.apprv11email
    }
    else { this.approver11Name = '' }

    this.approver21 = appv[0].approver2
    this.approver21Name = appv[0].approver2Name;
    this.apprv21email = appv[0].approver2Email;
    console.log('appv[0]', this.appv);


    if (appv[0].empid2 != '' && appv[0].empid2 != undefined) {
      this.approver1Names += ", <br> "
      this.approver1Names += this.approver21Name + '(' + appv[0].empid2 + ')'
      this.approver1Emails += ", " + this.apprv21email
    }
    else { this.approver21Name = '' }

    this.approver31 = appv[0].approver3;
    this.approver31Name = appv[0].approver3Name;
    this.apprv31email = appv[0].approver3Email;

    if (appv[0].empid3 != '' && appv[0].empid3 != undefined) {
      this.approver1Names += ', <br>' + this.approver31Name + '(' + appv[0].empid3 + ')'
      this.approver1Emails += ', ' + this.apprv31email
    }
    else { this.approver31Name = '' }

    //second Level
    this.approver12 = appv[1].approver1;
    this.approver12Name = appv[1].approver1Name;
    this.apprv12email = appv[1].approver1Email;
    if (appv[1].empid1 != '' && appv[1].empid1 != undefined) {
      this.approver2Names = this.approver12Name + '(' + appv[1].empid1 + ')'
      this.approver2Emails += ', ' + this.apprv12email
    }
    this.approver22 = appv[1].approver2;
    this.approver22Name = appv[1].approver2Name;
    this.apprv22email = appv[1].approver2Email;
    if (appv[1].empid2 != '' && appv[1].empid2 != undefined) {
      this.approver2Names += ', <br>' + this.approver22Name + '(' + appv[1].empid2 + ')'
      this.approver2Emails += ', ' + this.apprv22email
    }
    this.approver32 = appv[1].approver3;
    this.approver32Name = appv[1].approver3Name;
    this.apprv32email = appv[1].approver3Email;
    if (appv[1].empid3 != '' && appv[1].empid3 != undefined) {
      this.approver2Names += ', <br>' + this.approver32Name + '(' + appv[1].empid3 + ')'
      this.approver2Emails += ', ' + this.apprv32email
    }
    else { this.approver32Name = '' }

    //Thrid Level
    this.approver13 = appv[2].approver1;
    this.approver13Name = appv[2].approver1Name;
    this.apprv13email = appv[2].approver1Email;
    if (appv[2].empid1 != '' && appv[2].empid1 != undefined) {
      this.approver3Names = this.approver13Name + '(' + appv[2].empid1 + ')'
      this.approver3Emails += ', ' + this.apprv13email
    } else { this.approver13Name = '' }

    this.approver23 = appv[2].approver2;
    this.approver23Name = appv[2].approver2Name;
    this.apprv23email = appv[2].approver2Email;
    if (appv[2].empid2 != '' && appv[2].empid2 != undefined) {
      this.approver3Names += ', <br>' + this.approver23Name + '(' + appv[2].empid2 + ')'
      this.approver3Emails += ', ' + this.apprv23email
    } else { this.approver23Name = '' }
    this.approver33 = appv[2].approver3;
    this.approver33Name = appv[2].approver3Name;
    this.apprv33email = appv[2].approver3Email;
    if (appv[2].empid3 != '' && appv[2].empid3 != undefined) {
      this.approver3Names += ', <br>' + this.approver33Name + '(' + appv[2].empid3 + ')'
      this.approver3Emails += ', ' + this.apprv33email
    } else { this.approver33Name = '' }


    //this.approverdtls(this.approver31, 31)
    setTimeout(() => {
     
      if (emailreq == 'Requestor') {
        //alert('emailreq' + emailreq + 'crremail' + this.crremail + 'croemail' + this.croemail)
        this.to1 = this.crremail
        this.cc1 = this.croemail
        //this.cc1 = this.croemail
        const requestdate = this.crdateval
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Submitted for Approval`
        const output = this.readHtmlFile('assets/email.html');
        console.log(output);

        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{this.Cremailvalue[0].crdate}}', requestdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', changeDesc)
          .replace('{{phase}}', 'RFC Submission')
          .replace('{{status}}', 'Pending Approval')
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('@Approval1Status', 'Pending')
          .replace('@Approval2Status', 'Queued')
          .replace('@Approval3Status', 'Queued')
          .replace('{{BodyContent}}', 'Thank you for submitting the Change Request. Below are the details of the Change Request.')
          
      }
      else {//crremail
        this.to1 = this.approver1Emails
        //this.to2 = this.apprv21email
        //this.to3 = this.apprv31email
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        this.cc3 = this.approver2Emails
        console.log('this.cc1', this.cc1)
        console.log('this.cc2', this.cc2)
        console.log('this.cc3', this.cc3)
        const requestdate = this.crdateval
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Pending for Approval`
        const output = this.readHtmlFile('assets/email.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver1Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{this.Cremailvalue[0].crdate}}', requestdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', changeDesc)
          .replace('{{phase}}', 'RFC Submission')
          .replace('{{status}}', 'Pending Approval')
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('${status}', 'RFC Submitted')
          .replace('@Approval1Status', 'Pending')
          .replace('@Approval2Status', 'Queued')
          .replace('@Approval3Status', 'Queued')
          .replace('{{BodyContent}}', 'Please find the details of the Change Request Submitted by ' + this.supportpersonname +' and waiting for your Approval.');

      }

      if (this.to2 != '' && this.to3 != '') {
        var To = ',' + this.to2 + ',' + this.to3;
      } else if (this.to2 != '' && this.to3 == '') {
        var To = ',' + this.to2;
      }
      else {
        var To = '';
      }
      //cc
      if (this.cc2 != '' && this.cc3 != '') {
        var cc = ',' + this.cc2 + ',' + this.cc3;
      } else if (this.cc2 != '' && this.cc3 == '') {
        var cc = ',' + this.cc2;
      }
      else {
        var cc = '';
      }

      //if (this.cc2 != '') {
      //  var cc = ',' + this.cc2;
      //}
      //else {
      //  var cc = '';
      //}

      console.log('approver1Emails',this.approver1Emails)
      console.log('cc', cc)

      var cc1pluscc = this.cc1 + cc;

      var cc1pluscc1 = cc1pluscc.replace(',,', ',');

      const requestBody = {
        "to": this.approver1Emails,
        "cc": cc1pluscc1,
        "subject": this.subjecttxt,
        "body": this.populatedOutput

      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
        },
        (error: any) => {
          console.log('Post request failed', error);

        });
    },500)
    
  }

  readHtmlFile(file: string): string {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', file, false);
    xhr.send();
    if (xhr.status === 200) {
      return xhr.responseText;
    } else {
      console.error('Failed to read HTML file:', file);
      return ''; // or handle error accordingly
    }
  }
  inatiatorid: any;
  setinitator() {
    this.crinitiatedFor = this.supportid + '-' + this.supportpersonname
    //this.inatiatorid = this.supportid+'-'+

  }

  /*system landscape*/

  systemlandscape: any[] = [];
  checkboxValues: any[] = ['Development', 'Quality', 'Validation', 'Production', 'Live'];


  /*Search Filter*/
  dropdownItems: string[] = [];
  dropdownItemscr: string[] = [];
  selectedValue: string = '';
  selectedValuecr: string = '';
  supportteamname: string[] = [];
  supportnames: any;
  crownername: any;
  croemail: any = '';

  fetchAllItems() {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        this.crownername = response.filter(item => item.empId == this.updatevalue[0].crowner )
        this.supportnames = this.crownername[0].firstName + " " + this.crownername[0].middleName + " " + this.crownername[0].lastName;
        this.firstname = this.crownername[0].firstName;
        this.middlename = this.crownername[0].middleName;
        this.lastname = this.crownername[0].lastName;
        this.croemail = this.crownername[0].email;
        this.supportteamname = this.supportnames;
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;
        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }

        // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }


        // If all parts of the name are null, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

  dropdownsupportteamid: any;
  filterItems() {
    const filter = this.setiniatorname.toUpperCase();
    this.dropdownItems = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)

    );
    /* this.dropdownsupportteamid = this.supportteamid.filter();*/
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItems.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItems.length = 0
    }

  }
  
  iniatorsid: any[] = [];
  setiniatorname: any;
  criemail: any = '';
  criequestedBy: any = '';
  
  iniatorid() {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.iniatorsid = response.filter((item: any) => item.empId === this.updatevalue[0].crinitiatedFor);
        this.setiniatorname = this.iniatorsid[0].empId + "-" + this.iniatorsid[0].firstName + " " + this.iniatorsid[0].lastName
        this.criemail = this.iniatorsid[0].email;
        this.criequestedBy = this.iniatorsid[0].firstName + " " + this.iniatorsid[0].middleName +" " +this.iniatorsid[0].lastName
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
    console.log(this.setiniatorname);
    
  }

  selectItem(item: string) {
    this.selectedValue = item;
    this.setiniatorname = item;
    this.dropdownItems = [];
  }

  crrequestedby: any[] = [];
  setcreniatorname: any;
  crremail: any = '';
  crrequestedBy: any = '';

  crrequestors() {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.crrequestedby = response.filter((item: any) => item.empId === this.updatevalue[0].crrequestedBy);
        this.setcreniatorname = this.crrequestedby[0].empId + "-" + this.crrequestedby[0].firstName + " " + this.crrequestedby[0].lastName
        this.crremail = this.crrequestedby[0].email;
        this.crrequestedBy = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  filterItemscr() {
    const filter = this.setcreniatorname.toUpperCase();
    this.dropdownItemscr = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItemscr.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItemscr.length = 0
    }
  }

  selectItemcr(item: string) {
    this.selectedValuecr = item;
    this.setcreniatorname = item;
    this.dropdownItemscr = [];
  }

  //Login filters
  supportteams: any[] = [];
  getsupportid: any;
  supportpersonname = '';
  firstname: any;
  middlename: any;
  lastname: any;

  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId
        /*this.firstname = this.supportteams[0].firstName
        this.middlename = this.supportteams[0].middleName
        this.lastname = this.supportteams[0].lastName
        this.supportpersonname = this.firstname + this.middlename + this.lastname*/
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    this.getsupportteamassign()
  }

  supportteamassign: any[] = [];
  ischangeanalyst: any;
  isapprover: any;
  issupportegineer: any;
  assignedplant: any;
  mapplant: any;
  getsupportteamassign() {
     
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === parseInt(this.getsupportid));
        this.mapplant = this.supportteamassign.map((item: any) => item.plantId);
        this.assignedplant = Array.from(new Set(this.mapplant));
        this.isapprover = this.supportteamassign[0].isApprover
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getplant();
    }, 1000);
    
  }

  checklist: any[] = [];
  getCheckList() {
    
    const apiUrls = this.apiurl + '/CheckList'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        // Filter checklist based on conditions
        this.checklist = response.filter((item: any) => item.plantId === this.updatevalue[0].plantId && item.supportId === 1 && item.classificationId === this.updatevalue[0].classifcationId && item.categoryId === this.updatevalue[0].categoryId);
        console.log('CheckList:', this.checklist)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
}
