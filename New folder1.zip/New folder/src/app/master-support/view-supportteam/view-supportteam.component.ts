import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PasscrdataService } from '../../change-request/passcrdata.service';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { Item } from '@syncfusion/ej2-navigations';

interface DropdownDepartmentItem {
  itemdepartment_id: number;
  itemdepartment_text: string;
}
@Component({
  selector: 'app-view-supportteam',
  templateUrl: './view-supportteam.component.html',
  styleUrl: './view-supportteam.component.css'
})
export class ViewSupportteamComponent {
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute, private routeservice: PasscrdataService) { }

  ngOnInit(): void {
    this.getidupdate();
    this.getupdatyevalue();
  }

  private apiurl = environment.apiurls;

  supportteamId: any;

  getidupdate() {
    this.supportteamId = this.route.snapshot.paramMap.get('id');
  }

  updatevalue: any[] = [];
  varofresponse: any[] = [];
  getupdatyevalue() {
    const apiUrls: any = this.apiurl + '/SupportTeam/supportteam';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.varofresponse = response
        this.updatevalue = this.varofresponse.filter((item: any) => {
        return item.supportTeamId === parseInt(this.supportteamId) && item.level !== null;
      });

      // Sorting by level
      this.updatevalue = this.updatevalue.sort((a, b) => (a.level < b.level ? -1 : 1));

      this.updatevalue = this.updatevalue.filter((item: any) => {
        return item.categoryId === item.categoryId;
      });

      this.updatevalue = this.updatevalue.filter((item: any) => {
        return item.classificationId === item.classificationId;
      });

      const uniqueLevels = [...new Set(this.updatevalue.map(item => item.level))];
      this.updatevalue = uniqueLevels.map(level => {
        const itemsForLevel = this.updatevalue.filter(item => item.level === level);
        return {
          ...itemsForLevel[0],
          approverstage: itemsForLevel.map(item => item.approverstage)
        };
      });
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }


  /*updatevalue: any[] = [];
  varofresponse: any[] = [];
  getupdatyevalue() {
    const apiUrls: any = this.apiurl + '/SupportTeam/supportteam';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.varofresponse = response
        console.log('this.supportteamId', this.supportteamId)
        console.log('this.varofresponse', this.varofresponse)
        this.updatevalue = this.varofresponse.filter((item: any) => item.supportTeamId === parseInt(this.supportteamId));
        this.updatevalue = this.updatevalue.sort((a, b) => (a.level < b.level ? -1 : 1))
        //this.updatevalue = varofresponse.filter((item: any) => item.supportTeamId === parseInt(this.supportteamId));
        this.updatevalue = this.updatevalue.filter((item: any) => {
          return item.categoryId === item.classificationId;
        });

        const uniqueLevels = [...new Set(this.updatevalue.map(item => item.level))];

        // Prepare UI data based on unique levels
        this.updatevalue = uniqueLevels.map(level => {
          const itemsForLevel = this.updatevalue.filter(item => item.level === level);
          return {
            ...itemsForLevel[0], // Take the first item (assuming all items for the same level are the same for these fields)
            approverstage: itemsForLevel.map(item => item.approverstage) // Gather all approver stages
          };
        });
        console.log('this.updatevalue', this.updatevalue)

      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }*/

/*  natureofchange: boolean = false;
  release: boolean = false;
  closure: boolean = false;
  checkthestage() {
    if (this.updatevalue.approverstage == "N") {

    }
  }*/

  isActive: boolean = false;
  approvername: any = '';
  approverstage: string = '';
  IsAdmin: boolean = false;
  IsSuperAdmin: boolean = false;
  IsApprove: boolean = false;
  IsEngineer: boolean = false;
  IsAnalyst: boolean = false;
  plantId: any = '';
  ApproverN: any = '';
  ApproverC: any = '';
  ApproverR: any = '';
  approverstagen: any = '';
  approverstagec: any = '';
  approverstager: any = '';
  ApproverN2: any = '';
  ApproverC2: any = '';
  ApproverR2: any = '';
  approverstagen2: any = '';
  approverstagec2: any = '';
  approverstager2: any = '';
  ApproverN3: any = '';
  ApproverC3: any = '';
  ApproverR3: any = '';
  approverstagen3: any = '';
  approverstagec3: any = '';
  approverstager3: any = '';
  systemlandscape: any[] = [];
  categorytype: any[] = [];
  checkcatid: any = '';
  catidfilter: any = '';
  categorydata: any = '';
  supportTeamId: any = '';
  supportid: any = '';
  supportname: any = '';
  approverlevel: boolean = false;
  approverlevel2: boolean = false;
  approverlevel3: boolean = false;
  approverstage1: any = '';
  approverstage2: any = '';
  approverstage3: any = '';
  messagesuccess: boolean = false;
  messageerror: boolean = false;
  errormessage: any;
  impactedPlant: any = '';
  showMiniForm: boolean = false;
  superadminaccess: any;
  formFields: any[] = [];
  supportId: any = '';
  selecteddepartmentNames: DropdownDepartmentItem[] = [];
  today: any = '';

  onSelecteddepartmentItemsChange(): void {
    console.log("this is the plant ids will come", this.impactedPlant)
    this.impactedPlant = this.selecteddepartmentNames.map((item: any) => item.itemdepartment_id);
  }

  toggleMiniForm() {
    this.showMiniForm = !this.showMiniForm;
  }

  postSupportTeam() {
    if (this.ApproverN) {
      this.approverstagen = 'N'
    }
    if (this.ApproverR) {
      this.approverstager = 'R'
    }
    if (this.ApproverC) {
      this.approverstagec = 'C'
    }
    if (this.ApproverN2) {
      this.approverstagen2 = 'N'
    }
    if (this.ApproverR2) {
      this.approverstager2 = 'R'
    }
    if (this.ApproverC2) {
      this.approverstagec2 = 'C'
    }
    if (this.ApproverN3) {
      this.approverstagen3 = 'N'
    }
    if (this.ApproverR3) {
      this.approverstager3 = 'R'
    }
    if (this.ApproverC3) {
      this.approverstagec3 = 'C'
    }
    if (this.approverlevel) {
      this.approverstage1 = 1
    }
    if (this.approverlevel2) {
      this.approverstage2 = 2
    }
    if (this.approverlevel3) {
      this.approverstage3 = 3
    }

    ;
    const apiUrl = this.apiurl + '/SupportTeam/PostSupportTeam';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    const requestBody = {
      "flag": "U",
      "supportTeamId": 0,
      "email": this.updatevalue[0].email ? this.updatevalue[0].email : "",
      "firstName": this.updatevalue[0].firstName ? this.updatevalue[0].firstName : "",
      "middleName": this.updatevalue[0].middleName ? this.updatevalue[0].middleName : "",
      "lastName": this.updatevalue[0].lastName ? this.updatevalue[0].lastName : "",
      "imgUrl": this.updatevalue[0].imgUrl ? this.updatevalue[0].imgUrl : "",
      "designation": this.updatevalue[0].designation ? this.updatevalue[0].designation : "",
      "role": 'null',
      "empId": this.updatevalue[0].empId,
      "isActive": this.updatevalue[0].isActive,
      "dol": this.updatevalue[0].dob ? this.updatevalue[0].dob : "0000-00-00T00:00:00.000",
      "dob": this.updatevalue[0].dol ? this.updatevalue[0].dol : "0000-00-00",
      "isAdmin": this.IsAdmin,
      "isSuperAdmin": this.IsSuperAdmin,
      "isApprover": this.IsApprove,
      "isChangeAnalyst": this.IsAnalyst,
      "isSupportEngineer": this.IsEngineer,
      "plantId": this.updatevalue[0].code,
      "supportId": Number(this.supportId),
      "categoryId": this.updatevalue[0].categoryName,
      "classificationId": Number(this.updatevalue[0].classificationName),
      "approverstageCR": this.approverstagen,
      "approverstageR": this.approverstager,
      "approverstageC": this.approverstagec,
      "level": Number(this.approverstage1),
      "approverstage2CR": this.approverstagen2,
      "approverstage2R": this.approverstager2,
      "approverstage2C": this.approverstagec2,
      "level2": Number(this.approverstage2),
      "approverstage3CR": this.approverstagen3,
      "approverstage3R": this.approverstager3,
      "approverstage3C": this.approverstagec3,
      "level3": Number(this.approverstage3),
      "createdBy": Number(this.supportId),
      "createdDate": this.today
    };
    setTimeout(() => {
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
          this.messagesuccess = true;
        },
        (error: any) => {
          console.log('Post request failed', error);
          this.messageerror = true;
          this.errormessage = error;
        }
      );
    }, 500);
  }
}
