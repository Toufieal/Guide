import { Component } from '@angular/core';

@Component({
  selector: 'app-update-support',
  templateUrl: './update-support.component.html',
  styleUrl: './update-support.component.css'
})
export class UpdateSupportComponent {

}
