import { Component } from '@angular/core';

@Component({
  selector: 'app-master-support',
  templateUrl: './master-support.component.html',
  styleUrl: './master-support.component.css'
})
export class MasterSupportComponent {

}
