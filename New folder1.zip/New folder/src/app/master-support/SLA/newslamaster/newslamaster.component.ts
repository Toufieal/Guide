import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { PasscrdataService } from '../../../change-request/passcrdata.service';
import { Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { FormBuilder, FormControl,FormGroup } from '@angular/forms';

@Component({
  selector: 'app-newslamaster',
  templateUrl: './newslamaster.component.html',
  styleUrl: './newslamaster.component.css'
})
export class NewslamasterComponent {
  supportteammemid: any;
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private router: Router,
    private fb:FormBuilder) {
  }
  categorydata: any = '';
  selectedCategory:any ='';
  catidfilter:any='';
  categorytype:any='';
  categoryTypeId:any='';
  categoryName: any[] = [];
  checklist: any[] = [];
  plantcode: any[] = [];
  plantId:any='';
  classificationId:any='';
  private apiurl = environment.apiurls;
  slaForm!: FormGroup;
  
  ngOnInit() {
    this.getCategory();
    this.getplant();
    console.log(localStorage.getItem('user'))
    this.slaForm=this.fb.group({
      category:'',
      categoryType:'',
      WaitTime:'',
      WaitTimeUnit:'',
      AssigedTo:'',
      PlantId:'',
      Escalation1:'',
      WaitTimeEscal1:'',
      WaitTimeUnitEscal1:'',
      Escalation2:'',
      WaitTimeEscal2:'',
      WaitTimeUnitEscal2:'',
      slaId:''

    })
  }
  

  getplant() {
    
    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.plantcode = response;
      },
      (error) => {
        console.error("Get failed", error)
      }
    )
  }
  getCategory() {

    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response.filter((item: any) => item.supportId === 1);
        console.log("category data test",this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  getcategorytype() {
    const apiUrls = this.apiurl + '/CategoryTyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        //this.categorytype = responsz
        const checkcatid = this.slaForm.controls['category'].value
        this.catidfilter = checkcatid
        this.categorytype = response.filter((item: any) => item.categoryId.toString() === this.catidfilter);
        console.log("category type id based on categoryid", this.categorytype)
        console.log("sdfs",this.catidfilter)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )}
    submitForm(){
      debugger
      this.routeservice.getsupportteam();
      this.supportteammemid = this.routeservice.supporterID;
      let param = {
        "flag": "string",
        "itslaid": parseInt(this.slaForm.controls['slaId'].value),
        "categoryID": parseInt(this.slaForm.controls['category'].value),
        "classificationID": parseInt(this.slaForm.controls['slaId'].value),
        "categoryTypID": parseInt(this.slaForm.controls['categoryType'].value),
        "supportID": this.supportteammemid, //want to know
        "waitTime": parseInt(this.slaForm.controls['WaitTime'].value),
        "waitTimeUnit": this.slaForm.controls['WaitTimeUnit'].value,
        "assignedTo": parseInt(this.slaForm.controls['AssigedTo'].value),
        "plantID": parseInt(this.slaForm.controls['PlantId'].value),
        "escalation1": parseInt(this.slaForm.controls['Escalation1'].value),
        "waitTimeEscal1": parseInt(this.slaForm.controls['WaitTimeEscal1'].value),
        "waitTimeUnitEscal1": this.slaForm.controls['WaitTimeUnitEscal1'].value,
        "escalation2": parseInt(this.slaForm.controls['Escalation2'].value),
        "waitTimeEscal2": parseInt(this.slaForm.controls['WaitTimeEscal2'].value),
        "waitTimeUnitEscal2": this.slaForm.controls['WaitTimeUnitEscal2'].value,
        "createdBy": this.supportteammemid
      }
      const apiUrls = this.apiurl + '/SlaMaster/PostSlamaster'
      this.http.post(apiUrls, param).subscribe(
        (response: any) => {
        },
        (error) => {
          console.error("Post failed", error)
        }
      )
    }
}
