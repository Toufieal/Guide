import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PasscrdataService } from '../change-request/passcrdata.service';
import { HttpClient} from '@angular/common/http';
import { environment } from '../../environments/environment.development';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})

export class HomeComponent {
  username: string = '';
  password: string = '';
  supportid: any;
  supportempid: any;
  supportteams: any[] = [];
  private loginurls = environment.loginurl;

  constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: ActivatedRoute, private router: Router) {
    if (!sessionStorage.getItem('reloaded')) {
      sessionStorage.setItem('reloaded', 'true');
      window.location.reload();
    } else {
      sessionStorage.removeItem('reloaded');
    }

    this.employeeid();
  }

  idofemployee: any;
  employeeid() {
    this.route.params.subscribe(params => {
      this.idofemployee = params['this.empNumber'];
      this.routeservice.setEmployeeId(this.idofemployee);
    });

    const getToken = localStorage.getItem('token');
    if (!getToken) {
      localStorage.setItem('token', this.idofemployee);
    }
    
    if (getToken == this.idofemployee) {
      localStorage.setItem('isLoggedin', 'true');
    } else {
      localStorage.setItem('isLoggedin', 'false');
    }

    const getLogData = localStorage.getItem('isLoggedin');

    if (getLogData == 'true') {
      this.router.navigate(['/dashboard']);
    } else {
      setTimeout(() => {
        alert("You're Not Authenticated!");
        localStorage.removeItem('token');
        localStorage.setItem('isLoggedin', 'false');
        window.location.href = this.loginurls + '#' + '/login';
      },2000)
      return;
    }
  }

}
