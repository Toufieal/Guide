import { Component } from '@angular/core';

@Component({
  selector: 'app-history-tab',
  templateUrl: './history-tab.component.html',
  styleUrl: './history-tab.component.css'
})
export class HistoryTabComponent {

}
