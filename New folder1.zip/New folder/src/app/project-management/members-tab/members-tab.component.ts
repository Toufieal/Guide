import { Component } from '@angular/core';

@Component({
  selector: 'app-members-tab',
  templateUrl: './members-tab.component.html',
  styleUrl: './members-tab.component.css'
})
export class MembersTabComponent {

}
