import { Component } from '@angular/core';

@Component({
  selector: 'app-milestone-tab',
  templateUrl: './milestone-tab.component.html',
  styleUrl: './milestone-tab.component.css'
})
export class MilestoneTabComponent {
  
}
