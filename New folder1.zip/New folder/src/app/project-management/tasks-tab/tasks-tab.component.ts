import { Component } from '@angular/core';

@Component({
  selector: 'app-tasks-tab',
  templateUrl: './tasks-tab.component.html',
  styleUrl: './tasks-tab.component.css'
})
export class TasksTabComponent {

}
