import { Component } from '@angular/core';

@Component({
  selector: 'app-checklist-tab',
  templateUrl: './checklist-tab.component.html',
  styleUrl: './checklist-tab.component.css'
})
export class ChecklistTabComponent {

}
