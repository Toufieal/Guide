import { Component } from '@angular/core';

@Component({
  selector: 'app-issuetab',
  templateUrl: './issuetab.component.html',
  styleUrl: './issuetab.component.css'
})
export class IssuetabComponent {

}
