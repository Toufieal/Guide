import { Component } from '@angular/core';
import { HelpdeskserviceService } from '../../../helpdeskservice.service';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { PasscrdataService } from '../../../../change-request/passcrdata.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../../environments/environment.development';

@Component({
  selector: 'app-update-issue-resolution',
  templateUrl: './update-issue-resolution.component.html',
  styleUrl: './update-issue-resolution.component.css'
})
export class UpdateIssueResolutionComponent {

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    /*uploadUrl: 'v1/image',*/
    /*upload: (file: File) => { ... }
  uploadWithCredentials: false,
  sanitize: true,
  toolbarPosition: 'top'*/
    toolbarHiddenButtons: [
      ['fontSize',
        'subscript',
        'superscript',
        'indent',
        'outdent',
        'heading',
        'fontName',
        'fontSize',
        'link',
        'unlink',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode',
        'customClasses',
        'insertUnorderedList',
        'insertOrderedList',
      ]
    ]
  };

  selectedRowData: any[] = [];
  IssueCode: string = '';
  Status: string = '';
  Category: string = '';
  ImpactedAsset: string = '';
  ShowForwardTo: boolean = false;
  showPanel: boolean = false;
  showChatPanel: boolean = false;
  Description: string = '';
  ResolutionRemarks: string = '';
  UserRemarks: string = '';
  images: Array<{ name: string, type: string, url: string }> = [];
  ShowSelfInputs: boolean = false;
  ShowUserRemarks: boolean = false;
  ShowOthers: boolean = false;
  ShowGuest: boolean = false;
  ShowOnHold: boolean = true;
  ShowAdminButtons: boolean = false;
  selectRowData: any[] = [];
  EmployeeID: string = '';
  Name: string = '';
  Email: string = '';
  ContactNo: string = '';
  ReportingManager: string = '';
  StaffCategory: string = '';
  Paygroup: string = '';
  Department: string = '';
  Designation: string = '';
  Role: string = '';
  Plant: string = '';
  EmployeeIDOthers: string = '';
  OthersName: string = '';
  EmailOthers: string = '';
  ContactNoOthers: string = '';
  ReportingManagerOthers: string = '';
  StaffCategoryOthers: string = '';
  PlantOthers: string = '';
  PaygroupOthers: string = '';
  DepartmentOthers: string = '';
  DesignationOthers: string = '';
  RoleOthers: string = '';
  GuestEmployeeID: string = '';
  GuestName: string = '';
  Guestemail: string = '';
  GuestContactNo: string = '';
  ReportingManagerinML: string = '';
  StaffCategoryofML: string = '';
  GuestPlant: string = '';
  PaygroupML: string = '';
  DepartmentML: string = '';
  DesignationofMLManager: string = '';
  RoleofMLManager: string = '';
  ReportingManagerEmpID: string = '';

  togglePanel() {
    this.showPanel = !this.showPanel;
  }

  toggleChatPanel() {
    this.showChatPanel = !this.showChatPanel;
  }

  supportid: any;
  private apiurl = environment.apiurls2;

  constructor(private helpdeskservice: HelpdeskserviceService, private http: HttpClient, private routeservice: PasscrdataService) {
    this.helpdeskservice.UpdateIssueResolutiondata$.subscribe(data => {
      if (data && data.selectedData) {
        this.selectedRowData = data.selectedData.selectedVal;
      }
    })

    this.helpdeskservice.UpdateNewIssuedata$.subscribe(data => {
      if (data && data.selectRowData) {
        this.selectedRowData = data.selectRowData.rowData;
      }
    })

    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;

    console.log('this.selectedRowData', this.selectedRowData)
    //this.getUpdatedinputs();
    this.getsupportteams();
    this.fetchAllItems();

    if (this.ShowOnHold == true) {
      this.ShowAdminButtons = false;
    } else {
      this.ShowAdminButtons = true;
    }
  }

  getSelfData:any[]=[];

  fetchAllItems(): Promise<any> {
    const apiUrl = this.apiurl + '/EmployeeMasters';
    return this.http.get(apiUrl).toPromise()
      .then((response: any) => {
        console.log('response',response)
        console.log('selectedRowDataselectedRowData',this.selectedRowData)
        this.getSelfData = response.filter((row: any) => row.employeeId == parseInt(this.selectedRowData[0].assignedbyid));
        this.getInputDatas();

        if(this.ShowOthers == true){
        
        }
        })
      .catch((error: any) => {
        console.error('GET request failed', error);
        throw error;
      });
  }

  getInputDatas() {
    this.EmployeeID = this.getSelfData[0].employeeId;
    this.Name = this.getSelfData[0].employeeName;
    this.Email = this.getSelfData[0].email;
    this.ContactNo = this.getSelfData[0].phoneNumber;
    this.ReportingManager = this.getSelfData[0].reportManagerName;
    this.StaffCategory = this.getSelfData[0].staffCategory;
    this.Plant = this.getSelfData[0].plantcode;
    this.Paygroup = this.getSelfData[0].payGroup;
    this.Department = this.getSelfData[0].department;
    this.Designation = this.getSelfData[0].designation;
    this.Role = this.getSelfData[0].role;
  }

  supportteams: any[] = [];
  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        if (this.supportteams[0].empId == '135055') {
          this.ShowSelfInputs = true;
          this.ShowUserRemarks = false;
          this.ShowOthers = false;
          this.ShowGuest = false;
        } else {
          this.ShowSelfInputs = false;
          this.ShowUserRemarks = true;
          this.ShowOthers = true;
          this.ShowGuest = false;
        }
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  getUpdatedinputs() {
    this.IssueCode = this.selectedRowData[0].issueCode;
    this.Status = this.selectedRowData[0].status;
    this.Category = this.selectedRowData[0].categoryName;
    this.ImpactedAsset = this.selectedRowData[0].categoryName;
  }

  Forward() {
    this.ShowForwardTo = !this.ShowForwardTo;
  }

  Assign() {
    this.ShowForwardTo = !this.ShowForwardTo;
  }

  private decodeHtmlEntities(encodedString: string): string {
    const textarea = document.createElement('textarea');
    textarea.innerHTML = encodedString;
    return textarea.value;
  }

  private convertFileToBase64(file: File): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        resolve(reader.result as string);
      };
      reader.onerror = (error) => {
        reject('Error converting file to base64');
      };
    });
  }

  handleFileInput(event: any) {
    const files: File[] = Array.from(event.target.files);
    this.images = []; // Reset the array

    files.forEach(file => {
      this.convertFileToBase64(file).then(base64 => {
        this.images.push({ name: file.name, type: file.type, url: base64 });
        this.Description += `<img src="${base64}" alt="${file.name} width='100' height='100' ">`;
        /*this.ResolutionRemarks += `<img src="${base64}" alt="${file.name} width='100' height='100' ">`;
        this.UserRemarks += `<img src="${base64}" alt="${file.name} width='100' height='100' ">`;*/
      });
    });
  }


}
