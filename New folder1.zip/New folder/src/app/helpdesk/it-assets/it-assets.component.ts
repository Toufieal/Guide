import { Component } from '@angular/core';

@Component({
  selector: 'app-it-assets',
  templateUrl: './it-assets.component.html',
  styleUrl: './it-assets.component.css'
})
export class ItAssetsComponent {

}
