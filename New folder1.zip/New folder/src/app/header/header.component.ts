import { Component } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { PasscrdataService } from '../change-request/passcrdata.service';
import { Router } from 'express';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
}

/*supportid: any;
constructor(private http: HttpClient, private routeservice: PasscrdataService, private router: Router, private route: ActivatedRoute) {
  this.routeservice.getsupportteam();
  this.supportid = this.routeservice.supporterID;
}

  private apiurl = environment.apiurls

ngOnInit(): void {
  this.getsupportteams();
  this.getsupportteamassign()
}

supportteams: any[] = [];
getsupportid: any;
supportpersonname = '';
firstname: any;
middlename: any;
lastname: any;

getsupportteams() {
  
  const apiUrls = this.apiurl + '/SupportTeam'
  const requestBody = {

  }
  const httpOptions = {
    headers: new HttpHeaders({
      'content-Type': 'application/json'
    })
  };
  this.http.get(apiUrls, requestBody).subscribe(
    (response: any) => {
      this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
      this.getsupportid = this.supportteams[0].supportTeamId;
      this.firstname = this.supportteams[0].firstName;
      this.middlename = this.supportteams[0].middleName;
      this.lastname = this.supportteams[0].lastName;
      if (this.firstname !== null && this.firstname !== undefined) {
        this.supportpersonname += this.firstname;
      }

      if (this.middlename !== null && this.middlename !== undefined) {
        // If the supportpersonname is not empty, add a space before concatenating middle name
        if (this.supportpersonname !== '') {
          this.supportpersonname += ' ';
        }
        this.supportpersonname += this.middlename;
      }

      if (this.lastname !== null && this.lastname !== undefined) {
        // If the supportpersonname is not empty, add a space before concatenating last name
        if (this.supportpersonname !== '') {
          this.supportpersonname += ' ';
        }
        this.supportpersonname += this.lastname;
      }

      // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
      if (this.supportpersonname === '') {
        this.supportpersonname = 'Unknown';
      }


      // If all parts of the name are null, set supportpersonname to 'Unknown'
      if (this.supportpersonname === '') {
        this.supportpersonname = 'Unknown';
      }
    },
    (error) => {
      console.error("Post failed", error)
    }
  )
  this.getsupportteamassign();
}

supportteamassign: any[] = [];
ischangeanalyst: any;
isapprover: any;
issupportegineer: any;


getsupportteamassign() {

  const apiUrls = this.apiurl + '/SupportteamAssigned'
  const requestBody = {

  }
  const httpOptions = {
    headers: new HttpHeaders({
      'content-Type': 'application/json'
    })
  };
  this.http.get(apiUrls, requestBody).subscribe(
    (response: any) => {
      this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);

      this.isapprover = this.supportteamassign[0].isApprover
      this.issupportegineer = this.supportteamassign[0].isSupportEngineer
      this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
    },
    (error) => {
      console.error("Post failed", error)
    }
  )
}*/
