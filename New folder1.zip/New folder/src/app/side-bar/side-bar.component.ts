import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { PasscrdataService } from '../change-request/passcrdata.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrl: './side-bar.component.css'
})
export class SideBarComponent {
  ShowAdminSupData: boolean = false;
  private apiurl = environment.apiurls

  supportid: any;
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private router: Router, private route: ActivatedRoute) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
  }

  ngOnInit(): void {
    this.getsupportteams();
    //this.getsupportteamassign();
  }

  isSidebarClosed: boolean = true;

  toggleSidebar(): void {
    this.isSidebarClosed = !this.isSidebarClosed;
  }

  isDarkTheme: boolean = false;

  toggleTheme() {
    this.isDarkTheme = !this.isDarkTheme;

    if (this.isDarkTheme) {
      document.body.style.background = 'linear-gradient(90deg, rgba(2, 0, 36, 1) 0%, rgba(9, 9, 121, 1) 35%, rgba(0, 212, 255, 1) 100%)';
      document.body.style.color = '#000000';
      // Set text color for dark theme
    } else {
      document.body.style.background = '#d6dddd';
      document.body.style.color = '#000000';
    }
  }

  //login
  supportteams: any[] = [];
  getsupportid: any;
  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId;
        if (this.supportteams[0].empId == '135055') {
          this.ShowAdminSupData = true;
        } else {
          this.ShowAdminSupData = false;
        }
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getsupportteamassign();
    }, 500);
  }

  supportteamassign: any[] = [];
  ischangeanalyst: any;
  isapprover: any;
  issupportegineer: any;
  isadmin: any;
  issuperadmin: any;

  getsupportteamassign() {
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.isapprover = this.supportteamassign[0].isApprover
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.isadmin = this.supportteamassign[0].isAdmin
        this.issuperadmin = this.supportteamassign[0].isSuperAdmin
        //alert("approver = "+this.isapprover +" CR = "+this.ischangeanalyst+" SE = "+ this.issupportegineer+" AD = "+ this.isadmin)
      },

      (error) => {
        console.error("Post failed", error)
      }
    )
  }
}
