import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild, viewChild } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

import { Color } from '@swimlane/ngx-charts';
import { ChartData, ChartDataset, ChartOptions, ChartType, Plugin } from 'chart.js';
import { PasscrdataService } from '../change-request/passcrdata.service';
import { ActivatedRoute } from '@angular/router';
import { Chart } from 'chart.js';
import { IDropdownSettings } from 'ng-multiselect-dropdown';




@Component({
  selector: 'app-dashboard',
 
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
})

export class DashboardComponent implements OnInit {

 
  multi: any[] = [];
  showChart: boolean = false;
  chartOptions: any = {};

  
  supportid: any;
  today: any;
  constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: ActivatedRoute) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;

    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);
}

  private apiurl = environment.apiurls

  single: any;

  dropdownList: any[] = [];
  dplantcode: any = null;
  selectedPlantIds: any[] = [];
  startDate: any = '';
  endDate: any = '';
  colorScheme: any;

  data: any;

  options: any;
  Plant: any = '';
 

  ngOnInit(): void {
   
   /* this.getchangerequest();*/
    //this.getBarchart();
    //this.getChartData();
    this.getsupportteams();
    
    this.getplant();
    this.colorScheme = {
      domain: ['#14A44D', '#808080ff', '#54B4D3', '#DC4C64', '#b5eb49']
    };


  }

  // multi select

  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
    allowSearchFilter: true
  };

  // Filter

  isVisible: boolean = false;
  toggleVisibility(): void {
    this.isVisible = !this.isVisible
  }

  onFilterChange() {
    this.getchangerequest();
    this.getChartData();
    this.getBarchart();

  } 

  /*onSelectedItemsChange(): void {
    console.log("this is the plant ids will come", this.Plant)
    this.Plant = this.selectedPlantIds.map((item: any) => item.item_id);
    
  }*/

  
  getplant() {
    const apiUrls = this.apiurl + '/Plantid';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.get(apiUrls, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
          this.dropdownList = response.map((item:  any) => ({
          item_id: item.id,
          item_text: item.code
        }));
        
        console.log(this.dropdownList);
      },
      (error) => {
        console.error('Get plant failed', error);
      }
    );
  }

  mapedplantfilter: any;
  asignedplantidfilter: any;
  fromDt: any = '';
  endDt: any = '';
  mapedplantdatas() {
    this.mapedplantfilter = this.selectedPlantIds.map((item: any) => item.item_id);
    console.log(this.mapedplantfilter)
    this.asignedplantidfilter = Array.from(new Set(this.mapedplantfilter));
  }

  openNav() {
    const mySidenav = document.getElementById('mySidenav');
    if (mySidenav) {
      mySidenav.style.width = '250px';
    }
  }

  closeNav() {
    const mySidenav = document.getElementById('mySidenav');
    if (mySidenav) {
      mySidenav.style.width = '0';
    }
  }

 

  // DoughnutChart


  //API Call for change request
  changerequest: any[] = [];
  newCount: number = 0;
  completedCount: number = 0;
  pendingCount: number = 0;
  pendingApproval: number = 0;
  Approved: number = 0;
  Rejected: number = 0;
  Implemention: number = 0;
  pending: number = 0;
  release: number = 0;
  Closure: number = 0;
  filter: any[] = [];
  getbarchart: any[] = [];
  getchangerequest() {
    const apiUrls = this.apiurl + '/ViewChangeRequest/ViewChangerequest';
    let queryParams = new HttpParams();
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      }),
    };

    this.http.get(apiUrls, httpOptions).subscribe(
      (response: any) => {
        if (this.issuperadmin) {
          this.changerequest = response
        }
        else if (this.ischangeanalyst) {
          this.changerequest = response.filter((item: { crownerid: any; }) => item.crownerid === parseInt(this.supportid));
        }
        else {
          this.changerequest = response.filter((item: any) => this.assignedcat.includes(item.itcategoryId) && this.assignedplant.includes(item.plantcode));
        }
        this.filter = this.changerequest
        this.countStatus();
        const startDateObj = new Date(this.startDate);
        const endDateObj = new Date(this.endDate);

        // Filter by crdate within the date range
        this.filter = this.filter.filter((item: any) => {
          const crdate = new Date(item.crdate);
          return crdate >= startDateObj && crdate <= endDateObj;
        });
        console.log('plant:', this.filter)
      },

      (error) => {
        console.error("Post failed", error);
      }
    );
  }
  public doughnutChartData: ChartData<any, any[], string> = {
    labels: [],
    datasets: [
      {
        data: [],
        label: 'Status Counts',
        backgroundColor: []
      }
    ]
  };

  filterdonutbyplant() {
    this.filteredbarchartplant();
    this.filterplantwisebar();
    if (this.asignedplantidfilter != '') {
      this.changerequest = this.changerequest.filter((item: any) => this.asignedplantidfilter.includes(item.plantcode));
    }

    if (this.fromDt != '') {
      if (this.endDt == '') {
        this.endDt = this.today
      }
      this.changerequest = this.changerequest.filter((item: any) => item.crdate > this.fromDt && item.crdate < this.endDt)
    }
    this.filter = this.changerequest
    setTimeout(() => {
      this.countStatus();
    }, 1000);
    console.log("here is multi donut selected plantid", this.filter)
  }

  countStatus() {
    this.newCount = this.filter.filter(item => item.status.trim() === 'Draft').length;
    this.completedCount = this.filter.filter(item => item.status.trim() === 'Completed').length;
    this.pendingCount = this.filter.filter(item => item.status.trim() !== 'Completed' && item.status.trim() !== 'Draft').length;
    this.pendingApproval = this.filter.filter(item => item.status.trim() === 'Pending Approval').length;
    this.Approved = this.filter.filter(item => item.status.trim() === 'Approved').length;
    this.Rejected = this.filter.filter(item => item.status.trim() === 'Rejected').length;
    this.Implemention = this.filter.filter(item => item.status.trim() === 'Implement').length;
    this.pending = this.filter.filter(item => item.status.trim() === 'Pending').length;
    this.release = this.filter.filter(item => item.status.trim() === 'Release').length;

    this.doughnutChartData = {
      labels: ['Draft', 'Pending Approval', 'Approved', 'Rejected', 'Implementation', 'Pending', 'Release', 'Closure'],
      datasets: [
        {
          data: [
            this.newCount,
            this.pendingApproval,
            this.Approved,
            this.Rejected,
            this.Implemention,
            this.pending,
            this.release,
            this.completedCount
          ],
          label: 'Status Counts',
          backgroundColor: ['#3B71CA', '#808080ff', '#14A44D', '#DC4C64', '#54B4D3', '#E4A11B', '#b5eb49', '#808080ff']
        }
      ]
    };



  };


  public doughnutChartLabels: string[] = ['Draft', 'Pending Approval', 'Approved', 'Rejected', 'Implementation', 'Pending', 'Release', 'Closure'];

  public doughnutChartType: ChartType = 'doughnut';

  public chartHovered(e: any): void {
    // console.log(e);
  }




  /*Barchart*/

  chartdata: any;
  completed: any[] = [];
  /*notcompleted: any[] = [];*/
  noncompleted: any[] = [];
  month: any[] = [];
  barChartData: any[] = [];
  barChartLabels: string[] = [];
  noncompletedtotal: number = 0;
  completedtotal: number = 0;
  barChartLegend = true;
  getbarchartfilter: any[] = [];
  crmnthcnt: any[] = [];
  
  getBarchart() {
    const apiUrls = this.apiurl + '/Barchart/Getbarchart';
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      }),
    };

    this.http.get<any>(apiUrls).subscribe(
      
      (response: any[]) => {
        this.chartdata = response;
        if (this.issuperadmin) {
          this.getbarchartfilter = response
        }
        else {
          if (this.ischangeanalyst) {
            this.getbarchartfilter = response.filter((item: { crowner: Number; }) => item.crowner === parseInt(this.supportid))
          }
          else {
            this.getbarchartfilter = response.filter((item: any) => this.assignedcat.includes(item.categoryId) && this.assignedplant.includes(item.plantId));
          }
        }
        this.getbarchart = this.getbarchartfilter

        const uniqueMonths = Array.from(new Set(this.getbarchart.map(item => item.crmonth)));

        
        // Update chart data and labels
        this.updateBarChartData();
        this.updateBarChartLabels(uniqueMonths);
      },
      (error) => {
        console.log("Post failed", error);
      }
    );
  }

  filteredbarchartplant() {
    if (this.asignedplantidfilter != '') {
      this.getbarchartfilter = this.getbarchartfilter.filter((item: any) => this.asignedplantidfilter.includes(item.plantId));
    }
    
    if (this.fromDt != '') {
      if (this.endDt == '') {
        this.endDt = this.today
      }
      this.getbarchartfilter = this.getbarchartfilter.filter((item: any) => item.crdate > this.fromDt && item.crdate < this.endDt)
    }
    this.getbarchart = this.getbarchartfilter
    const uniqueMonths = Array.from(new Set(this.getbarchart.map(item => item.crmonth)));
    this.updateBarChartData();
    this.updateBarChartLabels(uniqueMonths);
    console.log(this.getbarchart)
  }

  updateBarChartData() {
    this.completed = this.getbarchart.map((item: { completedIdnum: any; }) => item.completedIdnum);
    console.log("Total", this.completed)

    this.noncompleted = this.getbarchart.map((item: { nonCompletedIdnum: any; }) => item.nonCompletedIdnum);

    this.noncompletedtotal = this.noncompleted.reduce((total: number, num: number) => total + num, 0);
    this.completedtotal = this.completed.reduce((total: number, num: number) => total + num, 0);
    console.log('total noncompleted:', this.noncompleted)
    console.log('completed:', this.completed)
    this.barChartData = [
      { data: [this.noncompletedtotal], label: 'Open' },
      { data: [this.completedtotal], label: 'Completed' },

    ]; console.log("getting inside the function", this.barChartData) }

  updateBarChartLabels(month: number[]) {

    this.barChartLabels = month.map(month => this.getMonthName(month));
  }

  getMonthName(month: number): string {
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    return monthNames[month - 1];
  }


  onBarClick(event: any) {
    if (event.active.length > 0) {
      const clickedIndex = event.active[0]._index;
      const selectedMonth = this.barChartLabels[clickedIndex];
      
    }
  }

  public barChartOptions: any = {

    responsive: true
  };

  // events
  public chartClicked(e: any): void {
    // console.log(e);
  }




  //new bar
  changeanalystplant: any[] = [];
  plantwisebarchart: any[] = [];
  plantData:any[]=[]
  stagesToCount: string[] = ['Approval', 'Closure', 'Implementation', 'Initiated', 'Release'];
  getChartData() {
    const apiUrls = this.apiurl + '/ViewChangeRequest/ViewChangerequest';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
    };


    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.multi = [];

        const uniquePlants = [...new Set(response.map((item: { plantId: any; }) => item.plantId))];

        uniquePlants.forEach(plantId => {
          if (this.issuperadmin) {
            this.changeanalystplant = response
          }
          else if (this.ischangeanalyst) {
            this.changeanalystplant = response.filter((item: { crownerid: any; }) => item.crownerid === parseInt(this.supportid));
          }
          else {
            this.changeanalystplant = response.filter((item: any) => this.assignedcat.includes(item.itcategoryId) && this.assignedplant.includes(item.plantcode));
          }
        
          console.log("here is changerequest overall", this.changeanalystplant)
          this.plantwisebarchart = this.changeanalystplant.filter((item: { plantId: any; }) => item.plantId === plantId);
          this.plantData = this.plantwisebarchart
          const stagesCount: { [key: string]: number } = {};
          this.stagesToCount.forEach(stage => {
            stagesCount[stage] = this.plantData.filter((item: { stage: string; }) => item.stage.trim() === stage).length;
          });

          const plantSeries = {
            label:plantId,
            data: this.stagesToCount.map(stage => stagesCount[stage])
          };

          this.multi.push(plantSeries);
        });
       
        // Now that multi is constructed, update chartOptions
        this.updateChartOptions();
        this.showChart = true;
      },
      (error: any) => {
        console.error('Error fetching chart data:', error);
      }
    );
  }

  filterplantwisebar() {
    this.filteredbarchartplant();
    if (this.asignedplantidfilter != '') {
      this.plantwisebarchart = this.plantwisebarchart.filter((item: any) => this.asignedplantidfilter.includes(item.plantcode));
    }

    if (this.fromDt != '') {
      if (this.endDt == '') {
        this.endDt = this.today
      }
      this.plantwisebarchart = this.plantwisebarchart.filter((item: any) => item.crdate > this.fromDt && item.crdate < this.endDt)
    }
    this.plantData = this.plantwisebarchart
    setTimeout(() => {
      this.updateChartOptions();
    }, 2000);
    console.log("here is multi donut selected plantid", this.filter)
  }

  updateChartOptions() {
    this.chartOptions = {
      animationEnabled: true,
      exportEnabled: false,
      data: this.stagesToCount.map((stage, index) => ({
        dataPoints: this.multi.map(plantSeries => ({ y: plantSeries.data[index], label: plantSeries.label })),
        type: "stackedBar",
        name: stage,
        showInLegend: true,
        color: this.getRandomColor(index)

      })),

      axisX: {
        title: "Plant ID",
        reversed: true
       
      },
     
      axisY: {
        title: "Total Changes",
        gridThickness:0,
        includeZero: true
      },
      toolTip: {
        shared: true
      },
      legend: {
        dockInsidePlotArea: false,
        horizontalAlign: "center",
        verticalAlign:"top"
      }
     
    };

  }

  getRandomColor(index: number) {
    const colors = ['#3B71CA', '#808080ff', '#54B4D3', '#009596','#b5eb49']; 
    return colors[index % colors.length];
  }
 

  supportteams: any[] = [];
  getsupportid: any;
  supportpersonname = '';
  firstname: any;
  middlename: any;
  lastname: any;
  emailofreciver: any;
  getsupportteams() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId;
        this.firstname = this.supportteams[0].firstName;
        this.middlename = this.supportteams[0].middleName;
        this.lastname = this.supportteams[0].lastName;
        this.emailofreciver = this.supportteams[0].email.trim();
        /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;
        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }

        // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }


        // If all parts of the name are null, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getsupportteamassign();
    }, 500);
    
  }


  supportteamassign: any[] = [];
  ischangeanalyst: any;
  isapprover: any;
  issupportegineer: any;
  assignedplant: any;
  assignedcat: any;
  mapplant: any;
  mapcategory: any;
  issuperadmin: any;
  getsupportteamassign() {

    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.mapplant = this.supportteamassign.map((item: any) => item.plantId);
        this.assignedplant = Array.from(new Set(this.mapplant));
        this.mapcategory = this.supportteamassign.map((item: any) => item.categoryId);
        this.assignedcat = Array.from(new Set(this.mapcategory));
        this.isapprover = this.supportteamassign[0].isApprover
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.issuperadmin = this.supportteamassign[0].isSuperAdmin
        console.log("PlantLogin", this.assignedplant)
        console.log("CateLogin", this.assignedcat)
      },

      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getBarchart();
      this.getChartData();
      this.getchangerequest();
    }, 1000);
  }
  }

  
