import { Component } from '@angular/core';
import { environment } from '../../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-slamaster',
  templateUrl: './slamaster.component.html',
  styleUrl: './slamaster.component.css'
})
export class SlamasterComponent {
  constructor(private http: HttpClient, private router: Router) {
    this.filteredData = this.categorytypedata;
  }
  ngOnInit() {

    this.getCategoryType();
  }
  private apiurl = environment.apiurls;

  categorytypedata: any[] = [];

  filteredData: any[]; // Array to hold filtered data
  searchText: string = '';
  filterData() {
    this.filteredData = this.categorytypedata.filter(item =>
      item.categoryType.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }
  getCategoryType() {
    const apiUrls = this.apiurl + '/CategoryTyp/viewcattyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorytypedata = response;
        this.filterData();
        console.log(this.categorytypedata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
}
