import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, EnvironmentInjector } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { PasscrdataService } from '../passcrdata.service';
import { DatePipe } from '@angular/common';
import { Item } from '@syncfusion/ej2-navigations';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { distinct } from 'rxjs';
import { environment } from '@environments/environment';

interface DropdownItem {
  item_id: number;
  item_text: string;
}

interface DropdownDepartmentItem {
  itemdepartment_id: number;
  itemdepartment_text: string;
}

@Component({
  selector: 'app-new-change-request',
  templateUrl: './new-change-request.component.html',
  styleUrl: './new-change-request.component.css'
})
export class NewChangeRequestComponent {
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  showRiskQ2: boolean = false;
  supportid: any;
  supportname: any;
  today: any;
  CheckGxPClassification: boolean = false;
  radioconfirmation: boolean = false;
  gxpradioconfirmation: boolean = false;

  vflag: boolean = true;  // var to manage the workflow enable save and submit button
  dropdownList: DropdownItem[] = [];
  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  dropdownListDepartment: DropdownDepartmentItem[] = [];
  dropdownDepartmentSettings = {
    idField: 'itemdepartment_id',
    textField: 'itemdepartment_text',
  };

  constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: Router) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;

    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);
  }

  private apiurl = environment.apiurls


  ngOnInit() {
    this.fetchDropdownData();
    this.fetchDropdownDepartment();
    this.getclassification();
    this.getnature();
    this.getcrdata();
    this.getcategorytype();
    this.getreference();
    this.getreferencetype();
    this.getinitator();
    this.fetchAllItems();
    this.getsystemlandscape();
    /*this.filterProjectTypes()*/
    this.getpriority();
    setTimeout(() => {
      this.getsupportteamassign();
      this.getsupportteams();
    }, 1000);

  }

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  selectedlocationNames: DropdownItem[] = [];
  impactedLocation: string = '';

  onSelectedItemsChange(): void {
    this.impactedLocation = this.selectedlocationNames.map((item: DropdownItem) => item.item_text).join(',');
  }

  fetchDropdownDepartment(): void {
    const apiUrl = this.apiurl + '/DepartmentMaster/GetDepartment'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownListDepartment = data.map(item => ({
          itemdepartment_id: item.id,
          itemdepartment_text: item.name // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  impactedDept: string = '';
  selecteddepartmentNames: DropdownDepartmentItem[] = [];
  onSelecteddepartmentItemsChange(): void {
    this.impactedDept = this.selecteddepartmentNames.map((item: DropdownDepartmentItem) => item.itemdepartment_text).join(',');
  }

  toggleInitiatorFields() {
    this.showInitiator = !this.showInitiator;
  }

  toggleField() {
    this.showRiskQ = !this.showRiskQ;
    if (!this.showRiskQ) {
      if (this.downTimeFromDate != '' || this.downTimeToDate != '' || this.selectedlocationNames.length != 0 || this.selecteddepartmentNames.length != 0 || this.imactedFunc != '') {
        this.radioconfirmation = true;
      }
      else {
        this.radioconfirmation = false;
      }
    }
  }

  Yes() {
    this.downTimeFromDate = '';
    this.downTimeToDate = '';
    this.selectedlocationNames = [];
    this.selecteddepartmentNames = [];
    this.imactedFunc = '';
    this.radioconfirmation = false;
  }

  No() {
    this.radioconfirmation = false;
  }

  toggleField2() {
    this.showRiskQ2 = !this.showRiskQ2;
    if (!this.showRiskQ2) {
      if (this.gxpplantId != 0 || this.changeControlNo != '' || this.changeControlDt != 0) {
        this.gxpradioconfirmation = true;
      }
      else {
        this.gxpradioconfirmation = false;
      }
    }
  }

  gxpYes() {
    this.gxpplantId = '';
    this.changeControlNo = '';
    this.changeControlDt = '';
    this.gxpradioconfirmation = false;
  }

  gxpNo() {
    this.gxpradioconfirmation = false;
  }

  isPopupVisible = false;

  togglePopup() {
    this.isPopupVisible = !this.isPopupVisible;
  }
  // g*p classification
  plantData: any[] = []; // Assuming you want to store multiple plant data entries

  addMore() {
    this.plantData.push({
      selectPlant: '',
      controlNumber: '',
      controlDate: '',
      attachment: null
    });
  }

  update(index: number) {
    // Implement the update logic here
  }

  delete(index: number) {
    this.plantData.splice(index, 1);
  }

  datetimefunction() {

    this.showRiskQ = true;
    this.updateEndDateMin();
  }

  handleFileInput(event: any, index: number) {
    // Assuming you want to handle file input for a specific row
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }

  supportId: any = '';
  classificationId: any = '';
  categoryId: any = '';
  crowner: any = '';
  crdate: any = '';
  changerequestedby: any = '';
  crrequestedDt: any = '';
  referenceid: any = '';
  referencetype: any = '';
  crinitiatedFor: any = '';
  crinitiate: any = '';
  setinitatorids: any = '';
  changeType: any = '';
  natureOfChange: any = '';
  priorityType: any[] = [];
  crpriority: any = '';
  plantId: any = '';
  gxpclassification: any = '';
  gxpplantId: any = '';
  changeControlNo: any = '';
  changeControlDt: any = '';
  changeControlAttach: any = '';
  changeDesc: any = '';
  reasonForChange: any = '';
  alternateConsidetation: any = '';
  impactNotDoing: any = '';
  triggeredBy: any = '';
  benefits: any = '';
  estimatedCost: any = '';
  estimatedCostCurr: any = '';
  estimatedEffort: any = '';
  estimatedEffortUnit: any = '';
  estimatedDateCompletion: any = '';
  rollbackPlan: any = '';
  backoutPlan: any = '';
  downTimeRequired: any = '';
  downTimeFromDate: string = ''; // Initialize downTimeFromDate
  downTimeToDate: string = '';
  approvedBy: any = '';
  approvedDt: any = '';
  createdBy: any = '';
  createdDt: any = '';
  modifiedBy: any = '';
  modifiedDt: any = '';
  selectedCategory: any = '';
  categoryTypeId: any = '';
  reftype: any[] = [];
  priority: any;
  supportteam: any[] = [];
  rfcDate: any;
  businessImpact: any = '';
  imactedFunc: any = '';
  plant: any = '';
  minEndDate: string = '';
  CheckDowntimeReq: boolean = false;

  getsuppotteam() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("Supportteam", response);
        this.supportteam = response;
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  errorMessage: any = '';
  successMessage: any = '';
  isSubmittedVal: boolean = false;

  submitApprove(status: any) {

    let checkedLansScapes = this.systemlandscape.filter(m=>m.isChcked==true).map(m=>m.sysLandscapeId)
    .join(',')
    if (this.crinitiatedFor == "") {
      alert('Enter Initiator');
    }
    else if (this.plantId == "") {
      alert('Select Plant');
    }
    else if (this.referenceid == "") {
      alert('Select Reference ');
    }
    else if (this.referencetype == "") {
      alert('Select Reference Type');
    }
    else if (this.classificationId == "") {
      alert('Select Classifcation');
    }
    else if (this.selectedCategory == "") {
      alert('Select Category');
    }
    else if (this.categoryTypeId == "") {
      alert('Select Category Type');
    }
    else if (this.natureOfChange == "") {
      alert('Select Nature of Change');
    }
    else if (this.crpriority == "") {
      alert('Select Priority');
    }
    else if (this.changerequestedby == "") {
      alert('Select Change Requested By');
    }
    else if (!this.crrequestedDt ) {
      alert('Select Change Requested On Date');
    }
    else if (this.triggeredBy == "") {
      alert('Select Change triggered By');
    }
    else if (this.changeDesc == "") {
      alert('Enter Change Description');
    }
    else if (this.reasonForChange == "") {
      alert('Enter Reason for Change');
    }
    else if (this.alternateConsidetation == "") {
      alert('Enter Alternate Consideration');
    }
    else if (this.impactNotDoing == "") {
      alert('Enter impact of not doing change');
    }
    else if (this.benefits == "") {
      alert('Enter benefits of doing change');
    }
    else if (this.businessImpact == "") {
      alert('Enter business impact if change is implemented');
    }
    else if (this.rollbackPlan == "") {
      alert('Enter Roll Back Plan');
    }
    else if (this.backoutPlan == "") {
      alert('Enter Back Out Plan');
    }
    else if (this.estimatedEffort.length == 0 || this.estimatedEffort == '') {
      alert('Please Enter Estimated Effort');
    }
    else if (this.estimatedEffortUnit == "") {
      alert('Select Effort Day(s)/Hour(s)');
    }
    else if (!this.estimatedDateCompletion) {
      alert('Select Expected Date of Completion');
    }
    else if (this.showRiskQ) {
      if (!this.downTimeFromDate) {
        alert('Select From Date');
      }
      else if (!this.downTimeToDate) {
        alert('Select End Date');
      }
      else if (this.selectedlocationNames.length == 0) {
        alert('Select Impacted Location');
      }
      else if (this.selecteddepartmentNames.length == 0) {
        alert('Select Impacted Department');
      }
      else if (this.imactedFunc == "") {
        alert('Enter Impacted Function');
      }
      else if (this.showRiskQ2) {
        if (!this.gxpplantId) {
          alert('Selectc GXP Plant');
        }
        else if (this.changeControlNo == "") {
          alert('Enter Change Control');
        }
        else if (!this.changeControlDt) {
          alert('Select Change Control Date');
        }
        else {
          this.ExecuteFunc(status)
        }
      }
      else {
        this.ExecuteFunc(status)
      }
    }
    else if (this.showRiskQ2) {
      if (!this.gxpplantId) {
        alert('Select GXP Plant');
      }
      else if (this.changeControlNo == "") {
        alert('Enter Change Control');
      }
      else if (!this.changeControlDt) {
        alert('Select Change Control Date');
      }
      else if (this.showRiskQ) {
        if (!this.downTimeFromDate) {
          alert('Select From Date');
        }
        else if (!this.downTimeToDate) {
          alert('Select End Date');
        }
        else if (this.selectedlocationNames.length == 0) {
          alert('Select Impacted Location');
        }
        else if (this.selecteddepartmentNames.length == 0) {
          alert('Select Impacted Department');
        }
        else if (this.imactedFunc == "") {
          alert('Enter Impacted Function');
        }
        else {
          this.ExecuteFunc(status)
        }
      }
      else {
        this.ExecuteFunc(status)
      }
    }
    else {
      this.ExecuteFunc(status)
    }
  }

  ExecuteFunc(status: any) {
    if (status == "Draft") {
      this.isSubmittedVal = false;
    } else {
      this.isSubmittedVal = true;
    }

    const apiUrl = this.apiurl + "/ChangeRequest/InsertChangeRequest";
    this.crinitiate = this.crinitiatedFor.split("-")[0];
    const changerequested = this.changerequestedby.split("-")[0];
    let checkedLansScapes = this.systemlandscape.filter(m=>m.isChcked==true).map(m=>m.sysLandscapeId)
    .join(',')
    const requestBody = {
      "type": "I",
      "itcrid": 0,
      "supportId": 1,
      "classifcationId": this.classificationId,
      "categoryId": this.selectedCategory,
      "categoryTypeId": this.categoryTypeId,
      "crowner": this.supportid,
      "crdate": this.today,
      "crrequestedBy": changerequested,
      "crrequestedDt": this.crrequestedDt,
      "crinitiatedFor": this.crinitiate,
      "status": status,
      "referenceId": this.referenceid,
      "referenceTyp": this.referencetype,
      "natureOfChange": this.natureOfChange,
      "priorityType": this.crpriority,
      "plantId": this.plantId,
      "gxpclassification": this.CheckGxPClassification,
      "gxpplantId": this.gxpplantId ? this.gxpplantId : null,
      "changeControlNo": this.changeControlNo ? this.changeControlNo : null,
      "changeControlDt": this.changeControlDt ? this.changeControlDt : null,
      "changeControlAttach": false,
      "changeDesc": this.changeDesc,
      "reasonForChange": this.reasonForChange,
      "alternateConsidetation": this.alternateConsidetation ? this.alternateConsidetation : null,
      "impactNotDoing": this.impactNotDoing,
      "businessImpact": this.businessImpact,
      "triggeredBy": this.triggeredBy,
      "benefits": this.benefits ? this.benefits : null,
      "estimatedCost": this.estimatedCost ? this.estimatedCost : null,
      "estimatedCostCurr": this.estimatedCostCurr ? this.estimatedCostCurr : null,
      "estimatedEffort": this.estimatedEffort ? this.estimatedEffort : null,
      "estimatedEffortUnit": this.estimatedEffortUnit ? this.estimatedEffortUnit : null,
      "estimatedDateCompletion": this.estimatedDateCompletion ? this.estimatedDateCompletion : null,
      "rollbackPlan": this.rollbackPlan ? this.rollbackPlan : null,
      "backoutPlan": this.backoutPlan ? this.backoutPlan : null,
      "downTimeRequired": this.CheckDowntimeReq,
      "downTimeFromDate": this.downTimeFromDate ? this.downTimeFromDate : null,
      "downTimeToDate": this.downTimeToDate ? this.downTimeToDate : null,
      "impactedLocation": this.impactedLocation,
      "impactedDept": this.impactedDept,
      'imactedFunc': this.imactedFunc,
      "isSubmitted": this.isSubmittedVal,
      "isApproved": false,
      "isImplemented": false,
      "isReleased": false,
      "createdBy": this.supportid,
      "SysLandscapeID" : checkedLansScapes
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
        if (status == "Draft") {
          this.successMessage = 'Saved Successfully as Draft!';
        } else {
          this.successMessage = 'Submitted Successfully for RFC Pending Approval!';
        }
        
        console.log(this.successMessage)

        //this.sendemailfrom(changerequested);
        alert(this.successMessage)
        this.route.navigate(['/change-request']);
      },
      (error: any) => {
        console.log('Post request failed', error);
      });
  }


  // successmessage:any='';
  // successMessage(){
  //   this.successmessage = 'Save Successfully!';
  //   setTimeout(()=>{
  //     this.successmessage = '';
  //   },1000);   
  // }


  clearErrorMessage() {
    this.errorMessage = '';
  }
  clearSuccessMessage() {
    this.successMessage = '';
  }

  categorydata: any[] = [];
  supportcateory: any[] = [];
  getcategory() {

    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportcateory = response.filter((item: any) => item.supportId === 1)
        this.categorydata = this.supportcateory.filter((item: any) => this.assignedcat.includes(item.itcategoryId));
        console.log("category data test", this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  getpriority() {
    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.priorityType = response;
        console.log("Priority", this.priorityType)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }


  categoryfunctions() {
    this.vflag = true;
    this.showSavebtn(1);
    this.getsystemlandscape();
    this.getcategorytype();
    this.getnature();
    this.getCheckList();
    this.chkapproverexists();

  }
  wrkflow: any = '';
  showSavebtn(val: Number) {

    if (val == 0) {
      this.vflag = false;
    }
    else {
      if (this.vflag == false) { this.vflag = false; }
      else { this.vflag = true; }
    }
    this.wrkflow = '';
    if (!this.vflag) {
      if (this.wrkflowmsg1 != '' && this.wrkflowmsg != '')
        this.wrkflow = "Workflow for the Change and Category for this plant needs to be updated. Please reach Admin to complete RFC!"
      else if (this.wrkflowmsg1 == '' && this.wrkflowmsg !== '')
        this.wrkflow = this.wrkflowmsg
      else
        this.wrkflow = this.wrkflowmsg1
    }

    // if (this.wrkflow == '' && this.vflag == false) this.vflag = true;
    // alert('valid flag' + this.vflag + 'wrkflowmsge' + this.wrkflow);
  }

  Natureofchange: any[] = [];
  natureofcatid: any = '';
  naturecatid: any = '';

  getnature() {

    const apiUrls = this.apiurl + '/NatureofChange'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        const naturecatid = this.selectedCategory
        this.natureofcatid = naturecatid
        this.Natureofchange = response.filter((item: any) => item.categoryId.toString() === this.natureofcatid);
        console.log(this.Natureofchange)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  classifications: any[] = [];

  getclassification() {

    const apiUrls = this.apiurl + '/Classification'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.classifications = response;
        console.log(this.classifications)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  plantcode: any[] = [];
  assignedPlantsArray: any[] = [];

  getplant() {

    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.plantcode = response.filter((item: any) => this.assignedplant.includes(item.id));
        console.log("PlantCodeID", this.plantcode)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  inatiatorid: any;
  setinitator() {
    this.crinitiatedFor = this.supportid + '-' + this.supportpersonname
    //this.inatiatorid = this.supportid+'-'+

  }

  changerequest: any[] = [];

  getcrdata() {

    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.changerequest = response;
        console.log(this.changerequest)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorytype: any[] = [];
  checkcatid: any = '';
  catidfilter: any = '';
  getcategorytype() {
    // 
    const apiUrls = this.apiurl + '/CategoryTyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        const checkcatid = this.selectedCategory
        this.catidfilter = checkcatid
        this.categorytype = response.filter((item: any) => item.categoryId.toString() === this.catidfilter);
        console.log("category type id based on categoryid", this.categorytype)
        console.log(this.catidfilter)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )

  }

  referenceapi: any[] = [];
  refer: any[] = [];
  getreference() {

    const apiUrls = this.apiurl + '/Reference'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {

        this.refer = response;

      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  referencedrop: any[] = [];

  getreferencetype() {

    const apiUrls = this.apiurl + '/ReferenceType'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.reftype = response;

      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  sameinitator: boolean = false;
  getinitator() {
    if (this.sameinitator == true) {
      this.crinitiatedFor = this.supportid
    }
  }
  updateEndDateMin() {
    const fromDate = new Date(this.downTimeFromDate);
    fromDate.setDate(fromDate.getDate() + 1);
    this.minEndDate = fromDate.toISOString().slice(0, 16); // Adjust as per your date format
  }

  /*filter initiator name*/
  dropdownItems: string[] = [];
  dropdownItemscr: string[] = [];
  selectedValue: string = '';
  selectedValuecr: string = '';
  supportteamname: string[] = [];
  supportnames: string[] = [];

  fetchAllItems() {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        console.log("Function", response);
        this.supportnames = response.map(item => item.empId + '-' + item.firstName + " " + item.lastName);
        this.supportnames = this.supportnames.filter((value, index, self) => self.indexOf(value) === index)
        this.supportteamname = this.supportnames;
        console.log("Suppoert Team Name", this.supportteamname);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }
  dropdownsupportteamid: any;
  filterItems() {
    const filter = this.crinitiatedFor.toUpperCase();
    this.dropdownItems = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItems.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItems.length = 0
    }

  }
  selectItem(item: string) {
    this.selectedValue = item;
    this.crinitiatedFor = item;
    this.dropdownItems = [];

  }


  filterItemscr() {
    const filter = this.changerequestedby.toUpperCase();
    this.dropdownItemscr = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItemscr.length === 0 && filter !== '') {
      this.dropdownItemscr.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItemscr.length = 0
    }
  }
  selectItemcr(item: string) {
    this.selectedValuecr = item;
    this.changerequestedby = item;
    this.dropdownItemscr = [];
  }
  systemlandscape: any[] = [];
  checkboxValues: any[] = ['Development', 'Quality', 'Validation', 'Production', 'Live'];
  wrkflowmsg1: any = '';
  getsystemlandscape() {
    const apiUrl = this.apiurl + '/SystemLandscape/Getsystems';
    const requestBody = {
      "categroyId": this.selectedCategory,
      "supportId": 1,
      "classificationId": this.classificationId
    };
    this.http.post(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Sys", response);
        this.systemlandscape = response;
        this.systemlandscape.forEach(m=>m['isChcked']=true)
        //alert('sys ln' + this.systemlandscape.length);
        if (this.systemlandscape.length == 0) {
          this.showSavebtn(0);
          this.wrkflowmsg1 = "Workflow is not defined for System Landscape. Please reach Admin to complete RFC!";
        }
        else {
          this.showSavebtn(1);
          //  this.vflag = true;
          this.wrkflowmsg1 = "";
        }

      },
      (error: any) => {
        console.error('POST request failed', error);
      }
    );
  }
  //validate if Approvers are existing for the workflow
  approverN: any = '';
  approverR: any = '';
  approverC: any = '';
  approver: any[] = [];
  wrkflowmsg: any = '';
  chkapproverexists() {
    const apiUrl = this.apiurl + '/SupportTeam/supportteam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        console.log("Function4", response);
        this.approver = response.filter((item: any) => item.plantId === Number(this.plantId) && item.categoryId === Number(this.selectedCategory) && item.classificationId === Number(this.classificationId))
        this.approverN = this.approver.filter((item: any) => item.approverstage === 'N' && item.level === 1)

        console.log("approverN value", this.approverN);

        this.approverR = this.approver.filter((item: any) => item.approverstage === 'R' && item.level === 1)

        console.log("approverR value", this.approverR);

        this.approverC = this.approver.filter((item: any) => item.approverstage === 'C' && item.level === 1)

        console.log("approverC value", this.approverC);
        //alert('apprv '+ this.approverN + '' + this.approverR + '' + this.approverC);
        if ((this.approverN.length === 0) || (this.approverR.length === 0) || (this.approverC.length === 0)) {
          //alert('inside approver loop');
          this.showSavebtn(0);
          this.wrkflowmsg = "Workflow is not defined for Approvers. Please reach Admin to complete RFC!";
        }
        else {
          this.showSavebtn(1);
          this.wrkflowmsg = "";
        }
      },
      (error: any) => {
        console.error('No Approver ', error);
      });
  }

  //login
  supportteams: any[] = [];
  getsupportid: any;
  supportpersonname = '';
  firstname: any;
  middlename: any;
  lastname: any;
  emailofreciver: any;
  getsupportteams() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId;
        this.firstname = this.supportteams[0].firstName;
        this.middlename = this.supportteams[0].middleName;
        this.lastname = this.supportteams[0].lastName;
        this.emailofreciver = this.supportteams[0].email.trim();
        /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;
        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }

        // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }


        // If all parts of the name are null, set supportpersonname to 'Unknown'
        if (this.supportpersonname === '') {
          this.supportpersonname = 'Unknown';
        }
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getsupportteamassign();
    }, 500);
  }

  supportteamassign: any[] = [];
  ischangeanalyst: any;
  isapprover: any;
  issupportegineer: any;
  assignedplant: any;
  assignedcat: any;
  mapplant: any;
  mapcategory: any;

  getsupportteamassign() {

    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {

        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.mapplant = this.supportteamassign.map((item: any) => item.plantId);
        this.assignedplant = Array.from(new Set(this.mapplant));
        this.mapcategory = this.supportteamassign.map((item: any) => item.categoryId);
        this.assignedcat = Array.from(new Set(this.mapcategory));
        this.isapprover = this.supportteamassign[0].isApprover
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        console.log("PlantLogin", this.assignedplant)
        console.log("CateLogin", this.assignedcat)
      },

      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getplant();
      this.getcategory();
    }, 500);
  }


  checklist: any[] = [];
  getCheckList() {

    const apiUrls = this.apiurl + '/CheckList'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        // Filter checklist based on conditions
        this.checklist = response.filter((item: any) => item.plantId === parseInt(this.plantId) && item.supportId === 1 && item.classificationId === parseInt(this.classificationId) && item.categoryId === parseInt(this.selectedCategory));
        console.log('CheckList:', this.checklist)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
}
