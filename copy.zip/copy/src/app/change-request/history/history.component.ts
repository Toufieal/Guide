import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment'
import { PasscrdataService } from '../passcrdata.service';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent {

  crid: any[] = [];
  getcrcode: string = '';
  constructor(private http: HttpClient, private routeservice: PasscrdataService) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = [data.report];
    })
    this.getcrcode = this.crid[0].value.crcode;
  }

  private apiurl = environment.apiurls

  ngOnInit(): void {
    this.getcrhistory();
    this.executionhistory();
    this.approvehistory();
    this.getData();
  }

  crhistory: any[] = [];

  getcrhistory() {

    const apiUrls = this.apiurl + '/ChangeRequestHistory/GetCrhistory'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.crhistory = response;
        console.log(this.crhistory)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  exehistory: any[] = [];

  executionhistory() {

    const apiUrls = this.apiurl + '/ExecutionHistory/ExecutionHistory'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.exehistory = response;
        console.log(this.crhistory)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  approverhistory: any[] = [];

  approvehistory() {

    const apiUrls = this.apiurl + '/CRApproverHistory/ApproverHistory'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.exehistory = response.filter();
        console.log(this.crhistory)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  tableData: any[] = [];
  getData() {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetChangeRequestHistory?id=' + this.getcrcode
    /*const requestBody = {

    }*/

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.tableData = response;
        console.log('responsetable12344',response)
      },
      (error) => {
        console.error("Data fetching error", error)
      }
    )
  }


}
