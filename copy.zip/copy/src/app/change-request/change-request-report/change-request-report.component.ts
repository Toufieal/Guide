import { Component } from '@angular/core';

@Component({
  selector: 'app-change-request-report',
  templateUrl: './change-request-report.component.html',
  styleUrl: './change-request-report.component.css'
})
export class ChangeRequestReportComponent {
selectedOption: string = '';

  onOptionSelected(option: string): void {
    this.selectedOption = option;
  }
  
}
