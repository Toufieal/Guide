import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component} from '@angular/core';
import { PasscrdataService } from '../../passcrdata.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-implemet',
  templateUrl: './implemet.component.html',
  styleUrl: './implemet.component.css'
})
export class ImplemetComponent {

  selectoption:any;
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  tabs: any[] = [];
  numberOfTabs: number = 1;
  plantData: any[] = [];
  status: any = '';
  approver: any = '';
  appdate: any = '';
  attach: any = '';
  remark: any = '';
  comment: any = '';
  crid: any = '';
  sysid:any;
  selecttask:any[]=[];
  itcrExecID: any = '';
  sysLandscape: any = '';
  executionStepName: any = '';
  executionStepDesc: any = '';
  assignedTo: any = '';
  startDt: any = '';
  endDT: any = '';
  attachments: any = '';
  statusece: any = '';
  forwardStatus: any = '';
  forwardedTo: string = '';
  forwardedDt:any ='';
  reasonForwarded: any = '';
  remarks: any = '';
  pickedStatus: any = '';
  pickedDt: any = '';
  actualStartDt: any = '';
  actualEndDt: any = '';
  forwardonValue = this.forwardedDt ? this.forwardedDt : null;
  startDtValue = this.startDt ? this.startDt : null;
  endDTValue = this.endDT ? this.endDT : null;
  actualStartDtValue = this.actualStartDt ? this.actualStartDt : null;
  actualEndDtValue = this.actualEndDt ? this.actualEndDt : null;
  execowner: boolean = true;
  supportid: any;
  supportname: any;
  appstatus: any;
  itcrid: any;
  isImplemented: any = '';
  getimplement: any = '';
  classificationId: any = '';
  categoryId: any = '';
  plantidforapp: any = '';
  today; any = '';
  crownername: string = '';

  constructor(private http: HttpClient, private routeservice: PasscrdataService, private router: Router) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value;
      this.itcrid = parseInt(this.crid.itcrid);
      this.getimplement = data.report;
      this.appstatus = this.crid.status.trim();
      this.crownername = this.crid.crowner;
      this.isImplemented = this.crid.isImplemented;
      this.plantidforapp = this.crid.plantcode;
      this.categoryId = this.crid.itcategoryId;
      this.classificationId = this.crid.itclassificationId;
    })
    this.routeservice.sysdata.subscribe(data => {
      this.sysid = data.report;
      console.log("Color",this.sysid)
    });
    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;
    this.getvalue();
  }


  private apiurl = environment.apiurls
  
  nagivate() {
    
    const report = {
      value: this.selectoption
    }
    this.routeservice.syslandscapedata({ report })
    this.router.navigate(['/cr-task'])
  }

  handleFileInput(event: any, index: number) {
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }
  uniqueLandscapes: string[] = [];

  type: any = '';
  data: any = [];
  items: any[] = [];
  selectedCategory: string = '';
  filteredData: any[] = [];
  landscapeOptions: number[] = [];
  exectivevalue: any[] = [];
  crownerid: any = '';

  ngOnInit(): void {
    this.getrequetervalue(this.crid.itcrid);
    this.getcrdata();
    this.getvalue();
    this.getexecutionhistory();
    this.getsystemlandscape();
    this.getupdatyevalue();
    this.usersupportteams();
    //this.btncontrol();
    this.getpredefinedtemplates();
    this.asignandviewtasks();
    this.landscapeOptions = this.value.map((item: { sysLandscape: any; }) => item.sysLandscape)
      .filter((value: any, index: any, self: string | any[]) => self.indexOf(value) === index);
    console.log("Value", this.landscapeOptions);
    this.getimplementname();
    this.getsupportteams();
    setTimeout(() => {
      this.getsupportteamassign();
      this.getreleaseforapprove();
      this.crrequestors();
    }, 1000);
  }

  asignandviewtask: boolean = false;

  asignandviewtasks() {
    if (this.appstatus == "Implement" || this.appstatus == "Implemented" || this.appstatus == "Released" || this.appstatus == "Completed") {
      this.asignandviewtask = true
    }
  }

  
  fnTask(task:any){
  }

  predefindtaskradio:boolean = false;
  manualtaskradio:boolean = false;

  updateCheckbox(checkboxNumber: number) {
  }



  head: string = '';
  filterData(event: any) {
    debugger
    const selectedLandscape: number = event.target.value;
    if (selectedLandscape) {
      this.filteredData = this.value.filter((row: any) => row.sysLandscapeid.toString() === selectedLandscape.toString());
      this.releaseforapprove = this.value.filter((item: any) => item.itcrid === this.crid.itcrid).every((row: any) => row.status.trim() === 'Completed');
    } else {
      this.filteredData = this.value;
      this.releaseforapprove = false;
    }
    console.log("drop", this.filteredData)
    this.getimplementname();
  }
 
  
  systemlandscape: any[] = [];
  getsystemlandscape() {
     
    const apiUrl = this.apiurl + '/SystemLandscape/Getsystems';
    const requestBody = {
      "categroyId": this.crid.itcategoryId,
      "supportId": this.crid.supportId,
      "classificationId": this.crid.itclassificationId
    };
    this.http.post(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Sys", response);
        this.systemlandscape = response;
        for(var i of this.systemlandscape){
          console.log('final', i);
        }
       
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  submitExexute() {
    const apiUrl = this.apiurl + '/Crexecute/executeplan';
    const requestBody = {
      "flag": "V",
      "itcrid": this.crid.itcrid,
      "sysLandscape": 1,
      "executionStepName": "",
      "executionStepDesc": "",
      "assignedTo": null,
      "startDt": null,
      "endDT": null,
      "attachments": null,
      "status": "Implemented",
      "forwardStatus": null,
      "forwardedTo": null,
      "forwardedDt": null,
      "reasonForwarded": null,
      "remarks": null,
      "pickedStatus": null,
      "pickedDt": null,
      "actualStartDt": null,
      "actualEndDt": this.actualEndDtValue,
      "createdBy": null,
     
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
       
        alert("Change ID"+" " + this.crid.itcrid+" "+": Release successfully submitted for Approval");
        this.router.navigate(['/change-request']);
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
    this.emailapproversinfo('Submitted for Approval');
  }
  emailapproversinfo(status: string) {
    const apiUrl = this.apiurl + '/GetApproverforEmail/GetApproverEmail';
    const requestBody = {
      "stage": "C",
      "plantid": Number(this.plantidforapp),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('email conut', response)
        //  alert('respn' + response.length)
        this.appv = response
      });
    setTimeout(() => {
      this.sendemailfrom(status, this.appv);

    }, 1000);
  }
  crremail: any = '';
  croemail: any = '';
  crrequestedBy: any = '';

  approver1N: any = ''
  approver2N: any = ''
  approver3N: any = ''
  approver1: any = ''
  approver2: any = ''
  approver3: any = ''
  plantid: any = ''
  appv: any[] = []
  apprv1email: any = ''
  apprv2email: any = ''
  apprv3email: any = ''
  valuereq: any = '';
  getrequetervalue(itcrid: any) {
    debugger
    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.valuereq = response
        this.updatevalue = this.valuereq.filter((item: any) => item.itcrid === itcrid);
        this.crownerid = this.updatevalue[0].crowner;
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }
  supportpersonname: any = ''
  firstname: any = ''
  middlename: any = ''
  lastname: any = ''
  employeeid: any = ''

  supportteams: any[] = []
  usersupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("SupportId:", this.supportid)
        this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
        this.employeeid = this.supportteams[0].empId;
        this.firstname = this.supportteams[0].firstName;
        this.middlename = this.supportteams[0].middleName;
        this.lastname = this.supportteams[0].lastName;
        /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;

        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }


      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  crval: any[] = [];
  crrname: any = '';
  croname: any = '';
  crrempid: any = '';
  croempid: any = '';
  crempid: any = '';
  cremail: any = '';

  getcrinfo(empid: Number, person: string) {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        this.crval = response.filter(item => item.empId === Number(empid))

        if (person == 'cro') {
          this.croname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.croemail = this.crval[0].email
        }
        else {
          this.crrname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.crremail = this.crval[0].email
        }
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }


  croemailid: any = ''
  crdate: any = ''
  crrdate: any = ''
  crdesc: any = ''
  emailCR: any[] = []

  getcrdata() {
    //alert('in getcrdata')
    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.emailCR = response.filter((item: any) => item.itcrid === Number(this.crid.itcrid))
        console.log('cr info', this.emailCR)
        this.crrempid = this.emailCR[0].crrequestedBy
        this.croempid = this.emailCR[0].crowner
        this.crdate = this.emailCR[0].crdate
        this.crrdate = this.emailCR[0].crrequestedDt
        this.crdesc = this.emailCR[0].changeDesc
        this.plantid = this.emailCR[0].plantId

        setTimeout(() => {
          this.getcrinfo(this.crrempid, 'cro');

          //CR Owner name ad email
          this.getcrinfo(this.croempid, 'crr');

        }, 1000);
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  submitfor: boolean = true;
  completedstatus: any = '';
  implcompleted: any[] = [];
  totrecords: any = '';
  comprecords: any = '';
  value: any[] = [];
  getforwardedtoname: any;
  taskOwner: any[] = [];
  addtaskflag: boolean = false;

  getvalue() {

    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.value = response.filter((item: any) => item.itcrid === this.crid.itcrid);
        console.log(this.value)

        this.totrecords = this.value.length
        this.implcompleted = response.filter((item: any) => item.itcrid === this.crid.itcrid && item.status == 'Completed');
        this.comprecords = this.implcompleted.length

        if ((Number(this.totrecords) == Number(this.comprecords)) && (Number(this.totrecords) != 0) && (!this.isImplemented))
          this.submitfor = true;
        else
          this.submitfor = false;

        this.taskOwner = response.filter((item: any) => item.itcrid === this.crid.itcrid && (item.assignedtoid == parseInt(this.supportid) || item.createdBy == parseInt(this.supportid)))
        
        if (this.taskOwner.length > 0) {
          this.addtaskflag = true;
        }
        else {
          
          setTimeout(() => {
            this.getcrdata();
            //alert('in else ' + this.crownerid + 'croempid' + this.croempid + 'supportt' + this.supportid)
            if (this.crownerid == this.supportid) {
                this.addtaskflag = true;
            }
            else {
              this.addtaskflag = false;
            }

          }, 1000);

        }

      },
      (error: any) => {
        alert('Request failed -' + error);
      });

  }


  crowner: any = '';
  submitby: any = '';
  crrequestors() {
    debugger

    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }

    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.crrequestedby = response.filter((item: any) => item.empId === this.updatevalue[0].crrequestedBy);
        this.setcreniatorname = this.crrequestedby[0].empId + "-" + this.crrequestedby[0].firstName + " " + this.crrequestedby[0].lastName
        this.crremail = this.crrequestedby[0].email;
        this.crrequestedBy = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
        this.crowner = response.filter((item: any) => item.empId === this.updatevalue[0].crowner);
        this.submitby = this.crowner[0].firstName + " " + this.crowner[0].middleName + " " + this.crowner[0].lastName

      },

      (error: any) => {
        console.error('POST request failed', error);
      });
  }
  appr: any[] = []
  appemail: any = ''
  approver11: any = ''
  approver21: any = ''
  approver31: any = ''
  approver12: any = ''
  approver22: any = ''
  approver32: any = ''
  approver13: any = ''
  approver23: any = ''
  approver33: any = ''

  approver11Name: any = ''
  approver21Name: any = ''
  approver31Name: any = ''
  approver12Name: any = ''
  approver22Name: any = ''
  approver32Name: any = ''
  approver13Name: any = ''
  approver23Name: any = ''
  approver33Name: any = ''
  approver1Names: any = ''
  approver2Names: any = ''
  approver3Names: any = ''
  apprv11email: any = ''
  apprv21email: any = ''
  apprv31email: any = ''
  apprv12email: any = ''
  apprv22email: any = ''
  apprv32email: any = ''
  apprv13email: any = ''
  apprv23email: any = ''
  apprv33email: any = ''
  approver1Emails: any = ''
  approver2Emails: any = ''
  approver3Emails: any = ''
  to: any = '';
  to1: any = '';
  to2: any = '';
  to3: any = '';
  cc1: any = '';
  cc2: any = '';
  cc3: any = '';
  cc4: any = '';
  cc5: any = '';
  crdateval: any = '';
  subjecttxt: any = '';
  populatedOutput: any = '';
  approverlevelstatus1: any = ''
  approverlevelstatus2: any = ''
  approverlevelstatus3: any = ''
  crrequestedby: any[] = [];
  setcreniatorname: any;
  sendemailfrom(emailreq: string, appv: any[]) {
    debugger
    const apiUrl = this.apiurl + '/Email'
    this.approver11 = appv[0].approver1;
    this.approver11Name = appv[0].approver1Name;
    this.apprv11email = appv[0].approver1Email;
    if (appv[0].empid1 != '') {
      this.approver1Names = this.approver11Name + '(' + appv[0].empid1 + ')'
      this.approver1Emails = ', ' + this.apprv11email
    }
    else { this.approver11Name = '' }

    this.approver21 = appv[0].approver2
    this.approver21Name = appv[0].approver2Name;
    this.apprv21email = appv[0].approver2Email;
    console.log('appv[0]', this.appv);
    if (appv[0].empid2 != '') {
      this.approver1Names += ", <br> "
      this.approver1Names += this.approver21Name + '(' + appv[0].empid2 + ')'
      this.approver1Emails += ", " + this.apprv21email
    }
    else { this.approver21Name = '' }

    this.approver31 = appv[0].approver3;
    this.approver31Name = appv[0].approver3Name;
    this.apprv31email = appv[0].approver3Email;
    if (appv[0].empid3 != '') {
      this.approver1Names += ', <br>' + this.approver31Name + '(' + appv[0].empid3 + ')'
      this.approver1Emails += ', ' + this.apprv31email
    }
    else { this.approver31Name = '' }
    //second Level
    this.approver12 = appv[1].approver1;
    this.approver12Name = appv[1].approver1Name;
    this.apprv12email = appv[1].approver1Email;
    if (appv[1].empid1 != '') {
      this.approver2Names = this.approver12Name + '(' + appv[1].empid1 + ')'
      this.approver2Emails += ', ' + this.apprv12email
    }
    this.approver22 = appv[1].approver2;
    this.approver22Name = appv[1].approver2Name;
    this.apprv22email = appv[1].approver2Email;
    if (appv[1].empid2 != '') {
      this.approver2Names += ', <br>' + this.approver22Name + '(' + appv[1].empid2 + ')'
      this.approver2Emails += ', ' + this.apprv22email
    }
    this.approver32 = appv[1].approver3;
    this.approver32Name = appv[1].approver3Name;
    this.apprv32email = appv[1].approver3Email;
    if (appv[1].empid3 != '') {
      this.approver2Names += ', <br>' + this.approver32Name + '(' + appv[1].empid3 + ')'
      this.approver2Emails += ', ' + this.apprv32email
    }
    else { this.approver32Name = '' }

    //Thrid Level
    this.approver13 = appv[2].approver1;
    this.approver13Name = appv[2].approver1Name;
    this.apprv13email = appv[2].approver1Email;
    if (appv[2].empid1 != '') {
      this.approver3Names = this.approver13Name + '(' + appv[2].empid1 + ')'
      this.approver3Emails += ', ' + this.apprv13email
    } else { this.approver13Name = '' }

    this.approver23 = appv[2].approver2;
    this.approver23Name = appv[2].approver2Name;
    this.apprv23email = appv[2].approver2Email;
    if (appv[2].empid2 != '') {
      this.approver3Names += ', <br>' + this.approver23Name + '(' + appv[2].empid2 + ')'
      this.approver3Emails += ', ' + this.apprv23email
    } else { this.approver23Name = '' }
    this.approver33 = appv[2].approver3;
    this.approver33Name = appv[2].approver3Name;
    this.apprv33email = appv[2].approver3Email;
    if (appv[2].empid3 != '') {
      this.approver3Names += ', <br>' + this.approver33Name + '(' + appv[2].empid3 + ')'
      this.approver3Emails += ', ' + this.apprv33email
    } else { this.approver33Name = '' }
    setTimeout(() => {

      this.to1 = this.approver1Emails
      //this.to2 = this.apprv21email
      //this.to3 = this.apprv31email
      this.cc1 = this.crremail
      this.cc2 = this.croemail
      this.cc3 = this.approver2Emails
      console.log('this.cc1', this.cc1)
      console.log('this.cc2', this.cc2)
      console.log('this.cc3', this.cc3)
      const requestdate = this.crdateval
      const changeDesc = this.crdesc
      this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Pending for Release Approval`
      const output = this.readHtmlFile('assets/email.html');
      console.log(output);
      this.populatedOutput = output
        .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver1Names)
        .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
        .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
        .replace('{{this.Cremailvalue[0].changeDesc}}', changeDesc)
        .replace('{{phase}}', 'Release')
        .replace('{{status}}', 'Pending for Release Approval')
        .replace('{{crapprover1}}', this.approver1Names)
        .replace('{{crapprover2}}', this.approver2Names)
        .replace('{{crapprover3}}', this.approver3Names)
        .replace('${status}', 'Release')
        .replace('@Approval1Status', 'Pending')
        .replace('@Approval2Status', 'Queued')
        .replace('@Approval3Status', 'Queued')
        .replace('{{BodyContent}}', 'Please find the details of the Change Request Submitted by ' + this.supportpersonname + ' and waiting for your Approval.');

      if (this.to2 != '' && this.to3 != '') {
        var To = ',' + this.to2 + ',' + this.to3;
      } else if (this.to2 != '' && this.to3 == '') {
        var To = ',' + this.to2;
      }
      else {
        var To = '';
      }
      //cc
      if (this.cc2 != '' && this.cc3 != '') {
        var cc = ',' + this.cc2 + ',' + this.cc3;
      } else if (this.cc2 != '' && this.cc3 == '') {
        var cc = ',' + this.cc2;
      }
      else {
        var cc = '';
      }
      var cc1pluscc = this.cc1 + cc;

      var cc1pluscc1 = cc1pluscc.replace(',,', ',');
      const requestBody = {
        "to": this.to1 + To,
        "cc": cc1pluscc1,
        "subject": this.subjecttxt,
        "body": this.populatedOutput

      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
        },
        (error: any) => {
          console.log('Post request failed', error);
        });
    }, 500)

  }

  readHtmlFile(file: string): string {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', file, false);
    xhr.send();
    if (xhr.status === 200) {
      return xhr.responseText;
    } else {
      console.error('Failed to read HTML file:', file);
      return ''; // or handle error accordingly
    }
  }


  templateName:any;

  predefindtask() {
    if (this.templateName == "") {
      alert("Enter Template Name")
    } else {
      
      const apiUrl = this.apiurl + '/CRTemplate/PostCRTemplate';
      const requestBody = {
        "flag": "I",
        "crTemplateID": 0,
        "templateName": this.templateName,
        "crid": this.crid.itcrid,
        "crTemplateDtlsID": 0,
        "supportID": this.crid.supportId,
        "sysLandscapeID": 1,
        "classificationID": this.crid.itclassificationId,
        "categoryID": this.crid.itcategoryId,
        "categoryTypID": this.crid.categoryTypeId,
        "taskName": "string",
        "taskDesc": "string",
        "priority": this.crid.priorityType,
        "isActive": true,
        "createdBy": this.crid.supportId,

      }
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
          alert("Saved as predefind task");
          this.router.navigate(['/change-request']);
        },
        (error: any) => {
          console.log('Post request failed', error);
        }
      );
    }
  }


  templateid: any = '';

  savepredefindtask() {
    
    const apiUrl = this.apiurl + '/CRTemplateExe/PostCRTemplateExe';
    const requestBody = {
      "flag": "I",
      "crTemplateID": Number(this.templateid),
      "crid": Number(this.crid.itcrid),
      "createdBy": Number(this.supportid),
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
        alert("Saved Template Successfully");
        this.router.navigate(['/change-request']);
        //this.getexecutionhistory();
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  predefindtemplate: any[] = [];
  templatenames:any[]=[];
  emailofreciver: any;

  getpredefinedtemplates() {
    const apiUrl = this.apiurl + '/CRTemplate/GetCRTemplate';
    const requestBody = {};
    
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Functionhdtncg v", response);
        // Filter out duplicate values
        this.templatenames = response;
        this.predefindtemplate = this.removeDuplicates(response, 'crtemplateId');
      },
      (error: any) => {
        console.error('GET request failed', error);
      });
  }

  showtasktable:boolean= false;
  showpredefindtasks:any[]=[];
  showpredefindtask()
  {
    
    this.showtasktable = true;
    this.showpredefindtasks = this.templatenames.filter((item: any) => item.crtemplateId === parseInt(this.templateid))
  }

  removeDuplicates(array: any[], property: string): any[] {
    return array.filter((obj, index, self) =>
      index === self.findIndex((o) => (
        o[property] === obj[property]
      ))
    );
  }

 executethepart:any[]=[]
 releaseforapprove: boolean = false;
  getreleaseforapprove() {
    
    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {}
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function", response);
        this.executethepart = response
        this.releaseforapprove = response.filter((item: any) => item.itcrid === this.crid.itcrid).every((row: any) => row.status.trim() === 'Completed');
        
        console.log("find the status of the id is completed or not", this.executethepart, this.releaseforapprove)
        
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }


  nameinimplement:any[]=[];
  gettheusername:any;
  getimplementname(){
     
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {}
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        for (var data in this.filteredData){
          this.nameinimplement = response.filter((item: any) => item.supportTeamId === 1); 
        }

        this.nameinimplement = response.filter((item: any) => item.supportTeamId === this.filteredData[0].forwardedTo); 
        this.gettheusername = this.nameinimplement[0].supportTeamId + "-" + this.nameinimplement[0].firstName + " " + this.nameinimplement[0].lastName
        console.log("getting the name in table",this.nameinimplement, this.gettheusername);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

 // Login
  getsupportid: any;

  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId
        console.log("getting supportteam id", this.getsupportid)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  supportteamassign: any[] = [];
  isapprover: any;
  ischangeanalyst: any;
  issupportegineer: any;
  supportteamid: any;

  getsupportteamassign() {
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === parseInt(this.getsupportid));
        this.supportteamid = this.supportteamassign[0].
        this.isapprover = this.supportteamassign[0].isApprover
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        console.log("geting support asigned id", this.isapprover)
      },
      (error) => {
        console.error("Post failed", error);
      }
    )
  }



  isReleased: any;
  updatevalue: any;
  getupdatyevalue() {

    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.updatevalue = response.filter((item: any) => item.itcrid === this.crid.itcrid);
        this.isReleased = this.updatevalue[0].isReleased
        console.log("Update_value", this.isReleased)
        /*if (this.itcrtd = this.updatevalue)*/
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  onclickassign() {
    this.getassigntome();
    this.assigintobutton();
  }

  assigntobutton: boolean = false;
  assigintobutton() {
    this.assigntobutton = true;
    this.implementbtn = false;
  }

  assingntome:any[]=[] ;
  getassigntome() {
    
    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.assingntome = response.filter((item: any) => item.itcrid === this.crid.itcrid && item.assignedtoid === parseInt(this.supportid));
         console.log('Value assign to me ' , this.value)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });

  }

  emplementtsk() {
    this.viewimplement();
    this.getexecutetask();
    this.getvalue();
  }

  implementbtn: boolean = false;
  viewimplement() {
    this.implementbtn = true
    this.assigntobutton = false
  }

  landscapeTasks: { [key: string]: any[] } = {};
  landscapeNames: { [key: string]: string } = {}; // Add this object to hold landscape names
  executetaskbyid: any[] = [];
  getexecutetask() {
    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {};

    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.executetaskbyid = response.filter((item: any) => item.itcrid === this.crid.itcrid);
        // Initialize landscapeTasks and landscapeNames objects
        this.landscapeTasks = {};
        this.landscapeNames = {};
        // Group tasks by landscape
        this.executetaskbyid.forEach((item: any) => {
          const landscape = item.sysLandscapeid;
          if (!this.landscapeTasks[landscape]) {
            this.landscapeTasks[landscape] = [];
            this.landscapeNames[landscape] = item.sylandscape; // Store landscape name
          }
          this.landscapeTasks[landscape].push(item);
        });
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

  executionhistory: any[] = [];


  getexecutionhistory() {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrExecutionPlanHistory?id=' + this.itcrid

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.executionhistory = response;

        console.log('responsetablew', response)
      },
      (error) => {
        console.error("Data fetching error", error)
      }
    )
  }
  deleteconfirmation: boolean = false;
  deleteitcrexecId: string = '';
  deletecategoryid: any;
  deleteRow(itcrexecId: any) {
    
    this.deleteitcrexecId = itcrexecId;
    this.deleteconfirmation = true
  }

  deleteyes() {
    this.deleteconfirmation = false
    this.deleteexeplan()
  }

  deleteno() {
    this.deleteconfirmation = false
  }

  deleteinprogress: boolean = false;
  deletesuccess: boolean = false;
  deletemessage: any = '';
  deleteinmessage: any = '';
  messageerror: boolean = false;
  errormessage: any;
  errorresponse: any;

  deleteexeplan() {
    
    const apiUrl = this.apiurl + '/Crexecute/executeplan'
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    const requestBody = {
        "flag": "D",
        "itcrExecID": this.deleteitcrexecId,
        "itcrid": 0,
        "sysLandscape": 0,
        "executionStepName": "string",
        "executionStepDesc": "string",
        "assignedTo": 0,
        "startDt": "2024-05-27T13:04:04.576Z",
        "endDT": "2024-05-27T13:04:04.576Z",
        "attachments": "string",
        "status": "string",
        "forwardStatus": "string",
        "forwardedTo": 0,
        "forwardedDt": "2024-05-27T13:04:04.576Z",
        "reasonForwarded": "string",
        "remarks": "string",
        "pickedStatus": "string",
        "pickedDt": "2024-05-27T13:04:04.576Z",
        "actualStartDt": "2024-05-27T13:04:04.576Z",
        "actualEndDt": "2024-05-27T13:04:04.576Z",
        "dependSysLandscape": 0,
        "dependTaskId": 0,
        "createdBy": 0

    }
    setTimeout(() => {
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log("this is error response", response);
          this.errorresponse = response.type
          if (this.errorresponse == "E") {
            this.deleteinprogress = true;
            this.deleteinmessage = "There are open items it Can't be deleted"
          } else if (this.errorresponse == "S") {
            this.deletesuccess = true;
            this.deletemessage = "Deleted Task ID :"+this.deleteitcrexecId+" Successfully"
          }
        },
        (error: any) => {
          console.log('Post request failed', error);
          this.messageerror = true;
          this.errormessage = error;
        }
      );
    }, 500);
  }

  navigateinprogress() {
    this.deleteinprogress = false;
  }

  navigatesuccess() {
    this.deletesuccess = false;
    this.router.navigate(["/change-request"])
  }

}
