import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { PasscrdataService } from '../../passcrdata.service';
import { isNgTemplate } from '@angular/compiler';
import { isAnyArrayBuffer } from 'util/types';

@Component({
  selector: 'app-cr-task',
  templateUrl: './cr-task.component.html',
  styleUrl: './cr-task.component.css'
})
export class CrTaskComponent {

  crid: any;
  sysid: any;
  filtersys: any;
  supportid: any;
  supportname: any;
  
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute, private routeservice: PasscrdataService) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report;
    })
    this.routeservice.sysdata.subscribe(data => {
      this.sysid = data.report;
      this.filtersys = parseInt(this.sysid.value);
      
    })

    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;
  }

  itcrid: any = '';

  getidupdate() {
    this.itcrid = this.route.snapshot.paramMap.get('id');
  }
  
  private apiurl = environment.apiurls

  updatevalue: any;

  ngOnInit(): void {
    this.getvalue();
    this.fetchAllItems();
    this.Systemtask();
    this.getsystemlandscape();
    this.filterassignedItems();
    this.getsupportteamassign();
    this.getsupportteams();
    setTimeout(() => {
      this.getsupportteamassign();
      this.getsupportteams();
    }, 500);
  }

  itcrExecID: any = '';
  sysLandscape: any = '';
  executionStepName: any = '';
  executionStepDesc: any = '';
  assignedTo: any = '';
  startDt: any = '';
  endDT: any = '';
  attachments: any = '';
  statusece: any = '';
  forwardStatus: any = '';
  forwardedDt:any ='';
  reasonForwarded: any = '';
  remarks: any = '';
  pickedStatus: any = '';
  pickedDt: any = '';
  actualStartDt: any = '';
  actualEndDt: any = '';
  dependSysLandscape: any = '';
  dependTaskId: any = '';
  status: any = '';
  forwardonValue = this.forwardedDt ? this.forwardedDt : null;
  startDtValue = this.startDt ? this.startDt : null;
  endDTValue = this.endDT ? this.endDT : null;
  actualStartDtValue = this.actualStartDt ? this.actualStartDt : null;
  actualEndDtValue = this.actualEndDt ? this.actualEndDt : null;

  /*SelectStatus() {
    if (this.statusece == 'Assigned') {
      
    }
  }
*/

  errorMessage: any = '';
  successMessage: any = '';

  clearErrorMessage() {
    this.errorMessage = '';
  }
  clearSuccessMessage() {
    this.successMessage = '';
  }

  submitExexute() {
    if (this.statusece === 'Assigned') {
      if (!this.startDtValue) {
        alert('Select Planned Start Date');
      }
      else if (!this.endDTValue) {
        alert('Select Planned End Date');
      }
      else if (this.assignedTo === '') {
        alert('Enter Employee Name');
      }
      else if (this.pickedStatus != '') {
        if (!this.pickedDt) {
          alert('Enter Picked Date');
        }
        else if (!this.actualStartDtValue) {
          alert('Select Actual Start Date');
        }
      }
      
      else if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }


    if (this.statusece == 'Onhold') {
      if (this.pickedStatus !== '') {
        if (!this.startDtValue) {
          alert('Select Planned Start Date');
        }
        else if (!this.endDTValue) {
          alert('Select Planned End Date');
        }
        else if (this.statusece === '') {
          alert('Select Status');
        }
        else if (this.assignedTo == '') {
          alert('Enter Employee Name');
        }
        else if (!this.pickedDt) {
          alert('Select Picked Date');
        }
        else if (!this.actualStartDtValue) {
          alert('Select Actual Start Date');
        }
        else if (!this.actualEndDtValue) {
          alert('Select Actual End Date');
        }
        else if (this.executionStepName == '') {
          alert('Enter Execution Step Name');
        }
        else if (this.executionStepDesc == '') {
          alert('Enter Execution Step Desc');
        }
      }
      else if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }


    if (this.statusece == 'Completed') {
      if (!this.startDtValue) {
        alert('Select Planned Start Date');
      }
      else if (!this.endDTValue) {
        alert('Select Planned End Date');
      }
      else if (this.assignedTo == '') {
        alert('Enter Employee Name');
      }
      else if (this.pickedStatus == '') {
        alert('Select Picked Status');
      }
      else if (!this.pickedDt) {
        alert('Select Picked Date');
      }
      else if (this.actualStartDtValue == '' || this.actualStartDtValue == undefined) {
        alert('Select Actual Start Date');
      }
      else if (this.actualEndDtValue == '' || this.actualEndDtValue == undefined) {
        alert('Select Actual End Date');
      }
      else if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }


    if (this.statusece == 'Unassigned') {
      if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.pickedStatus !== '' && this.statusece != 'Completed') {
      if (!this.startDtValue) {
        alert('Select Planned Start Date');
      }
      else if (!this.endDTValue) {
        alert('Select Planned End Date');
      }
      else if (this.statusece === '') {
        alert('Select Status');
      }
      else if (this.assignedTo == '') {
        alert('Enter Employee Name');
      }
      else if (!this.pickedDt) {
        alert('Select Picked Date');
      }
      else if (!this.actualStartDtValue) {
        alert('Select Actual Start Date');
      }
      else if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.statusece == '' && this.pickedStatus == '') {
      if (this.executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }
  }


  ExecuteFunc() {
    const apiUrl = this.apiurl + '/Crexecute/executeplan';
    const assignedtouser = this.assignedTo.split("-")[0];
    const forwardedtouser = this.forwardedto.split("-")[0];
    const requestBody = {
      "flag": "I",
      "itcrid": this.crid.value.itcrid,
      "sysLandscape": this.sysid.value,
      "executionStepName": this.executionStepName.trim(),
      "executionStepDesc": this.executionStepDesc.trim(),
      "assignedTo": assignedtouser ? assignedtouser : null,
      "startDt": this.startDtValue ? this.startDtValue : null,
      "endDT": this.endDTValue ? this.endDTValue : null,
      "attachments": this.attachments.trim(),
      "status": this.statusece.trim(),
      "forwardStatus": this.forwardStatus.trim(),
      "forwardedTo": forwardedtouser ? forwardedtouser : null,
      "forwardedDt": this.forwardonValue,
      "reasonForwarded": this.reasonForwarded.trim(),
      "remarks": this.remarks.trim(),
      "pickedStatus": this.pickedStatus.trim(),
      "pickedDt": this.pickedDt ? this.pickedDt : null,
      "actualStartDt": this.actualStartDtValue,
      "actualEndDt": this.actualEndDtValue,
      "dependSysLandscape": this.dependSysLandscape ? this.dependSysLandscape : null,
      "dependTaskId": this.dependTaskId ? this.dependTaskId : null,
      "createdBy": this.supportid,

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        alert("Change ID" + " " + this.crid.value.itcrid + " " + ": Impelmentation Task ID is successsfully Saved")
        this.goToTab('contact');
        this.viewemail();

      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
    }
  Cremailvalue: any[] = [];
  viewemail() {

    const apiUrl = this.apiurl + '/Crtaskemail/GetCrTaskEmail'
    const requestBody = {

    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.Cremailvalue = response.filter((item: any) => item.itcrid === this.crid.value.itcrid);
        console.log(this.Cremailvalue);
      },
      (error: any) => {
        console.log('Post request failed', error);

      });
    this.sendemailfrom(this.Cremailvalue)
  }

  sendemailfrom(response: any) {
    
    const apiUrl = this.apiurl + '/Email'
    const CrRequest = response[0].crrequestedBy
    const to = response[0].crremail
    const cc = response[0].croemail
    //const cc2 = response[0].crremail
    const cc2 = "yavanthi@techvaraha.com"
    const requestdate = response[0].crdate
    const changeDesc = response[0].changeDesc
    const output = `
   
    Dear ${CrRequest},

    For FollowingChnage Id, the Task ID is assigned to your Que under Implementation

          CR ID: ${response[0].itcrid}
          Requestor Name: ${CrRequest}
          Requested Date: ${requestdate}
          Phase: RFC Initial Approval
          Status: Assigned
          Change Description: ${changeDesc}
          ----------------------------------------------------------------------------
          Task ID :${response[0].taskId}
          Task Assigned:${response[0].estatus}
          Task Status:${response[0].estatus}
          Task Assinged to:${response[0].assignedToName}
          Task Description :${response[0].taskDesc}


          http://www.unnati.microlabs.co.in Click here to Log into Unnati and view your status.
          Regards,
          IT Team
          Micro Labs Ltd
          http://www.unnati.microlabs.co.in
          www.unnati.microlabs.co.in`;

    console.log(output);
    const requestBody = {
      "to": to, //Recipients: Requestor, Change Analyst
      "cc": cc, cc2,   //this.emailofreciver,
      "subject": `For following Change ID :${CrRequest}: the Task Id: ${response[0].taskId} assigned to Que your under Implementation`,
      "body": output

      //Recipients: Requestor, Change Analyst
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.log('Post request failed', error);

      });
  }



  goToTab(tabId: string) {
    const itcrid = this.crid.value.itcrid;
    this.router.navigate([`/executive/${itcrid}/edit`], { fragment: tabId });
    setTimeout(() => {
      const tabButton = document.getElementById(tabId + '-tab');
      if (tabButton) {
        tabButton.click();
      }
    });
  }

  employeeid: any[] = [];
  getvalue() {
    
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function", response);
        this.employeeid = response;
        console.log("suportid",this.employeeid)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });

  }

  /*search filter*/
  forwardedto: any = '';
  dropdownItems: string[] = [];
  selectedValue: string = '';
  supportteamname: string[] = [];
  supportnames: string[] = [];

  fetchAllItems() {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        console.log("Function", response);
        
        // Extracting only the 'firstname' field from each object in the response array
        this.supportteamname = response.map(item => item.empId + '-' + item.firstName + " " + item.lastName);
        this.supportteamname = this.supportteamname.filter((value, index, self) => self.indexOf(value) === index);
        //this.supportteamname = this.supportteamname.filter((item: any) => item.categoryId === this.crid.value.itcategoryId);
        console.log("supportid", this.supportteamname);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

  filterItems() {
    const filter = this.forwardedto.toUpperCase();
    this.dropdownItems = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItems.push('No name found');
    }
    else if (filter ==='') {
      this.dropdownItems.length=0
    }
  }

  selectItem(item: string) {
    this.selectedValue = item;
    this.forwardedto = item;
    this.dropdownItems = [];
  }

  /*Assigned to filter*/
  dropdownassignedItems: string[] = [];
  selectedassignedValue: string = '';
  
  filterassignedItems() {
    const filter = this.assignedTo.toUpperCase();

    this.dropdownassignedItems = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    

    if (this.dropdownassignedItems.length === 0 && filter !== '') {
      this.dropdownassignedItems.push('No name found');
    }
    else if (filter === '') {
      this.dropdownassignedItems.length = 0
    }
  }

  selectItemasignto(item: string) {
    this.selectedassignedValue = item;
    this.assignedTo = item;
    this.dropdownassignedItems = [];
  }
  /*task name*/ 
  taskname: any;
  Systemtask() {
    const apiUrl = this.apiurl + '/SystemLandscape/Allsystems';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.taskname = response.filter((item: any) => item.sysLandscapeId === this.filtersys);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  /*systemlandscape*/
  systemlandscape: any[] = [];
  getsystemlandscape() {

    const apiUrl = this.apiurl + '/SystemLandscape/Getsystems';
    const requestBody = {
      "categroyId": this.crid.value.itcategoryId,
      "supportId": this.crid.value.supportId,
      "classificationId": this.crid.value.itclassificationId
    };
    this.http.post(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Sys", response);
        this.systemlandscape = response.filter((item: any) => item.sysLandscapeId <= this.filtersys);
        for (var i of this.systemlandscape) {
          console.log('final', i);
        }
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }


  depdenttask: any[] = [];
  getdepdenttask() {
    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function", response);
        this.depdenttask = response.filter((item: any) => item.sysLandscapeid === parseInt(this.dependSysLandscape) &&
          item.itcrid === this.crid.value.itcrid);
        console.log("geting depandent task", this.depdenttask)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  /*login users*/
  supportteams: any[] = [];
  getsupportid: any;
  supportpersonname: any;
  firstname: any;
  middlename: any;
  lastname: any;

  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId
        this.firstname = this.supportteams[0].firstName
        this.middlename = this.supportteams[0].middleName
        this.lastname = this.supportteams[0].lastName
        this.supportpersonname = this.firstname + this.middlename + this.lastname
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    this.getsupportteamassign()
  }

  supportteamassign: any[] = [];
  issupportegineer: any;
  supportengineername: any;
  getsupportengineerid:any;

  getsupportteamassign() {
     
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.supportengineername = response.filter((row: any) => row.isSupportEngineer === this.issupportegineer);
        this.getsupportengineerid = this.supportengineername.supportTeamId
        console.log("this is support id", this.supportengineername)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
}
