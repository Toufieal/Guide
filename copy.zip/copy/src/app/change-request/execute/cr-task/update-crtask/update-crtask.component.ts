import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PasscrdataService } from '../../../passcrdata.service';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-update-crtask',
  templateUrl: './update-crtask.component.html',
  styleUrl: './update-crtask.component.css'
})
export class UpdateCrtaskComponent {
  crid: any;
  sysid: any;
  filtersys: any;
  supportid: any;
  supportname: any;
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute, private routeservice: PasscrdataService) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report;
    })
    this.routeservice.sysdata.subscribe(data => {
      this.sysid = data.report;
      this.filtersys = parseInt(this.sysid.value);
    });

    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;
  }

  itcrexecId: any = '';
  getidupdate() {
    this.itcrexecId = this.route.snapshot.paramMap.get('id');
    
  }

  private apiurl = environment.apiurls

  errorMessage: any = '';
  successMessage: any = '';

  clearErrorMessage() {
    this.errorMessage = '';
  }
  clearSuccessMessage() {
    this.successMessage = '';
  }

  ngOnInit(): void {
    this.getidupdate()
    this.getvalue();
    this.getupdatyevalue(this.itcrexecId);
    this.getexecuteid();
    this.Systemtask();
    this.getsystemlandscape();
    this.getdepdenttask();
    this.iniatorid();
    this.crrequestors();
    this.fetchAllItems();
    this.filterItems();
    this.getexecutionhistory();
   
  }
  
  getexecuteid() {  
    this.itcrexecId = this.route.snapshot.paramMap.get('id');
  }

  
  itcrExecID: any = '';
  sysLandscape: any = '';
  executionStepName: any = '';
  executionStepDesc: any = '';
  assignedTo: any = '';
  startDt: any = '';
  endDT: any = '';
  attachments: any = '';
  statusece: any = '';
  forwardStatus: any = '';
  forwardedTo: any = '';
  forwardedDt: any='';
  reasonForwarded: any = '';
  remarks: any = '';
  pickedStatus: any = '';
  pickedDt: any = '';
  actualStartDt: any = '';
  actualEndDt: any = '';
  dependSysLandscape: any = '';
  dependTaskId: any = '';
  status: string = 'Implemented';
  /*forwardonValue = this.forwardedDt ? this.forwardedDt : null;
  startDtValue = this.startDt ? this.startDt : null;
  endDTValue = this.endDT ? this.endDT : null;
  actualStartDtValue = this.actualStartDt ? this.actualStartDt : null;
  actualEndDtValue = this.actualEndDt ? this.actualEndDt : null;*/
  assignedtoid: any = '';
  updatevalue: any = '';
  updatestatus: any = '';
  forwardstatus: any = '';
  pickedstatus: any = '';
  Startdate: any = '';
  enddate: any = '';
  forwardtoid: any = '';
  getupdatyevalue(itcrexecId: any) {

    const apiUrls: any = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };

    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.updatevalue = response.filter((item: any) => Number(item.itcrexecId) === Number(this.itcrexecId));
        this.assignedtoid = this.updatevalue[0].assignedtoid;
        this.updatestatus = this.updatevalue[0].status.trim();
        this.forwardtoid = this.updatevalue[0].forwardedtoid;
        if (this.forwardtoid != '')
          this.forwardstatus = 'Forwarded'
        else
          this.forwardstatus = 'Not Forwarded'
       // this.forwardstatus = this.updatevalue[0].forwardStatus.trim();
        this.Startdate = this.updatevalue[0].startDt;
        this.enddate = this.updatevalue[0].endDt;
        this.pickedDt = this.updatevalue[0].pickedDt;
        
       // alert('imple start date' + this.Startdate + 'end date' + this.enddate)
        /*if (this.itcrtd = this.updatevalue)*/
        setTimeout(() => {
          const assignedtosupport = parseInt(this.setassignedname.split("-")[0]);
          this.getcrdata(this.crid.value.itcrid);
          this.getsupportdata(this.assignedtoid);
          
        }, 500);
        
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }
  crdesc: any = '';
  crdateval: any = '';
  crrempid: any = '';
  crrdtls: any[] = [];
  getcrdata(itcrid: any) {

    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.crrdtls = response.filter((item: any) => item.itcrid.toString() === itcrid.toString());
        this.crdesc = this.crrdtls[0].changeDesc;
        this.crdateval = this.crrdtls[0].crdate;
        this.crrempid = this.crrdtls[0].crrequestedBy
        //alert('crdesc' + this.crdesc)
        this.crdtls(this.crrempid, 'crr');
       // alert('crr' + this.crrempid);
        this.crdtls(this.crrempid, 'cro');
       // alert('cro' + this.crrempid);
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }
  assignedto: any = '';
  assignedname: any = '';
  assignedemail: any = '';
  assgn: any[] = [];

  getsupportdata(id:Number) {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.assgn = response.filter((item: any) => item.empId === id);
        this.assignedname = this.assgn[0].empId + "-" + this.assgn[0].firstName + " " + this.assgn[0].lastName
        this.assignedemail = this.assgn[0].email;
        console.log('this.assgn', this.assgn)
        //alert('assignedemail' + this.assignedemail + 'name ' + this.assignedname)
        //this.criequestedBy = this.assgn[0].firstName + " " + this.assgn[0].middleName + " " + this.iniatorsid[0].lastName
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
    console.log(this.assignedname);

  }
  crrequestedby: any[] = [];
  crremail: any = '';
  croemail: any = '';
  crrequestedBy: any = '';
  crownername: any = '';
  
  crdtls(id:Number,person:string) {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        if (person == 'crr') { 
        this.crrequestedby = response.filter((item: any) => item.empId === id);
        this.crremail = this.crrequestedby[0].email;
        this.crrequestedBy = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
        }
        else {
          this.crrequestedby = response.filter((item: any) => item.empId === id);
          this.croemail = this.crrequestedby[0].email;
          this.crownername = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
        }
        console.log('crdtls', this.crrequestedby)
        console.log('crremail', this.crremail)
        console.log('croemail', this.croemail)
        },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  submitExexute() {

    if (this.updatestatus == 'Assigned' && this.updatevalue[0].pickedStatus == '') {
      if (!this.updatevalue[0].startDt || this.updatevalue[0].startDt == '') {
        alert('Select Planned Start Date');
      }
      else if (!this.updatevalue[0].endDt || this.updatevalue[0].endDt == '') {
        alert('Select Planned End Date');
      }
      else if (this.setassignedname === '') {
        alert('Enter Employee Name');
      }
      else if (this.updatevalue[0].pickedStatus != '') {
        if (!this.updatevalue[0].pickedDt || this.updatevalue[0].pickedDt == '') {
          alert('Enter Picked Date');
          const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="updatevalue[0].pickedDt"]');
          if (selectElement) {
            selectElement.focus();
          }

          else if (!this.updatevalue[0].actualStartDt) {
            alert('Select Actual Start Date');
          }
        }
        else if (this.updatevalue[0].executionStepName == '') {
          alert('Enter Execution Step Name');
        }
        else if (this.updatevalue[0].executionStepDesc == '') {
          alert('Enter Execution Step Desc');
        }
        else {
          this.ExecuteFunc()
        }
      }
      
      else if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.updatestatus == 'Onhold') {
      if (this.updatevalue[0].pickedStatus != '') {
        if (!this.updatevalue[0].startDt || this.updatevalue[0].startDt == '') {
          alert('Select Planned Start Date');
        }
        else if (!this.updatevalue[0].endDt || this.updatevalue[0].endDt == '') {
          alert('Select Planned End Date');
        }
        else if (this.setassignedname == '') {
          alert('Enter Employee Name');
        }
        else if (!this.updatevalue[0].pickedDt || this.updatevalue[0].pickedDt == '') {
          alert('Select Picked Date');
        }
        else if (!this.updatevalue[0].actualStartDt) {
          alert('Select Actual Start Date');
        }
        else if (this.updatevalue[0].executionStepName == '') {
          alert('Enter Execution Step Name');
        }
        else if (this.updatevalue[0].executionStepDesc == '') {
          alert('Enter Execution Step Desc');
        }
        else {
          this.ExecuteFunc()
        }
      }
      else if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.updatestatus == 'Completed') {
      if (!this.updatevalue[0].startDt || this.updatevalue[0].startDt == '') {
        alert('Select Planned Start Date');
      }
      else if (!this.updatevalue[0].endDt || this.updatevalue[0].endDt == '') {
        alert('Select Planned End Date');
      }
      else if (this.setassignedname == '') {
        alert('Enter Employee Name');
      }
      else if (this.updatevalue[0].pickedStatus == '') {
        alert('Select Picked Status');
      }
      else if (!this.updatevalue[0].pickedDt || this.updatevalue[0].pickedDt == '') {
        alert('Select Picked Date');
      }
      else if (!this.updatevalue[0].actualStartDt || this.updatevalue[0].actualStartDt == '') {
        alert('Select Actual Start Date');
      }
      else if (!this.updatevalue[0].actualEndDt || this.updatevalue[0].actualEndDt == '') {
        alert('Select Actual End Date');
      }
      else if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.updatestatus == 'Unassigned') {
      if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.updatevalue[0].pickedStatus != '' && this.updatestatus != 'Completed') {
      if (!this.updatevalue[0].startDt || this.updatevalue[0].startDt == '') {
        alert('Select Planned Start Date');
      }
      else if (!this.updatevalue[0].endDt || this.updatevalue[0].endDt == '') {
        alert('Select Planned End Date');
      }
      else if (this.setassignedname == '') {
        alert('Enter Employee Name');
      }
      else if (!this.updatevalue[0].pickedDt || this.updatevalue[0].pickedDt == '') {
        alert('Select Picked Date');
      }
      else if (!this.updatevalue[0].actualStartDt) {
        alert('Select Actual Start Date');
      }
      else if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }

    if (this.updatestatus == '' && this.updatevalue[0].pickedStatus == '' ) {
      if (this.updatevalue[0].executionStepName == '') {
        alert('Enter Execution Step Name');
      }
      else if (this.updatevalue[0].executionStepDesc == '') {
        alert('Enter Execution Step Desc');
      }
      else {
        this.ExecuteFunc()
      }
    }
    
  }

  ExecuteFunc() {
    const apiUrl = this.apiurl + '/Crexecute/executeplan'
    const assignedtosupport = parseInt(this.setassignedname.split("-")[0]);
    const forwardedtosupport = parseInt(this.setforwardedto.split("-")[0]);
    const requestBody = {
      "flag": "U",
      "itcrExecID": this.itcrexecId,
      "itcrid": this.crid.value.itcrid,
      "sysLandscape": this.updatevalue[0].sysLandscapeid,
      "executionStepName": this.updatevalue[0].executionStepName,
      "executionStepDesc": this.updatevalue[0].executionStepDesc,
      "assignedTo": assignedtosupport ? assignedtosupport : null,
      "startDt": this.updatevalue[0].startDt ? this.updatevalue[0].startDt : null,
      "endDT": this.updatevalue[0].endDt ? this.updatevalue[0].endDt : null,
      "attachments": this.attachments,
      "status": this.updatestatus,
      "forwardStatus": this.forwardstatus,
      "forwardedTo": forwardedtosupport ? forwardedtosupport : null,
      "forwardedDt": this.updatevalue[0].forwardedDt ? this.updatevalue[0].forwardedDt : null,
      "reasonForwarded": this.updatevalue[0].reasonForwarded,
      "remarks": this.updatevalue[0].remarks,
      "pickedStatus": this.updatevalue[0].pickedStatus,
      "pickedDt": this.updatevalue[0].pickedDt ? this.updatevalue[0].pickedDt : null,
      "actualStartDt": this.updatevalue[0].actualStartDt ? this.updatevalue[0].actualStartDt : null,
      "actualEndDt": this.updatevalue[0].actualEndDt ? this.updatevalue[0].actualEndDt : null,
      "dependSysLandscape": this.updatevalue[0].dependSysLandscapeid,
      "dependTaskId": this.updatevalue[0].dependTaskId,
      "createdBy": parseInt(this.supportid),
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
        if (this.updatestatus == "Assigned" && this.updatevalue[0].pickedStatus != "Picked") {
          alert("Change ID" + " " + this.crid.value.itcrid + " " + ": Implementation Task ID is successfully Assigned")
          setTimeout(() => {
            this.sendemailfrom(this.updatestatus);
          },3000)
        }
        else if (this.updatevalue[0].pickedStatus == "Picked" && this.updatestatus == "Assigned") {
          alert("Change ID" + " " + this.crid.value.itcrid + " " + ": Implementation Task ID is successfully Picked")
          setTimeout(() => {
            this.sendemailfrom(this.updatevalue[0].pickedStatus);
          }, 3000)
        }
        else if (this.updatestatus == "Completed") {
          alert("Change ID" + " " + this.crid.value.itcrid + " " + ": Implementation Task ID is successfully Completed")
          this.sendemailfrom(this.updatestatus);
        }
        else {
          alert("Change ID" + " " + this.crid.value.itcrid + " " + " Update Successfully")
        }
        this.goToTab('contact');
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  Cremailvalue: any[] = [];
  viewemail(status: any) {
    //debugger//api/Crtaskemail/GetCrTaskEmail
    //const apiUrl = this.apiurl + '/Crtaskemail/GetCrTaskEmail'
    //const requestBody = {

    //}
    //this.http.get(apiUrl, requestBody).subscribe(
    //  (response: any) => {
    //    this.Cremailvalue = response.filter((item: any) => item.itcrid === this.crid.value.itcrid && item.taskId === Number(this.itcrexecId) );
    
    setTimeout(() => {
         
          this.sendemailfrom(status)
        }, 500);
      
      (error: any) => {
        console.log('Post request failed', error);

      }
    
  }

  crdate: any = '';
  assignDate: any = '';
  sendemailfrom(status:any) {
    //debugger
   // alert('assign in send ' + this.assignedemail + 'dd' + this.croemail +'crr' + this.crremail);
    const apiUrl = this.apiurl + '/Email'
    const CrRequest = this.crrequestedBy
    const to = this.assignedemail
    //const to = 'yavanthi@techvaraha.com'
    const cc = this.crremail;
    //const cc1 = 'yavanthishivakumar@gmail.com';
    const cc2 = this.croemail;
    const requestdate = this.crdateval;
    //this.crdate = requestdate.toISOString().slice(0, 10);
    const changeDesc = this.crdesc
    const assigneddate = this.assignDate
    //this.assignDate = assigneddate.toISOString().slice(0, 10);
    const output = this.readHtmlFile('assets/emailexecute.html');
    console.log(output);

    const populatedOutput = output
      .replace('${crid}', this.crid.value.itcrid)
      .replace('${crid}', this.crid.value.itcrid)
      .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
      .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
      .replace('{{this.Cremailvalue[0].crdate}}', requestdate)
      .replace('{{this.Cremailvalue[0].changeDesc}}', changeDesc)
      .replace('${status}', status)
      .replace('${status}', status)
      .replace('${response[0].taskId}', this.itcrexecId)
      .replace('${response[0].taskId}', this.itcrexecId)
      .replace('${response[0].estatus}', this.updatestatus)
      .replace('${response[0].estatus}', this.updatestatus)
      .replace('${response[0].assignedToName}', this.assignedname)
      .replace('${response[0].assignedToName}', this.assignedname)
      .replace('${response[0].assignedDt}', this.crdateval)
      .replace('${response[0].taskDesc}', this.updatevalue[0].executionStepDesc)
    const requestBody = {
      "to": to, //Recipients: Requestor, Change Analyst
      "cc": cc, cc2,   //this.emailofreciver,
      "subject": `For following Change ID :${this.crid.value.itcrid}: the Task Id: ${this.itcrexecId} assigned to Queued your under Implementation`,
      "body": populatedOutput

      //Recipients: Requestor, Change Analyst
    }

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.log('Post request failed', error);

      });
  }
  readHtmlFile(file: string): string {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', file, false);
    xhr.send();
    if (xhr.status === 200) {
      return xhr.responseText;
    } else {
      console.error('Failed to read HTML file:', file);
      return ''; // or handle error accordingly
    }
  }
  goToTab(tabId: string) {
    const itcrid = this.crid.value.itcrid;
    this.router.navigate([`/executive/${itcrid}/edit`], { fragment: tabId });
    setTimeout(() => {
      const tabButton = document.getElementById(tabId + '-tab');
      if (tabButton) {
        tabButton.click();
      }
    },500);
  }

  employeeid: any[] = [];
  getvalue() {

    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function", response);
        this.employeeid = response;
        console.log("suportid", this.employeeid)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });

  }

  /*search filter*/
  dropdownItems: string[] = [];
  dropdownItemscr: string[] = [];
  selectedValue: string = '';
  selectedValuecr: string = '';
  supportteamname: string[] = [];
  supportnames: string[] = [];

  fetchAllItems() {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        console.log("Function", response);
        this.supportteamname = response.map(item => item.empId + '-' + item.firstName + " " + item.lastName);
        this.supportteamname = this.supportteamname.filter((value, index, self) => self.indexOf(value) === index);

       // this.supportnames = response.map(item => item.empId + '-' + item.firstName + " " + item.lastName);
       // this.supportteamname = this.supportnames;

        console.log("Support Team Name", this.supportteamname);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

  dropdownsupportteamid: any;
  filterItems() {
    const filter = this.setassignedname.toUpperCase();
    this.dropdownItems = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)

    );
    /* this.dropdownsupportteamid = this.supportteamid.filter();*/
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItems.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItems.length = 0
    }

  }
  selectItem(item: string) {
    this.selectedValue = item;
    this.setassignedname = item;
    this.dropdownItems = [];
  }

  supportassignedto: any[] = [];
  setassignedname: any='';

  iniatorid() {
     
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.supportassignedto = response.filter((item: any) => item.empId === parseInt(this.updatevalue[0].assignedtoid));
        this.setassignedname = this.supportassignedto[0].empId + "-" + this.supportassignedto[0].firstName + " " + this.supportassignedto[0].lastName
        console.log("get assignedto", this.setassignedname)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  supforwardedto: any[] = [];
  setforwardedto: any='';

  crrequestors() {
    const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.supforwardedto = response.filter((item: any) => item.empId === parseInt(this.updatevalue[0].forwardedtoid)); 
        this.setforwardedto = this.supforwardedto[0].empId + "-" + this.supforwardedto[0].firstName + " " + this.supforwardedto[0].lastName
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  filterItemscr() {
    const filter = this.setforwardedto.toUpperCase();
    this.dropdownItemscr = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItemscr.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItemscr.length = 0
    }
  }

  selectItemcr(item: string) {
    this.selectedValuecr = item;
    this.setforwardedto = item;
    this.dropdownItemscr = [];
  }

  /*task name*/
  taskname: any;
  Systemtask() {
    const apiUrl = this.apiurl + '/SystemLandscape/Allsystems';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.taskname = response.filter((item: any) => item.sysLandscapeId === this.updatevalue[0].sysLandscape);
        console.log('this data', this.taskname)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }
  /*systemlandscape*/
  systemlandscape: any[] = [];
  getsystemlandscape() {
    
    const apiUrl = this.apiurl + '/SystemLandscape/Allsystems';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.systemlandscape = response.filter((item: any) => item.sysLandscapeId <= this.updatevalue[0].dependSysLandscapeid);
        console.log('this data', this.systemlandscape)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }


  depdenttask: any[] = [];
  getdepdenttask() {
     
    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function", response);
        this.depdenttask = response.filter((item: any) => item.sysLandscapeid === this.updatevalue[0].dependSysLandscapeid &&
          item.itcrid === this.crid.value.itcrid);
        console.log("geting depandent task", this.depdenttask)
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  executionhistory: any[] = [];
  getexecutionhistory() {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrExecutionPlanHistory?id=' + this.crid.value.itcrid

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.executionhistory = response.filter((item: any) =>parseInt(item.itcrexecId) === parseInt(this.itcrexecId));

        console.log('responsetablew', response)
      },
      (error) => {
        console.error("Data fetching error", error)
      }
    )
  }
}


