import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
//import { debug } from 'console';
import { PasscrdataService } from '../passcrdata.service';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-execute',
  templateUrl: './execute.component.html',
  styleUrls: ['./execute.component.css']
})
export class ExecuteComponent {

  isActive: string = 'implement'; 

  setActiveTab(tab: string): void {
    this.isActive = tab;
  }
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  activeflag: boolean = true;

  tabs: any[] = [];
  numberOfTabs: number = 1;
  plantData: any[] = [];
  status: any = '';
  approver: any = '';
  appdate: any = '';
  attach: any = '';
  remark: any = '';
  comment: any = '';
  crid: any = '';
  getstatus: any = '';
  isApproved: any = '';
  isImplemented: any = '';
  isReleased: any = '';
  isSubmitted: any = '';
  isCompleted: any = '';
  getstage: any = '';
  getRejData: string = '';
  constructor(private http: HttpClient, private router: Router, private routeservice: PasscrdataService) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value
      //this.crid = this.crid.itcrid;
      this.getstatus = this.crid.status.trim();
      
      this.getstage = this.crid.stage.trim();
      this.isApproved = this.crid.isApproved;
      this.isImplemented = this.crid.isImplemented;
      this.isReleased = this.crid.isReleased;
      this.isSubmitted = this.crid.isSubmitted;
     // alert('s submitted ' + this.isSubmitted +'is implemented' + this.isImplemented + 'Released??' + this.isReleased + 'status??' + this.status)
    })

    this.routeservice.RejectDta.subscribe(data => {
      this.getRejData = data.actvFlg.activeFlg;
      if (this.getRejData == 'false') {
        this.activeflag = false
      } else {
        this.activeflag = true
      }
    })
  }

  
  private apiurl = environment.apiurls
  
  removeTab() {
    if (this.tabs.length > 0) {
      this.tabs.pop();
    }
  }
 
  handleFileInput(event: any, index: number) {
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }

  uniqueLandscapes: string[]=[];

  type: any = '';
  data: any = [];
  items: any[] = [];
  selectedCategory: string = '';
  filteredData: any[] = [];
  landscapeOptions: number[] = [];
  exectivevalue: any[] = [];
  checkstatus: any = '';
  
  ngOnInit(): void {
    // Extract unique sysLandscape values from data
    this.landscapeOptions = this.value.map((item: { sysLandscape: any; }) => item.sysLandscape)
      .filter((value: any, index: any, self: string | any[]) => self.indexOf(value) === index);
    console.log("Value", this.landscapeOptions);
    this.checkstatus = this.getstatus.trim();
   
  }


  value: any[] = [];
  getvalue() {

    const apiUrl = this.apiurl + '/Crexecute/GetExecute';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("Function",response);
        this.value = response;
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }
  /*Common texts*/
}
