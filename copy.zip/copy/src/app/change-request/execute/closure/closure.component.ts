import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { PasscrdataService } from '../../passcrdata.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-closure',
  templateUrl: './closure.component.html',
  styleUrl: './closure.component.css'
})
export class ClosureComponent {

  crid: any = '';
  today:any;
  supportid:any;
  supportname:any;
  currentdate:any;
  stage: any;
  appstatus: any;
  status: any = '';
  appflag: any = '';
  remark: any = '';
  comment: any = '';
  APILevel: Number = 1;
  isReadOnly: boolean = false;
  isReadOnly2: boolean = false;
  isReadOnly3: boolean = false;
  rfcapproverlevel: string = '';
  isApproved: any;
  categoryId: any = '';
  selectedOption: string = '';
  classificationId: any = '';
  approveflag: boolean = true;
  isSupport: boolean = true;
  plantData: any[] = [];
  getcrid: any[] = [];
  getcrcode: string = '';
  crownername: string = '';
  isCompleted: boolean = false;
  plantidforapp: any = ' ';
  date: any = ' ';
  currentday: any = ' ';
  constructor(private http: HttpClient, private datepipe:DatePipe, private routeservice: PasscrdataService, private route: ActivatedRoute,private router:Router) {
    this.routeservice.crdata.subscribe(data => {
      this.crid = data.report.value;
       this.itcrid = this.crid.itcrid;
      this.appstatus = this.crid.status.trim();
      this.status = this.crid.status.trim();
      this.stage = this.crid.stage.trim();
      this.crownername = this.crid.crowner;
      this.plantidforapp = this.crid.plantcode
      
    })
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    this.supportname = this.routeservice.supporterName;
    console.log('1stsupportname', this.supportname)
    this.routeservice.crdata.subscribe(data => {
      this.isApproved = this.crid.isApproved;
      this.categoryId = this.crid.itcategoryId;
      this.classificationId = this.crid.itclassificationId
      if (this.isApproved == true) {//== "Approved" && this.stage == "Approval" || this.status == "" && this.stage == "Approval" ) {
        this.approveflag = false;
      }
      else {
        this.approveflag = true;
      }
    })
    this.StageStatus();
    //this.Approver1();
    this.getsupportteams();
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
    console.log('closure supportid', this.supportid);
    this.supportname = this.routeservice.supporterName;
    console.log('2ndsupportname', this.supportname)
    const currentDate = new Date()
    const datePart = currentDate.toISOString().slice(0, 10);
    const timePart = currentDate.getHours().toString().padStart(2, '0') + ':' +
      currentDate.getMinutes().toString().padStart(2, '0') + ':' +
      currentDate.getSeconds().toString().padStart(2, '0');
    this.date = `${datePart} ${timePart}`;
    this.currentday = `${datePart} ${timePart}`;
    this.today = currentDate.toISOString().slice(0, 10);
    this.currentdate = currentDate.toISOString().slice(0, 10);

    this.routeservice.crdata.subscribe(data => {
      this.getcrid = [data.report];
    })
    this.getcrcode = this.getcrid[0].value.crcode;
    this.getData();
  }
  tab1: boolean = true;

  showfunction() {
    this.supportid == 2;
    if (this.supportid == 2) {
      this.tab1 = true;
    }
  }
  
  selectedTab: number = 0;
  count: any;
  // Method to show the selected tab
  showTab(index: number) {
    this.selectedTab = index;
  }

  approver1Name: String = '';
  approver2Name: String = '';
  approver3Name: String = '';

  ngOnInit(): void {
    this.getidupdate();
    //this.getrequetervalue(this.crid.itcrid);
    this.getapprovestatus();
    this.getsupportteams();
    this.getupdatyevalue();
    this.getapproverslevel();
    this.getcrdata();
    this.getCloserdtls();
    this.getfollowupdtls();
    this.getlessonsdtls();
    this.usersupportteams()
    setTimeout(() => {
      this.getsupportteamassign();
      this.GetApprover(1);
      this.ReleasedStatus();
      this.StageStatus();
      this.crrequestors();
    }, 1000);
    setTimeout(() => {
      this.GetApprover(1);
    }, 500);
  }
  private apiurl = environment.apiurls;

  handleFileInput(event: any, index: number) {
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }

  getidupdate() {

    this.itcrid = this.route.snapshot.paramMap.get('id');
  }//ff
  approvervalue: any = '';
  approverCount: any = '';
  supportapp1: any; supportapp2: any; supportapp3: any; supportapp: any;
  supportapp1ID: any; supportapp2ID: any; supportapp3ID: any;
  appvflg: boolean = false;
 
  approverdata: any[] = [];
  
  data = 2; // Or any value you want
  approvers: any[] = [];


  initializeApprovers() {

  }

  counter(i: number) {
    return new Array(i);
  }

  isapprover: any[] = [];
  getapprovestatus() {

    const apiUrl = this.apiurl + '/SupportteamAssigned';
    const requestBody = {
    }
    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        console.log("approver id taken", response);
        this.isapprover = response.filter((item: any) => item.itcrid === this.crid.value.itcrid);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  selectedFile: any = '';
  getattach(event: any): void {
    this.selectedFile = event.target.files[0];
  }


  addFile(): void {
    if (!this.selectedFile) {
      console.error('No file selected.');
      return;
    }

    if (!this.crid.itcrid) {
      console.error('ITCRID is required.');
      return;
    }

    const itcrid = this.crid.itcrid.toString();
    const formData = new FormData();
    formData.append('itcrid', itcrid);
    formData.append('file', this.selectedFile, this.selectedFile.name);
    const apiUrl = this.apiurl + '/CRlession'; // Adjust the API endpoint as per your route

    this.http.post(apiUrl, formData).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.error('POST request failed', error);
      }
    );
  }
  viewFile(itcrid: string, fileName: string): void {
    const apiUrl = `${this.apiurl}/CRlession/GetFile?itcrid=${itcrid}&fileName=${fileName}`;

    this.http.get(apiUrl, { responseType: 'blob' }).subscribe(
      (response: Blob) => {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }


  crval: any[] = [];
  crrname: any = '';
  croname: any = '';

  crempid: any = '';
  cremail: any = '';
  getcrinfo(empid: Number, person: string) {
    const apiUrl = this.apiurl + '/SupportTeam';
    this.http.get<any[]>(apiUrl).subscribe(
      (response: any[]) => {
        this.crval = response.filter(item => item.empId === Number(empid))

        if (person == 'cro') {
          this.croname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.croemail = this.crval[0].email
        }
        else {
          this.crrname = this.crval[0].firstName + " " + this.crval[0].middleName + " " + this.crval[0].lastName;
          //this.crrempid = this.crval[0].empId
          this.crremail = this.crval[0].email
        }
        // alert('crr email' + this.crremail + 'emp id' + this.crrempid)
        // alert('cro email' + this.croemail + 'emp id' + this.crrempid)
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

   supportpersonname: any = ''
  firstname: any = ''
  middlename: any = ''
  lastname: any = ''
  employeeid: any = ''

  supportteams : any []=[]
  usersupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("SupportId:", this.supportid)
        this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
        this.employeeid = this.supportteams[0].empId;
        this.firstname = this.supportteams[0].firstName;
        this.middlename = this.supportteams[0].middleName;
        this.lastname = this.supportteams[0].lastName;
        /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
        if (this.firstname !== null && this.firstname !== undefined) {
          this.supportpersonname += this.firstname;

        }

        if (this.middlename !== null && this.middlename !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating middle name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.middlename;
        }

        if (this.lastname !== null && this.lastname !== undefined) {
          // If the supportpersonname is not empty, add a space before concatenating last name
          if (this.supportpersonname !== '') {
            this.supportpersonname += ' ';
          }
          this.supportpersonname += this.lastname;
        }

        
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  crrempid: any = ''
  croempid: any = ''
  croemailid: any = ''
  crdate: any = ''
  crrdate: any = ''
  crdesc: any = ''
  emailCR: any[] = []

  getcrdata() {
    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.emailCR = response.filter((item: any) => item.itcrid === Number(this.crid.itcrid))
        console.log('cr info', this.emailCR)
        this.crrempid = this.emailCR[0].crrequestedBy
        this.croempid = this.emailCR[0].crowner
        this.crdate = this.emailCR[0].crdate
        this.crrdate = this.emailCR[0].crrequestedDt
        this.crdesc = this.emailCR[0].changeDesc
        this.plantid = this.emailCR[0].plantId

        setTimeout(() => {
          this.getcrinfo(this.crrempid, 'cro');

          //CR Owner name ad email
          this.getcrinfo(this.croempid, 'crr');

        }, 1000);
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  activeTab: number = 1; // Default to the first tab being active

  // Function to activate a tab
  activateTab(tabNumber: number) {
    this.activeTab = tabNumber;
  }
  approverValues: string[] = [];
  remarkValues: string[] = [];
  value: any;
  attachfile: any = '';

  getdata(statu: any) {
    this.attachfile = this.selectedFile.name;
    if (this.attachfile == undefined) {
      this.attachfile = '';
    }
    console.log('ApproverIDONLYYY', this.supportid)
  
    if (this.APILevel == 1) {
      if (this.approverCount <= 1) {
        this.status = "Approved"
      }
      else {
        this.status = "Approved Level1"
      }
    }
    else if (this.APILevel == 2) {
      if (this.approverCount <= 2) {
        this.status = "Approved"
      }
      else {
        this.status = "Approved Level2"
      }
    }
    else {
      this.status = "Approved"
    }

    const apiUrl = this.apiurl + '/CRapprove/Approve';
    const requestBody = {

      "Flag": "I",
      "CRApproverID": 1,
      "approverLevel": this.APILevel,
      "PlantID": this.crid.plantcode,
      "SupportID": 1,
      "CRID": this.crid.itcrid,
      "Stage": "C",
      "ApproverID": Number(this.supportid),
      "ApprovedDt": this.today,
      "Remarks": this.remark,
      "Comments":"this.comment",
      "Status": this.status,
      "Attachment": this.attachfile,
      "CreatedBy": Number(this.supportid),
      "createdDt": this.today,
      "ModifiedBy": Number(this.supportid),
      "modifiedDt": this.today
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        this.addFile();
        console.log(response);
        alert("Change ID" + " " + this.crid.itcrid + " " + ": RFC Is Successfully" + " " + this.status);
        this.emailapproversinfo(this.status);
        console.log(response);
       // alert("Approve Successfully!");
        this.router.navigate(['/change-request']);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });


  }

  rejectbutton(status: any) {
    if (this.remark == '') {
      alert('Enter closure remarks')
    }
    else {
      const apiUrl = this.apiurl + '/CRapprove/Approve';
      const requestBody = {
        "Flag": "I",
        "CRApproverID": 1,
        "PlantID": this.crid.plantcode,
        "SupportID": 1,

        "CRID": this.crid.itcrid,
        "ApproverLevel": this.APILevel,
        "Stage": "C",
        "ApproverID": this.supportid,
        "ApprovedDt": this.today,
        "Remarks": this.remark,
        "Comments": "this.comment",
        "Status": status,
        "Attachment": this.attach,
        "CreatedBy": Number(this.supportid),
        "CreatedDt": this.today,
        "ModifiedBy": Number(this.supportid),
        "ModifiedDt": this.today,
        "sendemailfrom": this.sendemailfrom
      }
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };

      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
          alert("Change ID" + " " + this.crid.itcrid + " " + ": RFC was Rejected!");
          setTimeout(() => {
            this.emailapproversinfo(status);
          }, 1000)
          this.router.navigate(['/change-request']);
        },

        (error: any) => {
          alert("POST request failed");
          console.error('POST request failed', error);
        });
    }
  }

  crremail: any = '';
  croemail: any = '';
  crrequestedBy: any = '';

  approver1N: any = ''
  approver2N: any = ''
  approver3N: any = ''
  approver1: any = ''
  approver2: any = ''
  approver3: any = ''
  plantid: any = ''
  appv: any[] = []
  apprv1email: any = ''
  apprv2email: any = ''
  apprv3email: any = ''

  emailapproversinfo(status: any) {
    debugger
    const apiUrl = this.apiurl + '/GetApproverforEmail/GetApproverEmail';
    const requestBody = {
      "stage": "C",
      "plantid": Number(this.crid.plantcode),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('email conut', response)
        //  alert('respn' + response.length)
        this.appv = response
      });
    setTimeout(() => {
      this.sendemailfrom(status, this.appv);

    }, 1000);
  }
  appr: any[] = []
  appemail: any = ''

  approver11: any = ''
  approver21: any = ''
  approver31: any = ''
  approver12: any = ''
  approver22: any = ''
  approver32: any = ''
  approver13: any = ''
  approver23: any = ''
  approver33: any = ''

  approver11Name: any = ''
  approver21Name: any = ''
  approver31Name: any = ''
  approver12Name: any = ''
  approver22Name: any = ''
  approver32Name: any = ''
  approver13Name: any = ''
  approver23Name: any = ''
  approver33Name: any = ''
  approver1Names: any = ''
  approver2Names: any = ''
  approver3Names: any = ''
  apprv11email: any = ''
  apprv21email: any = ''
  apprv31email: any = ''
  apprv12email: any = ''
  apprv22email: any = ''
  apprv32email: any = ''
  apprv13email: any = ''
  apprv23email: any = ''
  apprv33email: any = ''
  approver1Emails: any = ''
  approver2Emails: any = ''
  approver3Emails: any = ''
  approverlevelstatus1: any = ''
  approverlevelstatus2: any = ''
  approverlevelstatus3: any = ''
  to: any = '';
  to1: any = '';
  to2: any = '';
  to3: any = '';
  cc1: any = '';
  cc2: any = '';
  cc3: any = '';
  cc4: any = '';
  cc5: any = '';
  addrto: any = '';
  subjecttxt: any = '';
  populatedOutput: any = '';
  crrequestedby: any[] = [];
  setcreniatorname: any;
  crowner: any = '';
  submitby: any = '';
  appname: any = '';

  crrequestors() {
        const apiUrl = this.apiurl + '/SupportTeam';
    const requestBody = {
    }

    this.http.get(apiUrl, requestBody).subscribe(
      (response: any) => {
        this.crrequestedby = response.filter((item: any) => item.empId === parseInt(this.supportid));
        this.setcreniatorname = this.crrequestedby[0].empId + "-" + this.crrequestedby[0].firstName + " " + this.crrequestedby[0].lastName
        this.crremail = this.crrequestedby[0].email;
        this.crrequestedBy = this.crrequestedby[0].firstName + " " + this.crrequestedby[0].middleName + " " + this.crrequestedby[0].lastName
        this.crowner = response.filter((item: any) => item.empId === this.updatevalue[0].crowner);
        this.submitby = this.crowner[0].firstName + " " + this.crowner[0].middleName + " " + this.crowner[0].lastName
       // alert('this.submitby' + this.submitby)
      },

      (error: any) => {
        console.error('POST request failed', error);
      });
  }
  sendemailfrom(emailreq: string, appv: any[]) {
    const apiUrl = this.apiurl + '/Email'

    this.approver11 = appv[0].approver1;
    this.approver11Name = appv[0].approver1Name;
    this.apprv11email = appv[0].approver1Email;
    if (appv[0].empid1 != '' && appv[0].empid1 != undefined) {
      this.approver1Names = this.approver11Name + '(' + appv[0].empid1 + ')'
      this.approver1Emails = ', ' + this.apprv11email
    }
    else { this.approver11Name = '' }

    this.approver21 = appv[0].approver2
    this.approver21Name = appv[0].approver2Name;
    this.apprv21email = appv[0].approver2Email;
    console.log('appv[0]', this.appv);
    if (appv[0].empid2 != '' && appv[0].empid2 != undefined) {
      this.approver1Names += ", <br> "
      this.approver1Names += this.approver21Name + '(' + appv[0].empid2 + ')'
      this.approver1Emails += ", " + this.apprv21email
    }
    else { this.approver21Name = '' }

    this.approver31 = appv[0].approver3;
    this.approver31Name = appv[0].approver3Name;
    this.apprv31email = appv[0].approver3Email;
    if (appv[0].empid3 != '' && appv[0].empid3 != undefined) {
      this.approver1Names += ', <br>' + this.approver31Name + '(' + appv[0].empid3 + ')'
      this.approver1Emails += ', ' + this.apprv31email
    }
    else { this.approver31Name = '' }
    //second Level
    this.approver12 = appv[1].approver1;
    this.approver12Name = appv[1].approver1Name;
    this.apprv12email = appv[1].approver1Email;
    if (appv[1].empid1 != '' && appv[1].empid1 != undefined) {
      this.approver2Names = this.approver12Name + '(' + appv[1].empid1 + ')'
      this.approver2Emails += ', ' + this.apprv12email
    }
    this.approver22 = appv[1].approver2;
    this.approver22Name = appv[1].approver2Name;
    this.apprv22email = appv[1].approver2Email;
    if (appv[1].empid2 != '' && appv[1].empid2 != undefined) {
      this.approver2Names += ', <br>' + this.approver22Name + '(' + appv[1].empid2 + ')'
      this.approver2Emails += ', ' + this.apprv22email
    }
    this.approver32 = appv[1].approver3;
    this.approver32Name = appv[1].approver3Name;
    this.apprv32email = appv[1].approver3Email;
    if (appv[1].empid3 != '' && appv[1].empid3 != undefined) {
      this.approver2Names += ', <br>' + this.approver32Name + '(' + appv[1].empid3 + ')'
      this.approver2Emails += ', ' + this.apprv32email
    }
    else { this.approver32Name = '' }

    //Thrid Level
    this.approver13 = appv[2].approver1;
    this.approver13Name = appv[2].approver1Name;
    this.apprv13email = appv[2].approver1Email;
    if (appv[2].empid1 != '' && appv[2].empid1 != undefined) {
      this.approver3Names = this.approver13Name + '(' + appv[2].empid1 + ')'
      this.approver3Emails += ', ' + this.apprv13email
    } else { this.approver13Name = '' }

    this.approver23 = appv[2].approver2;
    this.approver23Name = appv[2].approver2Name;
    this.apprv23email = appv[2].approver2Email;
    if (appv[2].empid2 != '' && appv[2].empid2 != undefined) {
      this.approver3Names += ', <br>' + this.approver23Name + '(' + appv[2].empid2 + ')'
      this.approver3Emails += ', ' + this.apprv23email
    } else { this.approver23Name = '' }
    this.approver33 = appv[2].approver3;
    this.approver33Name = appv[2].approver3Name;
    this.apprv33email = appv[2].approver3Email;
    if (appv[2].empid3 != '' && appv[2].empid3 != undefined) {
      this.approver3Names += ', <br>' + this.approver33Name + '(' + appv[2].empid3 + ')'
      this.approver3Emails += ', ' + this.apprv33email
    } else { this.approver33Name = '' }
    setTimeout(() => {
      //this.approver1N = appv[0].approver1Name;
      //this.approver2N = appv[0].approver2Name;
      //this.approver3N = appv[0].approver3Name;

      //alert('crremail' + this.crremail + 'cro email' + this.croemail)
      //alert('crremail' + this.approver1Emails + 'approver2Emails email' + this.approver2Emails)
      debugger
      if (emailreq == "Approved Level1") {
        this.to1 = this.approver1Emails
        //this.to2 = this.apprv21email
        //this.to3 = this.apprv31email
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        this.cc3 = this.approver2Emails
        // this.cc4 = this.croemail
        // this.cc5 = this.crremail
        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus2 = 'Pending'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus3 = 'Queued'
        }
        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Closure Approved Level 1`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);

        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver1Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{Requestorname}}', this.crrname)
          .replace('{{Submittedname}}', this.croname)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Completed Closure Approval Level 1')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Closure Approval')
          .replace('{{status}}', 'Closure Approved Level 1')
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);
      }
      else if (emailreq == "Approved Level2") {
        this.to1 = this.approver2Emails
        this.cc1 = this.crremail
        this.cc2 = this.croemail
        this.cc3 = this.approver3Emails
        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus2 = 'Approved'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus3 = 'Pending'
        }

        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Closure Approved Level 2`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver2Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{Requestorname}}', this.crrname)
          .replace('{{Submittedname}}', this.croname)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Completed Closure Approval Level 2')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Closure Approval')
          .replace('{{status}}', 'Closure Approved Level 2')
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);

      }
      else if (emailreq == "Approved") {
        this.to1 = this.apprv13email
        this.to2 = this.apprv23email
        this.to3 = this.apprv33email
        this.cc1 = this.croemail
        this.cc2 = this.crremail
        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus1 = 'Approved'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus2 = 'Approved'
        }
        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
        else {
          this.approverlevelstatus3 = 'Approved'
        }
        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Closure Approved`
        const output = this.readHtmlFile('assets/approvalemail.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.approver3Names)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{Requestorname}}', this.crrname)
          .replace('{{Submittedname}}', this.croname)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Completed Closure Approved')
          .replace('{{phase}}', 'Closure Approval')
          .replace('{{status}}', 'Closure Approved')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);
      }
      else if (emailreq == "Reject") {
        this.cc1 = this.croemail
        this.cc2 = this.crremail
        //alert("satus")
        if (this.status == 'Approved') {
          this.appname = this.approver3Names
          this.to1 = this.approver3Emails
          this.approverlevelstatus1 = 'Approved'
          this.approverlevelstatus2 = 'Approved'
          this.approverlevelstatus3 = 'Rejected'

        } else if (this.status == 'Approved Level2') {
          this.appname = this.approver2Names
          this.to1 = this.approver2Emails
          this.cc3 = this.approver3Emails
          this.approverlevelstatus1 = 'Approved'
          this.approverlevelstatus2 = 'Rejected'
          this.approverlevelstatus3 = 'Not Required'
        } else if (this.status == 'Approved Level1') {
          this.appname = this.approver1Names
          this.to1 = this.approver1Emails
          this.cc3 = this.approver2Emails

          this.approverlevelstatus1 = 'Rejected'
          this.approverlevelstatus2 = 'Not Required'
          this.approverlevelstatus3 = 'Not Required'

        } else {
          this.appname = this.approver1Names
          this.to1 = this.approver1Emails
          this.cc3 = this.approver2Emails

          this.approverlevelstatus1 = 'Rejected'
          this.approverlevelstatus2 = 'Not Required'
          this.approverlevelstatus3 = 'Not Required'
        }

        if (this.approver1Names == '') {
          this.approver1Names = 'No Approvers'
          this.approverlevelstatus1 = 'Not Applicable'
        }

        if (this.approver2Names == '') {
          this.approver2Names = 'No Approvers'
          this.approverlevelstatus2 = 'Not Applicable'
        }

        if (this.approver3Names == '') {
          this.approver3Names = 'No Approvers'
          this.approverlevelstatus3 = 'Not Applicable'
        }
       // alert(this.appname)

        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : Closure Approve Rejected`
        const output = this.readHtmlFile('assets/rejection.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.appname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrequestedBy)
          .replace('{{Requestorname}}', this.crrequestedBy)
          .replace('{{Submittedname}}', this.submitby)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'Closure Approve Rejected')
          .replace('{{phase}}', 'Closure Approve Approval')
          .replace('{{status}}', 'Closure Approve Rejected')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{setstatus}}', 'Rejected')
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('@Approval1Status', this.approverlevelstatus1)
          .replace('@Approval2Status', this.approverlevelstatus2)
          .replace('@Approval3Status', this.approverlevelstatus3)
          .replace('{{approvedby}}', this.supportpersonname);

      }
      else if ((emailreq == "Completed")) {
        this.to1 = this.crremail
        this.to2 = this.croemail
        this.cc1 = this.croemail
        this.crdesc +='<br><br> <b>Closure Remarks</b>:'+this.remark
        const requestdate = this.crdate
        const changeDesc = this.crdesc
        this.subjecttxt = `Unnati:IT Change Request:${this.itcrid} : RFC Completed`
        const output = this.readHtmlFile('assets/email.html');
        console.log(output);
        this.populatedOutput = output
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.croname)
          .replace('{{Requestorname}}', this.crrname)
          .replace('{{Submittedname}}', this.croname)
          .replace('{{this.Cremailvalue[0].crrequestedBy}}', this.crrname)
          .replace('{{this.Cremailvalue[0].crdate}}', this.crdate)
          .replace('{{this.Cremailvalue[0].changeDesc}}', this.crdesc)
          .replace('{{Approvestatus}}', 'RFC Completed')
          .replace('{{crid}}', this.crid.itcrid)
          .replace('{{crapprover1}}', this.approver1Names)
          .replace('{{crapprover2}}', this.approver2Names)
          .replace('{{crapprover3}}', this.approver3Names)
          .replace('{{phase}}', 'Closure ')
          .replace('{{status}}', 'Completed')
          .replace('@Approval1Status', 'Approved')
          .replace('@Approval2Status', 'Approved')
          .replace('@Approval3Status', 'Approved')
          .replace('{{BodyContent}}', 'Please find the details of the Change Request Submitted by ' + this.supportpersonname + ' and waiting for your Approval.')
          .replace('{{approvedby}}', this.supportpersonname);
      }

      if (this.to2 != '' && this.to3 != '') {
        var To = ',' + this.to2 + ',' + this.to3;
      } else if (this.to2 != '' && this.to3 == '') {
        var To = ',' + this.to2;
      }
      else {
        var To = '';
      }

      if (this.cc2 != '' && this.cc3 != '') {
        var cc = ',' + this.cc2 + ',' + this.cc3;
      } else if (this.cc2 != '' && this.cc3 == '') {
        var cc = ',' + this.cc2;
      }
      else {
        var cc = '';
      }
      var cc1pluscc = this.cc1 + cc;

      var cc1pluscc1 = cc1pluscc.replace(',,', ',');
      const requestBody = {
        "to": this.to1 + To,
        "cc": cc1pluscc1,
        "subject": this.subjecttxt,
        "body": this.populatedOutput

      }

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
        },
        (error: any) => {
          console.log('Post request failed', error);
        });
    }, 500)

  }

  readHtmlFile(file: string): string {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', file, false);
    xhr.send();
    if (xhr.status === 200) {
      return xhr.responseText;
    } else {
      console.error('Failed to read HTML file:', file);
      return ''; // or handle error accordingly
    }
  }

  //supportteams: any[] = [];
  getsupportid: any;

  getsupportteams() {

    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log("Supportid", response);

        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid));
        this.getsupportid = this.supportteams[0].supportTeamId
        console.log("getting supportteam id", this.getsupportid)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
    this.getsupportteamassign()
  }

  supportteamassign: any[] = [];
  isapprovers: any = 0;
  issupportegineer: any = 0;
  ischangeanalyst: any = 0;

  getsupportteamassign() {

    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.isapprovers = this.supportteamassign[0].isApprover
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        console.log("geting support asigned id", this.issupportegineer)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  updatevalue: any;
  isapproved: any;
  changerequest: any = '';
  getupdatyevalue() {

    const apiUrls: any = this.apiurl + '/ChangeRequest/Getrequest';
    const requestBody = {
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.changerequest = response.filter((item: any) => item.itcrid.toString() === this.crid.itcrid);
        this.isapproved = this.updatevalue[0].isApproved
        /*if (this.itcrtd = this.updatevalue)*/
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  GetApprover(index: number) {
    const apiUrl = this.apiurl + '/GetApproval/GetApprover';
    const requestBody = {
      "level": Number(index),
      "stage": "C",
      "plantid": Number(this.plantidforapp),
      "categoryId": Number(this.categoryId),
      "classificationId": Number(this.classificationId)
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log('apvconut', response)

        this.approverCount = response[0].approverCount;
        console.log("Approver count", this.approverCount)
        this.approvervalue = response;
        this.supportapp = "Select Approver"

        if (this.approvervalue[0].approver1 != '') {

          this.supportapp1ID = this.approvervalue[0].approver1;
          this.supportapp1 = this.approvervalue[0].approver1Name;
          if (Number(this.getsupportid) === Number(this.supportapp1ID)) {
            this.selectedOption = "support1";
          }
          if (Number(this.supportapp1ID) == Number(this.getsupportid))
            this.appvflg = true;

        }
        if (this.approvervalue[0].approver2 != '') {
          this.supportapp2ID = this.approvervalue[0].approver2;
          this.supportapp2 = this.approvervalue[0].approver2Name;
          if (Number(this.supportapp2ID) == Number(this.getsupportid))
            this.appvflg = true;
        }
        if (this.approvervalue[0].approver3 != '') {
          this.supportapp3ID = this.approvervalue[0].approver3;
          this.supportapp3 = this.approvervalue[0].approver3Name;
          if (Number(this.supportapp3ID) == Number(this.getsupportid))
            this.appvflg = true;
        }
        console.log("Approver data", this.supportapp, this.approverCount, this.appvflg)
        //alert('appr flag in GetApprover()' + this.appvflg + 'tab' + index);
      },
      (error: any) => {
        console.error('POST request failed', error);
      });
  }

  ReleasedStatus() {
     if (this.stage == "Release") {
      if (this.appstatus == "Released") {
        this.Approver1();

        if (this.approverCount == 2) {
          this.Approver2();
        }

        if (this.approverCount == 3) {
          this.Approver2();
          this.Approver3();
        }
       }
    }
  }

  StageStatus() {
      if (this.appstatus == "Completed") {
      this.Approver1();
      if (this.approverCount == 2) {
        this.Approver2();
      }

      if (this.approverCount == 3) {
        this.Approver2();
        this.Approver3();
      }
      this.isCompleted = true;
    }
    if (this.stage == "Closure") {
      if (this.appstatus == "Approved") {
        this.Approver1();

        if (this.approverCount == 2) {
          this.Approver2();
        }

        if (this.approverCount == 3) {
          this.Approver2();
          this.Approver3();
        }
        this.isCompleted = true;
      }
      if (this.appstatus == "Approved level1") {
        this.Approver1();
        this.Approver2();

        if (this.approverCount == 3) {
          this.Approver3();

        }
      }
      if (this.appstatus == "Approved level2") {
        this.Approver1();
        this.Approver2();
        this.Approver3();
      }
      if (this.status == "Approved level3") {
        this.Approver1();
        this.Approver2();
        this.Approver3();

      }

    }
    //alert('isCompleted : ' + this.isCompleted + 'app status' + this.appstatus)
  }
  Approver(applevel: Number) {
    if (applevel == 3) { this.Approver3(); }
    else if (applevel == 2) { this.Approver2(); }
    else { this.Approver1(); }
  }
  //get approved details for all levels
  getapprvdtls: any[] = [];
  approvedDt: any = '';
  getlevel: any = '';
  getapprdtls(level: Number) {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrApproverHistory?id=' + this.itcrid

    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {

        this.getapprvdtls = response.filter((item: any) => item.stage.trim() === "C" );
        this.getlevel = Number(level) - 1
        this.approvedDt = this.getapprvdtls[this.getlevel].approvedDt;
        this.remark = this.getapprvdtls[this.getlevel].remarks
        this.comment = this.getapprvdtls[this.getlevel].comments
        this.date = this.getapprvdtls[this.getlevel].approvedDt
        this.attach = this.getapprvdtls[this.getlevel].attachment
        console.log('get apprv dtls', response)

      },
      (error) => {
        console.error("Data fetching error", error)
      }

    )

  }

  Approver1() {
    this.APILevel = 1;
    this.GetApprover(1);
    this.getapproverslevel();
    this.getapprdtls(1);

    if (this.appstatus == "Released") {
      if (this.appvflg) this.appflag = true;
      this.remark = ''
      this.attach = ''
      this.date = this.currentday;
    } else {
      this.appflag = false;
      this.appvflg=false;
    }

  }

  Approver2() {
    this.APILevel = 2;
    this.GetApprover(2);
    this.getapproverslevel();
    this.getapprdtls(2);


    if (this.appstatus == "Approved level1") {
      if (this.appvflg) this.appflag = true;
      this.remark = ''
      this.attach = ''
      this.date = this.currentday;
    } else {
      this.appflag = false;
      this.appvflg=false;
    }
    //alert('this.appflag APPROVER 2' + this.appvflg + '--' + this.appflag + '--' + this.supportapp1ID + '--' + this.supportapp2ID + '--' + this.supportapp3ID + '--' + this.getsupportid)
  }

  Approver3() {
    this.APILevel = 3;
    this.GetApprover(3);
    this.getapproverslevel();
    this.getapprdtls(3);
    if (this.appstatus == "Approved level2") {
      if (this.appvflg) this.appflag = true;
      this.remark = ''
      this.attach = ''
      this.date = this.currentday;
    } else {
      this.appflag = false;
      this.appvflg=false;
    }
  }

  approverget: any;
  approverlevels: any = '';
  responseData: any[] = [];
  apvnames: any[] = [];

  ApproverNames(): { id: string, name: string }[] {
    const approverNames: { id: string, name: string }[] = [];
    for (const key in this.responseData[0]) {
      if (key.endsWith('Name')) {
        const idKey = key.replace('Name', '');
        const id = this.responseData[0][idKey];
        const name = this.responseData[0][key];
        if (id && name && name.trim() !== '') {
          approverNames.push({ id, name });
        }
      }
    }
    return approverNames;
  }

  getapproverslevel() {
    const apiUrls: any = this.apiurl + '/GetApproval/GetApprover';
    //alert('I m in getapproverslevel() fn' + this.APILevel);
    const requestBody = {
      "level": Number(this.APILevel),
      "stage": "C",
      "plantid": Number(this.plantidforapp),
      "categoryId": this.categoryId,
      "classificationId": this.classificationId
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.post(apiUrls, requestBody, httpOptions).subscribe(
      (response: any) => {
        //console.log('apilevels', response)
        console.log('getapproverslevel response', this.apvnames)
        if (this.APILevel == 1) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 1";
          this.ApproverNames();
        }
        if (this.APILevel == 2) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 2";
          this.ApproverNames();
        }
        if (this.APILevel == 3) {
          this.responseData = response;
          this.rfcapproverlevel = "Approval Level 3";
          this.ApproverNames();
        }
        this.approverget = response.filter((item: any) => item.approverstage.trim() === "C");
        this.approverlevels = this.updatevalue[0].isApproved
        console.log("geting approversstaesinpage", response)
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  itcrid: any = '';
  approver: any = '';
  attach: any='';
  closureRemarks: any = "";
  feedbackout: any = "";
  closedby: any = "";
  createdby: any = "";
  closeddate: any = "";
  closedstatus: any = "";

  submitCloser() {
    
    const apiUrl = this.apiurl + '/Crcloser/Closer';
    const requestBody = {
      "itcrid": this.crid.itcrid,
      "closureRemarks": this.closureRemarks,
      "closedBy": Number(this.supportid),
      "closedDt": "2024-06-12T13:22:17.307Z",
      "feedback": this.feedbackout,
      "createdBy": Number(this.supportid),
      "closedStatus":this.closedstatus,
      "sendemailfrom":this.sendemailfrom,
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
        alert("Change ID" + " " + this.crid.itcrid + " " + ": RFC Is Completed");
        this.emailapproversinfo('Completed');
        this.router.navigate(['/change-request']);
      },
      (error: any) => {
        console.log('Post request failed', error);
      });
  }
  //get data from cr for closure
  closerdtls:any[]=[]

  getCloserdtls() {
    const apiUrls = this.apiurl + '/ChangeRequest/Getrequest' 
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.closerdtls = response;
       this.closerdtls=response.filter((item: any) => item.itcrid== this.crid.itcrid);
        console.log('closer response', this.closerdtls);
         this.closureRemarks= this.closerdtls[0].closureRemarks
          this.currentdate= this.closerdtls[0].closedDt
         this.feedbackout= this.closerdtls[0].feedback
         this.closedstatus= this.closerdtls[0].closedStatus
      },
      (error) => {
        console.error("Data fetching error", error)
      });
  }

  followupdtls:any[]=[]
  followupviewdt: string = '';
  getfollowupdtls() {
    const apiUrls = this.apiurl + '/CRfollowUp/GetFollow' 
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
       // this.followupdtls = response;
         console.log('followp response', response);
       this.followupdtls=response.filter((item: any) => item.itcrid === this.crid.itcrid);
        console.log('followp response', this.followupdtls);
        //FollowUpDtStart
         this.followupviewdt = this.followupdtls[0].followupDt
         const apimnfdate = this.datepipe.transform(this.followupviewdt, 'dd-MMM-yyyy') || '';
        const [day, month, year] = apimnfdate.split('-');
        const dateObject = new Date(`${year}-${month}-${day}`);
        const formatDate = dateObject.toISOString().split('T')[0];
        this.followupDt = formatDate;
        //FollowUpDtEnd
          this.followupComments= this.followupdtls[0].followupComments
          console.log('followupComments',this.followupComments)
       // alert('this.followupComments'+this.followupComments)
      },
      (error) => {
        console.error("Data fetching error", error)
      });
  }

  lessondata:any[]=[];
  lessonsdtOnly: string = '';
  getlessonsdtls() {
    const apiUrls = this.apiurl + '/CRlession/GetCrLession' 
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
       // this.followupdtls = response;
        console.log('lsncriditcrid', this.crid.itcrid);
       this.lessondata=response.filter((item: any) => item.itcrid === this.crid.itcrid);
        this.lessondata.forEach((row) => {
          this.lessonsArray.push({ text: `${row.lessons}` });
        });
        this.lessonsdtOnly = this.lessondata[0].lessonDt
        const apilsnmnfdate = this.datepipe.transform(this.lessonsdtOnly, 'dd-MMM-yyyy') || '';
        const [day, month, year] = apilsnmnfdate.split('-');
        const datelsnObject = new Date(`${year}-${month}-${day}`);
        const formattedLsnDate = datelsnObject.toISOString().split('T')[0];
        this.lessonDt = formattedLsnDate;

         // this.lesson= this.lessondata[0].lessons
       // alert('this.followupComments'+this.followupComments)
      },
      (error) => {
        console.error("Data fetching error", error)
      });
  }

  lessons: any = "";
  lessonsArray: any[] = [];
  attachment: any = "";
  lessonDt: any = "";
  errorMessage: any = '';


  crlesson() {
    this.lessonsArray.forEach((lesson, index) => {
      const apiUrl = this.apiurl + '/CRlession/Approve';
      const requestBody = {
        "flag": "I",
        "crLessonID": 0,
        "itcrid": this.crid.itcrid,
        "lessons": lesson.text,
        "lessonDt": this.lessonDt, // Assuming you want the same lessonDt for each lesson
        "attachment": this.attachment, // Assuming you want the same attachment for each lesson
        "createdBy": Number(this.supportid),
        "createdDt": this.today,
        "modifiedBy": Number(this.supportid),
        "modifiedDt": this.today
      };

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };

      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log(response);
          alert("Lessons Saved successfully!")
          this.router.navigate(['/change-request']);
        },
        (error: any) => {
          console.log('Post request failed', error);
        }
      );
    });
  }

 
  

  addLesson() {
    this.lessonsArray.push({ text: '' });
  }

  removeLastLesson() {
    if (this.lessonsArray.length > 1) {
      this.lessonsArray.pop();
    }
  }

 
  // Function to activate a tab
    followupDt:any;
    followupToPerson:any;
    followupComments:any;
    emailofreciver: any;

     Closerfollowup(){
       if (!this.followupDt || this.followupDt == '') {
         alert('Please enter Follow-up date!');
       }
       else if (!this.followupComments || this.followupComments == '') {
         alert('Please enter Follow-up comments!');
       }
       else {
         const apiUrl = this.apiurl + '/CRfollowUp/Followup';
         const requestBody = {
           "Flag": "I",
           "crFollowupID": 1,
           "itcrid": this.crid.itcrid,
           "followupDt": this.followupDt,
           "followupToPerson": this.supportid,
           "followupComments": this.followupComments,
           "CreatedBy": this.supportid

         }
         const httpOptions = {
           headers: new HttpHeaders({
             'Content-Type': 'application/json'
           })
         };

         this.http.post(apiUrl, requestBody, httpOptions).subscribe(
           (response: any) => {
             console.log(response);
             alert("FollowUp Saved Successful!")
             this.router.navigate(['/change-request']);
           },
           (error: any) => {
             console.error('POST request failed', error);
           });
       }
    }

   
  tableData: any[] = [];
  getData() {
    const apiUrls = this.apiurl + '/ViewChangeHistory/GetCrApproverHistory?id='+this.itcrid
    /*const requestBody = {

    }*/
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        this.tableData = response;
        console.log('responsetable', response)
      },
      (error) => {
        console.error("Data fetching error", error)
      }
    )
  }
 }
