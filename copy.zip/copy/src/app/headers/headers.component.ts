import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component, HostListener,ElementRef } from '@angular/core';
import { PasscrdataService } from '../change-request/passcrdata.service';
import { Router } from '@angular/router';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

@Component({
  selector: 'app-headers',
  templateUrl: './headers.component.html',
  styleUrl: './headers.component.css'
})
export class HeadersComponent {
  supportid: any;
constructor(private http: HttpClient, private routeservice: PasscrdataService, private route: Router, private elementRef: ElementRef) {
  
}
@HostListener('document:click', ['$event'])
  onClick(event: Event) {
    if (!this.elementRef.nativeElement.contains(event.target)) {
     
    }
  }

 showDropdown: boolean = false;

toggleDropdown() {
    this.showDropdown = !this.showDropdown;
  }



ngOnInit(): void {
  //this.getsupportteams();
  this.getsupporttid();
  setTimeout(() => {
    this.getsupportteams();
  }, 100);
}

getsupporttid(){
  this.routeservice.getsupportteam();
  this.supportid = this.routeservice.supporterID;
}


supportteams: any[] = [];
getsupportid: any;
supportpersonname = '';
firstname: any;
middlename: any;
lastname: any;
designation: any;
employeeid:any;


  private apiurl = environment.apiurls
  private loginurls = environment.loginurl
  idofemployee: any;
  urls: string = '';

  logout() {
    this.idofemployee = '';
    this.routeservice.setEmployeeId(this.idofemployee);
    localStorage.removeItem('token');
    localStorage.setItem('isLoggedin', 'false');
    this.urls = this.loginurls + '#' + '/login'
  }

getsupportteams() {
  const apiUrls = this.apiurl + '/SupportTeam'
  const requestBody = {

  }
  const httpOptions = {
    headers: new HttpHeaders({
      'content-Type': 'application/json'
    })
  };
  this.http.get(apiUrls, requestBody).subscribe(
    (response: any) => {
      console.log("SupportId:",this.supportid)
      this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
      this.getsupportid = this.supportteams[0].supportTeamId;
      this.designation = this.supportteams[0].role;
      this.employeeid = this.supportteams[0].empId;
      this.firstname = this.supportteams[0].firstName;
      this.middlename = this.supportteams[0].middleName;
      this.lastname = this.supportteams[0].lastName;
      /*this.supportpersonname = this.firstname + this.middlename + this.lastname;*/
      if (this.firstname !== null && this.firstname !== undefined) {
        this.supportpersonname += this.firstname;
        
      }

      if (this.middlename !== null && this.middlename !== undefined) {
        // If the supportpersonname is not empty, add a space before concatenating middle name
        if (this.supportpersonname !== '') {
          this.supportpersonname += ' ';
        }
        this.supportpersonname += this.middlename;
      }

      if (this.lastname !== null && this.lastname !== undefined) {
        // If the supportpersonname is not empty, add a space before concatenating last name
        if (this.supportpersonname !== '') {
          this.supportpersonname += ' ';
        }
        this.supportpersonname += this.lastname;
      }

      // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
      if (this.supportpersonname === '') {
        this.supportpersonname = 'Unknown';
      }


      // If all parts of the name are null, set supportpersonname to 'Unknown'
      if (this.supportpersonname === '') {
        this.supportpersonname = 'Unknown';
      }
    },
    (error) => {
      console.error("Post failed", error)
    }
  ) 
}
}
