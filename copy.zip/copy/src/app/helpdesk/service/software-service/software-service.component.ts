import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment';

interface DropdownDepartmentItem {
  itemdepartment_id: number;
  itemdepartment_text: string;
}

interface DropdownCatItem {
  itemcat_id: number;
  itemcat_text: string;
}

@Component({
  selector: 'app-software-service',
  templateUrl: './software-service.component.html',
  styleUrl: './software-service.component.css'
})
export class SoftwareServiceComponent {

  constructor(private http: HttpClient) {
    this.fetchDropdownDepartment();
  }

  showProcureBuy: boolean = false;
  showDevelopmentApplicationmobileapp: boolean = false;
  showWebsiteDevelopment: boolean = false;
  Installationtype: string = '';
  RequestFor: string = '';
  today!: Date;
  selectAMC: string = '';
  showAMC: boolean = false; 
  showImplementationRequired: boolean = false;
  selectImplementationRequired: string = '';
  selectInterface: string = '';
  selectdevelopmentInterface: string = '';
  showInterfaceRequirements: boolean = false;
  showInstallSoftware: boolean = false;
  showupgradeSoftware: boolean = false;
  showUnInstallSoftware: boolean = false;
  SelectPlant: string = '';
  dropdownListDepartment: DropdownDepartmentItem[] = [];
  impactedPlant: any = '';
  private apiurl = environment.apiurls;

  dropdownDepartmentSettings = {
    idField: 'itemdepartment_id',
    textField: 'itemdepartment_text',
  };

  dropdownListCat: DropdownCatItem[] = [];
  dropdownCatSettings = {
    idField: 'itemcat_id',
    textField: 'itemcat_text',
  };

  selecteddepartmentNames: DropdownDepartmentItem[] = [];

  onSelecteddepartmentItemsChange(): void {
    console.log("this is the plant ids will come", this.impactedPlant)
    this.impactedPlant = this.selecteddepartmentNames.map((item: any) => item.itemdepartment_id);
  }

  fetchDropdownDepartment(): void {
    const apiUrl = this.apiurl + '/Plantid';
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownListDepartment = data.map(item => ({
          itemdepartment_id: item.id,
          itemdepartment_text: item.code
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }

  RequestForFunc() {
    if (this.RequestFor === "Procure/Buy") {
      this.showProcureBuy = true;
      this.showDevelopmentApplicationmobileapp = false;
      this.showWebsiteDevelopment = false;
      this.showInstallSoftware = false;
      this.showupgradeSoftware = false;
      this.showUnInstallSoftware = false;
    }
    else if (this.RequestFor === "Development-Application,mobile app") {
      this.showDevelopmentApplicationmobileapp = true;
      this.showProcureBuy = false;
      this.showWebsiteDevelopment = false;
      this.showInstallSoftware = false;
      this.showupgradeSoftware = false;
      this.showUnInstallSoftware = false;
    }
    else if (this.RequestFor === "Website Development") {
      this.showWebsiteDevelopment = true;
      this.showProcureBuy = false;
      this.showDevelopmentApplicationmobileapp = false;
      this.showInstallSoftware = false;
      this.showupgradeSoftware = false;
      this.showUnInstallSoftware = false;
    }
    else if (this.RequestFor === "Install Software") {
      this.showInstallSoftware = true;
      this.showWebsiteDevelopment = false;
      this.showProcureBuy = false;
      this.showDevelopmentApplicationmobileapp = false;
      this.showupgradeSoftware = false;
      this.showUnInstallSoftware = false;
    }
    else if (this.RequestFor === "Upgrade Software") {
      this.showProcureBuy = false;
      this.showDevelopmentApplicationmobileapp = false;
      this.showWebsiteDevelopment = false;
      this.showInstallSoftware = false;
      this.showUnInstallSoftware = false;
      this.showupgradeSoftware = true;

    }
    else if (this.RequestFor === "Uninstall Software") {
      this.showUnInstallSoftware = true;
      this.showProcureBuy = false;
      this.showDevelopmentApplicationmobileapp = false;
      this.showWebsiteDevelopment = false;
      this.showInstallSoftware = false;
      this.showupgradeSoftware = false;
    }


  }

  amcOption() {
    if (this.selectAMC === "Yes") {
      this.showAMC = true;
    } else {
      this.showAMC = false;
    }
  }

  ImplementationRequiredOption() {
    if (this.selectImplementationRequired === "Yes") {
      this.showImplementationRequired = true;
    } else {
      this.showImplementationRequired = false;
    }
  }

  interfaceOption() {
    if (this.selectInterface === "Yes") {
      this.showInterfaceRequirements = true;
    } else {
      this.showInterfaceRequirements = false;
    }
  }



  // DevinterfaceOption(){
  //   if (this.selectdevelopmentInterface === "Yes") {
  //     this.showInterfaceRequirements = true;
  //   } else {
  //     this.showInterfaceRequirements = false;
  //   }
  // }
}
