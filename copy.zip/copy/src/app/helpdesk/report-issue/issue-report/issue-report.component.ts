import { Component } from '@angular/core';

@Component({
  selector: 'app-issue-report',
  templateUrl: './issue-report.component.html',
  styleUrl: './issue-report.component.css'
})
export class IssueReportComponent {
  filter = {
    location: '',
    department: '',
    user: '',
    category: '',
    type: '',
    fromDate: '',
    toDate: ''
  };

  constructor() { }

  applyFilters() {
    // Here you can implement the logic to apply the filters
    console.log('Filters:', this.filter);
    // You can call a service or perform any other action with the filter values
  }

 /* dropdownList: DropdownItem[] = [];
  dropdowncategroy: DropdownItem[] = [];
  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code // Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }*/

  tableData: any[] = [
    {
      'srno':'001',
    'engineer':'Mechnanical Engineer',
    'status':'Opened',
    'location':'ML04',
    'department':'Manufacturing',
    'user':'Michael',
    'category':'Servers',
    'type':'TrendMicro',
    'fromdate':'01-02-2024',
    'todate':'05-02-2024',
    'sla':'sla',
    'delay':'02-03-2024',
    },
    {
      'srno': '002',
      'engineer': 'Backend Developer',
      'status': 'On Hold',
      'location': 'ML04',
      'department': 'Manufacturing',
      'user': 'Muthu',
      'category': 'Servers',
      'type': 'TrendMicro',
      'fromdate': '01-02-2024',
      'todate': '05-02-2024',
      'sla': 'sla',
      'delay': '02-03-2024',
    },
    {
      'srno': '003',
      'engineer': 'Software Engineer',
      'status': 'Resolved',
      'location': 'ML04',
      'department': 'Manufacturing',
      'user': 'Syed',
      'category': 'Servers',
      'type': 'TrendMicro',
      'fromdate': '01-02-2024',
      'todate': '05-02-2024',
      'sla': 'sla',
      'delay': '02-03-2024',
    }
  ]

}
