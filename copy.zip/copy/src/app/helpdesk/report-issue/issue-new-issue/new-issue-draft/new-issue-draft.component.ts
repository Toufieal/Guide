import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment'
import { Router } from '@angular/router';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { PasscrdataService } from '../../../../change-request/passcrdata.service';
import { HelpdeskserviceService } from '../../../helpdeskservice.service';

@Component({
  selector: 'app-new-issue-draft',
  templateUrl: './new-issue-draft.component.html',
  styleUrl: './new-issue-draft.component.css'
})
export class NewIssueDraftComponent {
  @ViewChild('EnterIssueID') EnterIssueID: any;

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: 'auto',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    /*uploadUrl: 'v1/image',*/
    /*upload: (file: File) => { ... }
  uploadWithCredentials: false,
  sanitize: true,
  toolbarPosition: 'top'*/
    toolbarHiddenButtons: [
      ['fontSize',
        'subscript',
        'superscript',
        'indent',
        'outdent',
        'heading',
        'fontName',
        'fontSize',
        'link',
        'unlink',
        'insertVideo',
        'insertHorizontalRule',
        'removeFormat',
        'toggleEditorMode',
        'customClasses',
        'insertUnorderedList',
        'insertOrderedList',
      ]
    ]
  };

  private apiurl = environment.apiurls

  supportid: any;
  today: any;
  selectedOption: string = '';
  EmployeeID: string = '';
  Name: string = '';
  Email: string = '';
  ContactNo: string = '';
  ReportingManager: string = '';
  StaffCategory: string = '';
  Paygroup: string = '';
  Department: string = '';
  Designation: string = '';
  Role: string = '';
  IssueRaisedFor: string = '';
  Plant: string = '';
  supportteams: any[] = [];
  supportteamsforOthers: any[] = [];
  supportteamsforGuest: any[] = [];
  DisableissueRaiseFor: boolean = true;
  service: any = '';
  Type: string = '';
  ShowSelf: boolean = true;
  ShowOthers: boolean = false;
  ShowGuest: boolean = false;
  EmployeeIDOthers: string = '';
  OthersName: string = '';
  EmailOthers: string = '';
  ContactNoOthers: string = '';
  ReportingManagerOthers: string = '';
  StaffCategoryOthers: string = '';
  PlantOthers: string = '';
  PaygroupOthers: string = '';
  DepartmentOthers: string = '';
  DesignationOthers: string = '';
  RoleOthers: string = '';
  GuestEmployeeID: string = '';
  GuestName: string = '';
  Guestemail: string = '';
  GuestContactNo: string = '';
  ReportingManagerinML: string = '';
  StaffCategoryofML: string = '';
  GuestPlant: string = '';
  PaygroupML: string = '';
  DepartmentML: string = '';
  DesignationofMLManager: string = '';
  RoleofMLManager: string = '';
  supportnames: any[] = [];
  plantcode: any[] = [];
  ReportingManagerEmpID: string = '';
  selectRowData:any[]=[];

  constructor(private http: HttpClient, private route: Router, private routeservice: PasscrdataService, private helpdeskservice: HelpdeskserviceService ) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;

    const currentDate = new Date()
    this.today = currentDate.toISOString().slice(0, 10);

      this.helpdeskservice.UpdateNewIssuedata$.subscribe(data => {
    if (data && data.selectRowData) {
  this.selectRowData = data.selectRowData.rowData;
  }
  })
  console.log("hiiiii", this.selectRowData)
  }

  ngOnInit(): void {
    this.getplant();
    this.getcategory();
    this.priorityapi();
    this.fetchAllItems();
    this.OnLabelChange();
  setTimeout(() => {
  this.asignDraftData();
    }, 1000);
  }

  async asignDraftData() {
    this.plantId = this.selectRowData[0].plantname;
    if(this.plantId != ''){
      const foundplant = this.plantcode.find(row=>row.code == this.plantId);
      if(foundplant){
        this.plantId = foundplant.id.toString();
      }
    }

    this.categoryId = this.selectRowData[0].categoryName;
    if(this.categoryId != ''){
      const foundcategoryId = this.categorydata.find(row=>row.categoryName == this.categoryId);
      if(foundcategoryId){
        this.categoryId = foundcategoryId.itcategoryId.toString();
        this.getcategorytype();
      }
    }
    try {
        await this.getcategorytype();
        this.getCatType();
      } catch (error) {
        console.error('Error fetching items:', error);
      }

     this.priority = this.selectRowData[0].priorityName;
    if(this.priority != ''){
      const foundpriority = this.prioritytype.find(row=>row.priorityName == this.priority);
      if(foundpriority){
        this.priority = foundpriority.priorityId.toString();
      }
    }

    this.source= this.selectRowData[0].source;
    this.assetId=this.selectRowData[0].assetId;
    this.assignedTo=this.selectRowData[0].assignedTo;
    this.Subject=this.selectRowData[0].issueShotDesc;
    this.issueDesc=this.selectRowData[0].issueDesc;
    this.attachment=this.selectRowData[0].attachment;


  }

  getCatType() {
    this.categoryTypId = this.selectRowData[0].categoryType;
    if(this.categoryTypId != ''){
      console.log('this.categorytype',this.categorytype)
      console.log('this.categoryTypId',this.categoryTypId)
      const foundcategoryTypId = this.categorytype.find(row=>row.categoryType == this.categoryTypId);
      console.log('foundcategoryTypId',foundcategoryTypId)
      if(foundcategoryTypId){
        this.categoryTypId = foundcategoryTypId.categoryTypeId.toString();
      }
    }
  }

  ClearIssueDetailsInputs() {
    this.plantId = '';
    this.categoryId = '';
    this.categoryTypId = '';
    this.priority = '';
    this.Type = '';
    this.source = '';
    this.assetId = '';
    this.assignedTo = '';
    this.Subject = '';
    this.issueDesc = '';
    this.attachment = '';
  }

  ClearGuestInputs() {
    this.GuestEmployeeID = '';
    this.GuestName = '';
    this.Guestemail = '';
    this.GuestContactNo = '';
    this.ReportingManagerEmpID = '';
    this.ReportingManagerinML = '';
    this.StaffCategoryofML = '';
    this.GuestPlant = '';
    this.PaygroupML = '';
    this.DepartmentML = '';
    this.DesignationofMLManager = '';
    this.RoleofMLManager = '';
  }

  ClearOtherInputs() {
    this.EmployeeIDOthers = '';
    this.OthersName = '';
    this.EmailOthers = '';
    this.ContactNoOthers = '';
    this.ReportingManagerOthers = '';
    this.StaffCategoryOthers = '';
    this.PlantOthers = '';
    this.PaygroupOthers = '';
    this.DepartmentOthers = '';
    this.DesignationOthers = '';
    this.RoleOthers = '';
  }

  ClearGuestOtherInputs() {
    this.ReportingManagerinML = '';
    this.StaffCategoryofML = '';
    this.GuestPlant = '';
    this.PaygroupML = '';
    this.DepartmentML = '';
    this.DesignationofMLManager = '';
    this.RoleofMLManager = '';
  }

  ClearSelfInputs() {
    this.EmployeeID = '';
    this.Name = '  ';
    this.Email = '';
    this.ContactNo = '';
    this.ReportingManager = '';
    this.StaffCategory = '';
    this.Plant = '';
    this.Paygroup = '';
    this.Department = '';
    this.Designation = '';
    this.Role = '';
  }

  getInputDatas() {
    this.EmployeeID = this.supportteams[0].employeeId;
    this.Name = this.supportteams[0].employeeName;
    this.Email = this.supportteams[0].email;
    this.ContactNo = this.supportteams[0].phoneNumber;
    this.ReportingManager = this.supportteams[0].reportManagerName;
    this.StaffCategory = this.supportteams[0].staffCategory;
    this.Plant = this.supportteams[0].plantcode;
    this.Paygroup = this.supportteams[0].payGroup;
    this.Department = this.supportteams[0].department;
    this.Designation = this.supportteams[0].designation;
    this.Role = this.supportteams[0].role;
  }

  getOtherInputDatas() {
    this.EmployeeIDOthers = this.supportteamsforOthers[0].employeeId;
    this.OthersName = this.supportteamsforOthers[0].employeeName;
    this.EmailOthers = this.supportteamsforOthers[0].email;
    this.ContactNoOthers = this.supportteamsforOthers[0].phoneNumber;
    this.ReportingManagerOthers = this.supportteamsforOthers[0].reportManagerName;
    this.StaffCategoryOthers = this.supportteamsforOthers[0].staffCategory;
    this.PlantOthers = this.supportteamsforOthers[0].plantcode;
    this.PaygroupOthers = this.supportteamsforOthers[0].payGroup;
    this.DepartmentOthers = this.supportteamsforOthers[0].department;
    this.DesignationOthers = this.supportteamsforOthers[0].designation;
    this.RoleOthers = this.supportteamsforOthers[0].role;
  }

  getGuestInputDatas() {
    this.ReportingManagerinML = this.supportteamsforGuest[0].reportManagerName;
    this.StaffCategoryofML = this.supportteamsforGuest[0].staffCategory;
    this.GuestPlant = this.supportteamsforGuest[0].plantcode;
    this.PaygroupML = this.supportteamsforGuest[0].payGroup;
    this.DepartmentML = this.supportteamsforGuest[0].department;
    this.DesignationofMLManager = this.supportteamsforGuest[0].designation;
    this.RoleofMLManager = this.supportteamsforGuest[0].role;
  }

  async OnLabelChange() {
    if (this.selectedOption) {
      this.ClearSelfInputs();
      this.ClearOtherInputs();
      this.ClearGuestInputs();
      this.ClearIssueDetailsInputs();
      this.supportteams = [];
      this.supportteamsforOthers = [];
      this.supportteamsforGuest = [];
      this.issueRaiseFor = '';
      this.dropdownItems = [];
      this.dropdownItems2 = [];

      if (this.selectedOption === "self") {
        this.DisableissueRaiseFor = true;
        this.ShowSelf = true;
        this.ShowOthers = false;
        this.ShowGuest = false;
      }
      else if (this.selectedOption === "others") {
        setTimeout(() => {
          this.EnterIssueID.nativeElement.focus();
        }, 0);
        this.DisableissueRaiseFor = false;
        this.ShowSelf = false;
        this.ShowOthers = true;
        this.ShowGuest = false;
      }
      else if (this.selectedOption === "guest") {
        this.DisableissueRaiseFor = true;
        this.ShowSelf = false;
        this.ShowOthers = false;
        this.ShowGuest = true;
      }

      this.supportid = this.routeservice.supporterID;
      try {
        await this.fetchAllItems();
        this.getInputDatas();
      } catch (error) {
        console.error('Error fetching items:', error);
      }

    }
  }

  getplant() {

    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.plantcode = response;
        console.log(this.plantcode)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorydata: any[] = [];

  getcategory() {
    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response.filter((item: any) => item.supportId === 1);
        console.log(this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorytype: any[] = [];

  getcategorytype(): Promise<any> {
    const apiUrls = this.apiurl + '/CategoryTyp'
    return this.http.get(apiUrls).toPromise()
      .then((response: any) => {
        this.categorytype = response.filter((item: any) => item.categoryId === parseInt(this.categoryId))
        console.log('maincat',this.categorytype)
      })
      .catch((error: any) => {
        console.error('Post request failed', error);
        throw error;
      });
  }

  prioritytype: any[] = [];

  priorityapi() {
    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.prioritytype = response;
        console.log(this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }


  onsubmit() {
    this.checkassigned();
    this.submitissue();
  }

  checkassigned() {
    if (this.assignedtosearch != "") {
      this.assignedBy = this.supportid
      this.assignedOn = this.today
    }
  }

  issueRaisedBy: any = '';
  issueDate: any = '';
  Subject: any = '';
  issueDesc: any = '';
  images: Array<{ name: string, type: string, url: string }> = [];
  issueRaiseFor: any = '';
  plantId: any = '';
  assetId: any = '';
  categoryId: any = '';
  categoryTypId: any = '';
  priority: any = '';
  source: any = '';
  attachment: any = '';
  status: any = '';
  assignedTo: any = '';
  assignedBy: any = '';
  assignedOn: any = '';
  remarks: any = '';
  issuesraisedfor: any = '';
  assignedtosearch: any = '';
  messagesuccess: boolean = false;
  messageerror: boolean = false;

  errorMessage: any = '';
  successMessage: any = '';

  clearErrorMessage() {
    this.errorMessage = '';
  }
  clearSuccessMessage() {
    this.successMessage = '';
  }

  private decodeHtmlEntities(encodedString: string): string {
    const textarea = document.createElement('textarea');
    textarea.innerHTML = encodedString;
    return textarea.value;
  }

  private convertFileToBase64(file: File): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        resolve(reader.result as string);
      };
      reader.onerror = (error) => {
        reject('Error converting file to base64');
      };
    });
  }

  handleFileInput(event: any) {
    const files: File[] = Array.from(event.target.files);
    this.images = []; // Reset the array

    files.forEach(file => {
      this.convertFileToBase64(file).then(base64 => {
        this.images.push({ name: file.name, type: file.type, url: base64 });
        this.issueDesc += `<img src="${base64}" alt="${file.name} width='100' height='100' ">`;
      });
    });
  }



  submitissue() {
    const decodedDescData = this.decodeHtmlEntities(this.issueDesc);

    if (this.plantId == '') {
      this.errorMessage = 'Select Plant';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="plantId"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.categoryId == '') {
      this.errorMessage = 'Select Service-Category';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="categoryId"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.categoryTypId == '') {
      this.errorMessage = 'Select Sub-Category';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="categoryTypId"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.priority == '') {
      this.errorMessage = 'Select Priority';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="priority"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.Type == '') {
      this.errorMessage = 'Select Type';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="Type"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.source == '') {
      this.errorMessage = 'Select Source';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="source"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.assetId == '') {
      this.errorMessage = 'Select Impacted Asset';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="assetId"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.Subject == '') {
      this.errorMessage = 'Enter Subject';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="Subject"]');
      if (selectElement) {
        selectElement.focus();
      }
    }
    else if (this.issueDesc == '') {
      this.errorMessage = 'Enter Description';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      const selectElement = document.querySelector<HTMLSelectElement>('select[ngModel="issueDesc"]');
      if (selectElement) {
        selectElement.focus();
      }
    }

    else {
      const apiUrl = this.apiurl + '/IssueList/IssueList'
      this.issuesraisedfor = this.issueRaiseFor.split("-")[0];
      this.assignedtosearch = this.assignedTo.split("-")[0];
      const issuesRaisedBy = this.issueRaisedBy.split("-")[0];

      const requestBody = {
        "flag": "I",
        "issueId": 0,
        "issueRaisedBy": Number(this.supportid),
        "issueDate": this.today,
        "issueShotDesc": this.Subject,
        "issueDesc": decodedDescData,
        "issueRaiseFor": Number(this.issuesraisedfor),
        "issueForGuest": 'this.issueForGuest',
        "guestCompany": 'this.guestCompany',
        "plantId": Number(this.plantId),
        "assetId": Number(this.assetId),
        "categoryId": Number(this.categoryId),
        "categoryTypId": Number(this.categoryTypId),
        "priority": this.priority,
        "source": this.source,
        "attachment": this.attachment,
        "status": "Draft",
        "assignedTo": Number(this.assignedtosearch),
        "assignedBy": Number(this.EmployeeID),
        "assignedOn": /*this.assignedOn*/"2024-06-15T14:26:23.211Z",
        "remarks": 'this.remarks',
        "createdBy": Number(this.supportid)
      }
      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json'
        })
      };
      this.http.post(apiUrl, requestBody, httpOptions).subscribe(
        (response: any) => {
          console.log('responseresponse', response);
          this.messagesuccess = true
          this.addFile();
          alert("Saved Successfully!");
          //this.route.navigate(['/report_issue']);
          this.route.navigate(['/report_issue']);
        },
        (error: any) => {
          console.log('Post request failed', error);
          this.messageerror = true;
        });
    }

  }

  selectedFile: any = '';
  getattach(event: any): void {
    
    this.selectedFile = event.target.files[0];
    console.log = this.selectedFile
  }

  addFile(): void {
    if (!this.selectedFile) {
      console.error('No file selected.');
      return;
    }

    if (!this.supportid) {
      console.error('Support ID is required.');
      return;
    }

    const suppid = this.supportid.toString();
    const formData = new FormData();

    formData.append('itcrid', suppid);
    formData.append('file', this.selectedFile, this.selectedFile.name);

    const apiUrl = this.apiurl + '/CRlession';

    this.http.post(apiUrl, formData).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.error('POST request failed', error);
      }
    );
  }

  viewFile(fileName: string): void {
    const apiUrl = `${this.apiurl}/CRlession/GetFile?itcrid=${this.supportid}&fileName=${fileName}`;

    this.http.get(apiUrl, { responseType: 'blob' }).subscribe(
      (response: Blob) => {
        const url = window.URL.createObjectURL(response);
        const link = document.createElement('a');
        link.href = url;
        link.download = fileName;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
      },
      (error: any) => {
        console.error('GET request failed', error);
      }
    );
  }

  navigatesuccess() {
    this.route.navigate(['/report_issue']);
  }

  closeNotification() {
    this.messageerror = false;
  }

  /*search filter*/



  dropdownItems: any[] = [];
  selectedValue: string = '';
  supportteamname: any[] = [];
  employeeprofile: any[] = [];
  supportpersonname = '';
  firstname: any;
  middlename: any;
  lastname: any;

  /*  fetchAllItems() {
      const apiUrl = this.apiurl + '/EmployeeMasters';
      this.http.get<any[]>(apiUrl).subscribe(
        (response: any[]) => {
          console.log("Function", response);
          this.supportnames = response.map(item => item.employeeId + '-' + item.firstName + ' ' + item.middleName + ' ' + item.lastName);
          this.supportteamname = this.supportnames;
          this.employeeprofile = response.filter((row: any) => row.employeeId === this.supportid.trim());
          this.firstname = this.employeeprofile[0].firstName;
          this.middlename = this.employeeprofile[0].middleName;
          this.lastname = this.employeeprofile[0].lastName;
          *//*this.supportpersonname = this.firstname + this.middlename + this.lastname;*//*
  if (this.firstname !== null && this.firstname !== undefined) {
    this.supportpersonname += this.firstname;
  }

  if (this.middlename !== null && this.middlename !== undefined) {
    // If the supportpersonname is not empty, add a space before concatenating middle name
    if (this.supportpersonname !== '') {
      this.supportpersonname += ' ';
    }
    this.supportpersonname += this.middlename;
  }

  if (this.lastname !== null && this.lastname !== undefined) {
    // If the supportpersonname is not empty, add a space before concatenating last name
    if (this.supportpersonname !== '') {
      this.supportpersonname += ' ';
    }
    this.supportpersonname += this.lastname;
  }

  // If all parts of the name are null or undefined, set supportpersonname to 'Unknown'
  if (this.supportpersonname === '') {
    this.supportpersonname = 'Unknown';
  }


  // If all parts of the name are null, set supportpersonname to 'Unknown'
  if (this.supportpersonname === '') {
    this.supportpersonname = 'Unknown';
  }
},
(error: any) => {
  console.error('GET request failed', error);
}
);
}

filterItems() {
const filter = this.issueRaiseFor.toUpperCase();
this.dropdownItems = this.supportteamname.filter(item =>
item.toUpperCase().includes(filter)
);
if (this.dropdownItems.length === 0 && filter !== '') {
this.dropdownItems.push('No name found');
}
else if (filter === '') {
this.dropdownItems.length = 0
}

}
*/

  filterItems() {
    const filter = this.issueRaiseFor;
    this.dropdownItems = this.supportnames.filter(item =>
      item.employeeId.toString().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter === '') {
      this.dropdownItems.push('');
    } else if (filter === '') {
      this.dropdownItems.length = 0;
    }
  }

  dropdownItems2: any[] = [];
  filterItemsforGuest() {
    const filter = this.ReportingManagerEmpID;
    this.dropdownItems2 = this.supportnames.filter(item =>
      item.employeeId.toString().includes(filter)
    );
    if (this.dropdownItems2.length === 0 && filter === '') {
      this.dropdownItems2.push('');
    } else if (filter === '') {
      this.dropdownItems2.length = 0;
    }
  }

  fetchAllItems(): Promise<any> {
    const apiUrl = this.apiurl + '/EmployeeMasters';
    return this.http.get(apiUrl).toPromise()
      .then((response: any) => {
        this.supportnames = response;
        this.supportteams = response.filter((row: any) => row.employeeId == parseInt(this.supportid.trim()));
        if (this.selectedOption == "others") {
          this.supportteamsforOthers = response.filter((row: any) => row.employeeId == parseInt(this.issueRaiseFor.trim()));
        }
        if (this.selectedOption == "guest") {
          this.supportteamsforGuest = response.filter((row: any) => row.employeeId == parseInt(this.ReportingManagerEmpID.trim()));
        }
        console.log('this.supportteams', this.supportteams);
        console.log('this.supportteamsforOthers', this.supportteamsforOthers);
      })
      .catch((error: any) => {
        console.error('GET request failed', error);
        throw error;
      });
  }

  async selectItem(item: any) {
    if (this.selectedOption == "others") {
      this.issueRaiseFor = item.employeeId;
      this.dropdownItems = [];
      try {
        await this.fetchAllItems();
        this.getOtherInputDatas();
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    }

    if (this.selectedOption == "guest") {
      this.ReportingManagerEmpID = item.employeeId;
      this.dropdownItems2 = [];
      try {
        await this.fetchAllItems();
        this.getGuestInputDatas();
      } catch (error) {
        console.error('Error fetching items:', error);
      }
    }
  }

  /*selectItem(item: string) {
    this.selectedValue = item;
    this.issueRaiseFor = item;
    this.dropdownItems = [];
    this.supportid = this.selectedValue.split("-")[0];
    this.getSelectedData();
  }*/

  /*  getSelectedData() {
      this.supportteams = [];
      const apiUrls = this.apiurl + '/SupportTeam'
      const requestBody = {
  
      }
      const httpOptions = {
        headers: new HttpHeaders({
          'content-Type': 'application/json'
        })
      };
      this.http.get(apiUrls, requestBody).subscribe(
        (response: any) => {
          this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
          this.getInputDatas();
          this.getcategorytype();
        },
        (error) => {
          console.error("Post failed", error)
        }
      )
    }
  */

  async getSelectedData() {
    this.supportteams = [];
    const apiUrls = this.apiurl + '/SupportTeam';
    const requestBody = {}; // No request body needed for GET request

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    try {
      const response: any = await this.http.get(apiUrls, httpOptions).toPromise();

      if (response) {
        // Process response
        this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));

        // Now call your methods that depend on this data
        this.getInputDatas();
        this.getcategorytype();
      } else {
        console.error('Response is undefined or null');
        // Handle undefined response case if needed
      }
    } catch (error) {
      console.error('GET request failed', error);
      // Handle error as needed
    }
  }

  dropdownItemscr: string[] = [];
  selectedValuecr: string = '';
  filterItemscr() {
    const filter = this.issueRaisedBy.toUpperCase();
    this.dropdownItemscr = this.supportteamname.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItemscr.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItemscr.length = 0
    }
  }

  selectItemcr(item: string) {
    this.selectedValuecr = item;
    this.issueRaisedBy = item;
    this.dropdownItemscr = [];
  }

  assigntofilter: any[] = [];

  dropdownItemsassign: string[] = [];
  selectedValueassign: string = '';
  filterItemsassign() {
    const filter = this.assignedTo.toUpperCase();
    this.dropdownItemsassign = this.assigntofilter.filter(item =>
      item.toUpperCase().includes(filter)
    );
    if (this.dropdownItems.length === 0 && filter !== '') {
      this.dropdownItemsassign.push('No name found');
    }
    else if (filter === '') {
      this.dropdownItemsassign.length = 0
    }
  }

  selectItemassign(item: string) {
    this.selectedValueassign = item;
    this.assignedTo = item;
    this.dropdownItemsassign = [];
  }
}

