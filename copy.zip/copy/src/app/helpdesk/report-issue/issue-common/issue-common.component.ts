import { Component } from '@angular/core';

@Component({
  selector: 'app-issue-common',
  templateUrl: './issue-common.component.html',
  styleUrl: './issue-common.component.css'
})
export class IssueCommonComponent {

}
