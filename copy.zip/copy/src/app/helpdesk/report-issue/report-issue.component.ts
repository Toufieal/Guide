import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { environment } from '/IT_Portal/IT-Portal/IT-Portal.UI/src/environments/environment'
import { MatDialog } from '@angular/material/dialog';
import { IssueAssigntoComponent } from './issue-new-issue/issue-assignto/issue-assignto.component';
import { PasscrdataService } from '../../change-request/passcrdata.service';
import { Router } from '@angular/router';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { HelpdeskserviceService } from '../helpdeskservice.service';

interface DropdownItem {
  item_id: number;
  item_text: string;
}

@Component({
  selector: 'app-report-issue',
  templateUrl: './report-issue.component.html',
  styleUrl: './report-issue.component.css'
})
export class ReportIssueComponent {
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  tableData: any[] = [];
  supportid: any;

  paginatedTableData: any[] = [];
  pageIndex = 0;
  pageSize = 5;
  totalItems = 0;
  editIndex: number = -1;
  filterflag: boolean = false;
  fromDt: any = '';
  endDt: any = '';
  today: any;

  constructor(private http: HttpClient, private router: Router, private helpdeskservice: HelpdeskserviceService, private route: Router, private dialog: MatDialog, private routeservice:PasscrdataService) {
    this.routeservice.getsupportteam();
    this.supportid = this.routeservice.supporterID;
  }

  private apiurl = environment.apiurls
  isVisible = true;
  empid: string = '';
  deleteconfirmation: boolean = false;


  toggleVisibility() {
    this.isVisible = !this.isVisible;
  }

  ShowIssue: boolean = false;

  ngOnInit(): void {
    this.getsupportteams();
    this.getplant();
    this.getcategory();
    this.getpriority();
    this.getissuelist();
    this.fetchDropdownData();
    this.fetchCategoryData();
    this.getSelectedData();
  }

  /*-----------------------Filter--------------------------------start*/

  dropdownList: DropdownItem[] = [];
  selectedPlantIds: any[] = [];
  impactedLocation: any = '';
  selectedlocationNames: any = '';
  dropdowncategroy: DropdownItem[] = [];
  selectedCategoryId: any[] = [];
  selectedcategroy: any = '';
  filtersdata: any[] = [];
  issuelist: any = '';
  categoryId: any = '';
  Category: any = '';
  

  dropdownSettings = {
    idField: 'item_id',
    textField: 'item_text',
  };

  fetchDropdownData(): void {
    const apiUrl = this.apiurl + '/Plantid'; //Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdownList = data.map(item => ({
          item_id: item.id,
          item_text: item.code //Assuming your API response has 'id' and 'name' fields
        }));
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }
  fetchCategoryData(): void {
    const apiUrl = this.apiurl + '/Category' // Replace with your API endpoint
    this.http.get<any[]>(apiUrl).subscribe(
      (data) => {
        this.dropdowncategroy = data.map(item => ({
          item_id: item.itcategoryId,
          item_text: item.categoryName // Assuming your API response has 'id' and 'name' fields
        }));
        console.log(this.dropdowncategroy);
      },
      (error) => {
        console.error('Error fetching dropdown data:', error);
      }
    );
  }
  mapedplantdatas() {
    this.impactedLocation = this.selectedPlantIds.map((item: any) => item.item_id);
    console.log('Plant:', this.impactedLocation)
    this.selectedlocationNames = Array.from(new Set(this.impactedLocation));
  }

  mapedcategoryatas() {
    this.impactedLocation = this.selectedCategoryId.map((item: any) => item.item_id);
    console.log(this.impactedLocation)
    this.selectedcategroy = Array.from(new Set(this.impactedLocation));
  }

  onclickfilter() {
      //this.resetfn();
      this.filterdropdown();
  }

  filterdropdown() {
    debugger
    this.filtersdata = [];
  

    if (this.selectedlocationNames != '') {

      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist;
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.plantId === parseInt(this.selectedlocationNames))
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
      console.log("filter in chage", this.selectedlocationNames, this.paginatedTableData)
    }


    if (this.selectedcategroy != '') {
      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.parseAndSortResponse(this.issuelist)
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.categoryId === parseInt(this.selectedcategroy))
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
    }

    /*if (this.classificationid != '') {
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.itclassificationId === parseInt(this.classificationid))
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
      //return this.paginatedTableData
    }
    else {
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
    }*/

    if (this.prioritytypeid != '') {

      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.priorityid === parseInt(this.prioritytypeid))
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
    }

   /* if (this.searchrfcnumber != '') {
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.crcode === this.searchrfcnumber)
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
    }*/


    if (this.fromDt != '') {
      if (this.endDt == '') this.endDt = this.today;
        this.filterflag = true;
        if (this.filtersdata.length == 0) {
          this.filtersdata = this.issuelist
        }
        this.filtersdata = this.filtersdata.filter((item: any) => item.issueDate > this.fromDt.trim() && item.issueDate <= this.endDt.trim())
        this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
      
    }

    if (this.endDt != '' && this.fromDt == '') {
      if (this.fromDt == '') this.fromDt = this.endDt;

      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist
      }
      this.filtersdata = this.filtersdata.filter((item: any) => item.issueDate > this.fromDt && item.issueDate <= this.endDt)
      this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
    }

    if (this.statusfilter != '' && this.statusfilter != undefined) {
      this.filterflag = true;
      if (this.filtersdata.length == 0) {
        this.filtersdata = this.issuelist
      }

      if (this.statusfilter == 'All') {
        this.filtersdata = this.issuelist
        this.filtersdata = this.parseAndSortResponse(this.filtersdata);
      }
      else {
        this.filtersdata = this.filtersdata.filter((item: any) => item.status.trim() === this.statusfilter)
        this.paginatedTableData = this.parseAndSortResponse(this.filtersdata);
      }
    }

    this.totalItems = this.paginatedTableData.length;
    this.paginatedTableData = this.paginatedTableData.slice(this.pageIndex * this.pageSize, (this.pageIndex + 1) * this.pageSize);
    console.log("(filtereddata", this.paginatedTableData)
  }

  resetfn() {
    this.selectedPlantIds = [];
    this.selectedCategoryId = [];
    this.Category = '';
    this.prioritytypeid = '';
    this.statusfilter = '';
    this.fromDt= '';
    this.endDt = '';
    this.getissuelist();
  }

/*-----------------------Filter--------------------------------end*/

  OnEdit(index: number) {
    this.editIndex = index;
    const selectdata = [this.paginatedTableData[index]];
    const selectRowData = {
      rowData: selectdata,
    }
    if (selectdata[0].status.trim() == "Draft") {
      this.helpdeskservice.getUpdateNewIssueData({ selectRowData });
      this.route.navigate(['/new_issue_draft/' + selectdata[0].issueId + '/edit'])
    }
    else {
      this.helpdeskservice.getUpdateNewIssueData({ selectRowData });
      this.route.navigate(['/update_issue_resolution/' + selectdata[0].issueId + '/edit'])
    }
  }


 
  /*updatevalue: any[] = [];
  getupdatevalue() {
    const apiUrls = this.apiurl + '/IssueList/Getissuelist'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.tableData = response;
        *//*this.updatevalue = response.filter((row: any) => row.issueId === parseInt(this.urlissueid));
        console.log("update issues",this.updatevalue)*//*
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }*/

  getissuelist() {

    const apiUrls = this.apiurl + '/IssueList/Getissuelist'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.issuelist = response.filter((item: any) => item.raisedbyid === parseInt(this.supportid));
        this.totalItems =this.issuelist.length;
        this.paginatedTableData = this.issuelist.slice(this.pageIndex * this.pageSize, (this.pageIndex + 1) * this.pageSize);
        console.log('this.paginatedTableData', this.paginatedTableData)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  onPageChange(event: PageEvent) {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.getissuelist();
  }

  /*plantscode: string = '';*/
  categoryids: string = '';
  
  prioritytypeid: string = '';
  statusfilter: string = '';
  plantcode: any[] = [];

  getplant() {
    const apiUrls = this.apiurl + '/Plantid'
    const requestBody = {

    }
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.plantcode = response;
        console.log("Plantid",this.plantcode)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }


  getSelectedData() {
    this.supportteams = [];
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId == parseInt(this.supportid.trim()));
        this.getcategorytype();
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorytype: any[] = [];

  getcategorytype() {
    const apiUrls = this.apiurl + '/CategoryTyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.categorytype = response.filter((item: any) => item.categoryId === parseInt(this.categoryId))
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorydata: any[] = [];

  getcategory() {
    const apiUrls = this.apiurl + '/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response;
        console.log(this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  prioritydata: any[] = [];
  getpriority() {

    const apiUrls = this.apiurl + '/Priority'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.prioritydata = response;
        console.log("Priority data test", this.prioritydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  openDialog(issueId: string): void {
    const dialogRef = this.dialog.open(IssueAssigntoComponent, {
      width: '33%',
      data: { issueId: issueId }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  //Login users

  supportteams: any[] = [];
  getsupportid: any;
  supportpersonname = '';
  firstname: any;
  middlename: any;
  lastname: any;
  HideUpdate: boolean = false;

  getsupportteams() {
    const apiUrls = this.apiurl + '/SupportTeam'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteams = response.filter((row: any) => row.empId === parseInt(this.supportid.trim()));
        this.getsupportid = this.supportteams[0].supportTeamId
        /*if (this.supportid == "135055") {
          this.ShowIssue = true;
          this.HideUpdate = true;
        }
        else {
          this.ShowIssue = false;
          this.HideUpdate = false;
        }*/
        /*this.firstname = this.supportteams[0].firstName
        this.middlename = this.supportteams[0].middleName
        this.lastname = this.supportteams[0].lastName
        this.supportpersonname = this.firstname + this.middlename + this.lastname*/
      },
      
      (error) => {
        console.error("Post failed", error)
      }
    )
    setTimeout(() => {
      this.getsupportteamassign()
    }, 1000);
    
  }

  parseAndSortResponse(response: any): any[] {
    let parsedResponse = response.map((item: any) => {
      return item;
    });
    parsedResponse.sort((a: any, b: any) => {
      if (a.itcrid < b.itcrid) {
        return 1;
      }
      if (a.itcrid > b.itcrid) {
        return -1;
      }
      return 0;
    });
    return parsedResponse;
  }
  
  /*tableData: any[] = [
    {
      'engineer': 'Mechnanical Engineer',
      'status': 'Opened',
      'location': 'ML04',
      'department': 'Manufacturing',
      'user': 'Michael',
      'category': 'Servers',
      'type': 'TrendMicro',
      'fromdate': '01-02-2024',
      'todate': '05-02-2024',
      'sla': 'sla',
      'delay': '02-03-2024',
    },
    {
      'engineer': 'Backend Developer',
      'status': 'On Hold',
      'location': 'ML04',
      'department': 'Manufacturing',
      'user': 'Muthu',
      'category': 'Servers',
      'type': 'TrendMicro',
      'fromdate': '01-02-2024',
      'todate': '05-02-2024',
      'sla': 'sla',
      'delay': '02-03-2024',
    },
    {
      'engineer': 'Software Engineer',
      'status': 'Resolved',
      'location': 'ML04',
      'department': 'Manufacturing',
      'user': 'Syed',
      'category': 'Servers',
      'type': 'TrendMicro',
      'fromdate': '01-02-2024',
      'todate': '05-02-2024',
      'sla': 'sla',
      'delay': '02-03-2024',
    }
  ]*/

  supportteamassign: any[] = [];
  ischangeanalyst: any;
  isapprover: any;
  issupportegineer: any;
  assignedplant: any;
  getsupportteamassign() {
    
    const apiUrls = this.apiurl + '/SupportteamAssigned'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        this.supportteamassign = response.filter((row: any) => row.supportTeamId === this.getsupportid);
        this.assignedplant = this.supportteamassign[0].plantId
        this.isapprover = this.supportteamassign[0].isApprover
        this.issupportegineer = this.supportteamassign[0].isSupportEngineer
        this.ischangeanalyst = this.supportteamassign[0].isChangeAnalyst
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  GotoResolution() {
    this.router.navigate(['/issue_resolution']);
  }

  deleteyes() {
    this.deleteconfirmation = false
  }

  deleteno() {
    this.deleteconfirmation = false
  }


}
