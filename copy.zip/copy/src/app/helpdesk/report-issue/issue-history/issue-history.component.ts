import { Component } from '@angular/core';

@Component({
  selector: 'app-issue-history',
  templateUrl: './issue-history.component.html',
  styleUrl: './issue-history.component.css'
})
export class IssueHistoryComponent {

}
