import { Component } from '@angular/core';

@Component({
  selector: 'app-itspare',
  templateUrl: './itspare.component.html',
  styleUrl: './itspare.component.css'
})
export class ItspareComponent {

}
