import { Component } from '@angular/core';

@Component({
  selector: 'app-consumeable',
  templateUrl: './consumeable.component.html',
  styleUrl: './consumeable.component.css'
})
export class ConsumeableComponent {

}
