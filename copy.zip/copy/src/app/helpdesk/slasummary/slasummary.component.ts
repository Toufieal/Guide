import { Component } from '@angular/core';

@Component({
  selector: 'app-slasummary',
  templateUrl: './slasummary.component.html',
  styleUrl: './slasummary.component.css'
})
export class SlasummaryComponent {


}
