import { Component } from '@angular/core';

@Component({
  selector: 'app-slaresolution',
  templateUrl: './slaresolution.component.html',
  styleUrl: './slaresolution.component.css'
})
export class SlaresolutionComponent {



}
