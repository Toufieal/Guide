import { Component } from '@angular/core';

@Component({
  selector: 'app-details-tab',
  templateUrl: './details-tab.component.html',
  styleUrl: './details-tab.component.css'
})
export class DetailsTabComponent {

}
