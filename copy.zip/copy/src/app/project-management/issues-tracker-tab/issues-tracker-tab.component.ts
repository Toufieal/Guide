import { Component } from '@angular/core';

@Component({
  selector: 'app-issues-tracker-tab',
  templateUrl: './issues-tracker-tab.component.html',
  styleUrl: './issues-tracker-tab.component.css'
})
export class IssuesTrackerTabComponent {

}
